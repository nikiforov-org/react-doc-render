import {
  formatDateToEuropean,
  formatDateToISO,
  formatDateToRussian,
  formatTime,
  isIsoString,
} from './date';

describe('date utility', () => {
  describe('isIsoString', () => {
    it('should return true for valid ISO string', () => {
      const input = '2024-09-18T11:30:45.123Z';
      expect(isIsoString(input)).toBe(true);
    });

    it('should return false for invalid ISO string', () => {
      const input = '2024-09-18T11:30:45.123';
      expect(isIsoString(input)).toBe(false);
    });

    it('should return false for non-date string', () => {
      const input = 'date';
      expect(isIsoString(input)).toBe(false);
    });
  });

  describe('formatDateToISO', () => {
    it('should format a Date object to ISO date string (YYYY-MM-DD)', () => {
      const input = new Date(2024, 8, 18);
      const expected = '2024-09-18';
      expect(formatDateToISO(input)).toBe(expected);
    });

    it('should format a date string to ISO date string (YYYY-MM-DD)', () => {
      const input = '2024-08-03T12:05:30.123';
      const expected = '2024-08-03';
      expect(formatDateToISO(input)).toBe(expected);
    });

    it('should return "Invalid Date" for non-date string', () => {
      const input = 'date';
      const expected = 'Invalid Date';
      expect(formatDateToISO(input)).toBe(expected);
    });
  });

  describe('formatDateToEuropean', () => {
    it('should format a Date object to european date string (DD-MM-YYYY)', () => {
      const input = new Date(2024, 5, 17);
      const expected = '17-06-2024';
      expect(formatDateToEuropean(input)).toBe(expected);
    });

    it('should format a date string to europen date string (DD-MM-YYYY)', () => {
      const input = '2024-03-08T12:00:30.123';
      const expected = '08-03-2024';
      expect(formatDateToEuropean(input)).toBe(expected);
    });

    it('should return "Invalid Date" for non-date string', () => {
      const input = 'date';
      const expected = 'Invalid Date';
      expect(formatDateToEuropean(input)).toBe(expected);
    });
  });

  describe('formatDateToRussian', () => {
    it('should format a Date object to russian date string (DD.MM.YYYY)', () => {
      const input = new Date(2024, 1, 23);
      const expected = '23.02.2024';
      expect(formatDateToRussian(input)).toBe(expected);
    });

    it('should format a date string to russian date string (DD.MM.YYYY)', () => {
      const input = '2024-05-31T10:10:30.100';
      const expected = '31.05.2024';
      expect(formatDateToRussian(input)).toBe(expected);
    });

    it('should return "Invalid Date" for  non-date string', () => {
      const input = 'date';
      const expected = 'Invalid Date';
      expect(formatTime(input)).toBe(expected);
    });
  });

  describe('formatTime', () => {
    it('should format a Date object to time string (HH:mm:ss)', () => {
      const input = new Date(2024, 5, 1, 17, 30, 30);
      const expected = '17:30:30';
      expect(formatTime(input)).toBe(expected);
    });

    it('should format a date string to time string (HH:mm:ss)', () => {
      const input = '2024-12-31T09:12:32.100';
      const expected = '09:12:32';
      expect(formatTime(input)).toBe(expected);
    });

    it('should return "Invalid Date" for non-time string', () => {
      const input = 'date';
      const expected = 'Invalid Date';
      expect(formatTime(input)).toBe(expected);
    });
  });
});
