import { Metadata } from '@/components/MetaData';

export const getFilteredObjectTypes = (
  objectTypesData: Metadata['objectTypeMap'] | null,
): string[] => {
  if (objectTypesData) {
    return Object.keys(objectTypesData).filter(
      (key) => !objectTypesData[key]?.dictionary,
    );
  }
  return [];
};
