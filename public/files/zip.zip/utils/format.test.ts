import { formatBytes } from './format';

describe('format utility', () => {
  describe('formatBytes', () => {
    it('should return "0 B" for 0 and negative numbers', () => {
      expect(formatBytes(0)).toBe('0 B');
      expect(formatBytes(-1)).toBe('0 B');
    });

    it('should format bytes correctly with default 2 decimals', () => {
      expect(formatBytes(1024)).toBe('1.02 kB');
      expect(formatBytes(1550550)).toBe('1.55 MB');
    });

    it('should format bytes correctly without decimals', () => {
      expect(formatBytes(1024, 0)).toBe('1 kB');
      expect(formatBytes(1050550, 0)).toBe('1 MB');
    });

    it('should format bytes correctly with custom decimals', () => {
      expect(formatBytes(1024, 3)).toBe('1.024 kB');
      expect(formatBytes(1050550, 5)).toBe('1.05055 MB');
    });

    it('should handle large numbers (GB and TB)', () => {
      expect(formatBytes(1048576123)).toBe('1.05 GB');
      expect(formatBytes(1056576123456)).toBe('1.06 TB');
    });

    it('should handle small numbers less than 1 kB', () => {
      expect(formatBytes(512)).toBe('512 B');
    });
  });
});
