export const objectToArray = <T extends object>(
  obj: T,
): Array<{ key: string } & T[keyof T]> => {
  return Object.entries(obj).map(([key, value]) => {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      return { key, ...value };
    } else {
      return { key, value };
    }
  });
};
