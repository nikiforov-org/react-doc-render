import { getFilteredObjectTypes } from './getFilteredObjectTypes';

describe('getFilteredObjectTypes', () => {
  it('should return an empty array if objectTypesData is empty or null', () => {
    expect(getFilteredObjectTypes({})).toEqual([]);
    expect(getFilteredObjectTypes(null)).toEqual([]);
  });

  it('should return keys of object types with dictionary = false', () => {
    const input = {
      objectType1: {
        dictionary: true,
        displayName: 'object type 1',
        fieldMap: {},
      },
      objectType2: {
        dictionary: false,
        displayName: 'object type 2',
        fieldMap: {},
      },
      objectType3: {
        dictionary: false,
        displayName: 'object type 3',
        fieldMap: {},
      },
    };
    const expected = ['objectType2', 'objectType3'];
    expect(getFilteredObjectTypes(input)).toEqual(expected);
  });

  it('should return all keys of object types if they all have not dictionary property', () => {
    const input = {
      objectType1: {
        dictionary: false,
        displayName: 'object type 1',
        fieldMap: {},
      },
      objectType2: {
        dictionary: false,
        displayName: 'object type 2',
        fieldMap: {},
      },
      objectType3: {
        dictionary: false,
        displayName: 'object type 3',
        fieldMap: {},
      },
    };
    expect(getFilteredObjectTypes(input)).toEqual([
      'objectType1',
      'objectType2',
      'objectType3',
    ]);
  });

  it('should return an empty array if all object types with dictionary = true', () => {
    const input = {
      objectType1: {
        dictionary: true,
        displayName: 'object type 1',
        fieldMap: {},
      },
      objectType2: {
        dictionary: true,
        displayName: 'object type 2',
        fieldMap: {},
      },
      objectType3: {
        dictionary: true,
        displayName: 'object type 3',
        fieldMap: {},
      },
    };
    expect(getFilteredObjectTypes(input)).toEqual([]);
  });
});
