import { TreeNode } from 'primereact/treenode';
import { findNodeByField } from './tree';

describe('tree utility', () => {
  describe('findNodeByField', () => {
    const tree: TreeNode[] = [
      {
        key: '0',
        label: 'Node 0',
        children: [
          {
            key: '0-0',
            label: 'Node 0-0',
          },
          {
            key: '0-1',
            label: 'Node 0-1',
            children: [
              {
                key: '0-1-0',
                label: 'Node 0-1-0',
              },
            ],
          },
        ],
      },
      {
        key: '1',
        label: 'Node 1',
        children: [
          {
            key: '1-0',
            label: 'Node 1-0',
          },
        ],
      },
    ];

    it('should return the correct node at the root level', () => {
      const input = findNodeByField('key', '0', tree);
      const expected = {
        key: '0',
        label: 'Node 0',
        children: [
          {
            key: '0-0',
            label: 'Node 0-0',
          },
          {
            key: '0-1',
            label: 'Node 0-1',
            children: [
              {
                key: '0-1-0',
                label: 'Node 0-1-0',
              },
            ],
          },
        ],
      };
      expect(input).toEqual(expected);
    });

    it('should return the correct node at the child level', () => {
      const input = findNodeByField('label', 'Node 1-0', tree);
      const expected = {
        key: '1-0',
        label: 'Node 1-0',
      };
      expect(input).toEqual(expected);
    });

    it('should return the correct node at the grandchild level', () => {
      const input = findNodeByField('key', '0-1-0', tree);
      const expected = {
        key: '0-1-0',
        label: 'Node 0-1-0',
      };
      expect(input).toEqual(expected);
    });

    it('should return null when the node is not found', () => {
      const input = findNodeByField('label', 'NODE TEST', tree);
      expect(input).toBeNull();
    });

    it('should return null when searching by a non-existent field', () => {
      const input = findNodeByField('count' as keyof TreeNode, 1, tree);
      expect(input).toBeNull();
    });
  });
});
