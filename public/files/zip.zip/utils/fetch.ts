export const fetchWithErrorHandling =
  (
    fetchFn: (
      input: URL | RequestInfo,
      init?: RequestInit | undefined,
    ) => Promise<Response>,
  ) =>
  async (input: string | URL | Request, init?: RequestInit | undefined) => {
    try {
      const response = await fetchFn(input, init);
      if (!response.ok) {
        throw new Error(`Fetch response is not ok: ${response.status}`, {
          cause: response,
        });
      }
      return response;
    } catch (error) {
      if (process.env.NODE_ENV === 'development') {
        if (
          error instanceof Error &&
          error.message.startsWith('Fetch response is not ok')
        ) {
          console.error(error.message, error.cause);
        } else {
          console.error(error);
        }
      }
      throw error;
    }
  };
