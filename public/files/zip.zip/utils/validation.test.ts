import { Field } from '@/components/MetaData';
import { getRules } from './validation';

describe('validation utility', () => {
  describe('getRules', () => {
    it('should return undefined if field is undefined', () => {
      const input = getRules(undefined);
      expect(input).toBeUndefined();
    });

    it('should return required rule if field is not nullable and not a filter', () => {
      const field: Field = {
        dataType: 'TEXT',
        nullable: false,
      };
      const input = getRules(field);
      const expected = {
        required: 'Обязательное поле',
        pattern: undefined,
      };
      expect(input).toEqual(expected);
    });

    it('should not return required rule for nullable field', () => {
      const field: Field = {
        dataType: 'TEXT',
        nullable: true,
      };
      const input = getRules(field);
      const expected = {
        required: undefined,
        pattern: undefined,
      };
      expect(input).toEqual(expected);
    });

    it('should not return required rule for BOOLEAN data type', () => {
      const field: Field = {
        dataType: 'BOOLEAN',
        nullable: false,
      };
      const input = getRules(field);
      const expected = {
        required: undefined,
        pattern: undefined,
      };
      expect(input).toEqual(expected);
    });

    it('should not return required rule if isFilter = true', () => {
      const field: Field = {
        dataType: 'TEXT',
        nullable: false,
      };
      const input = getRules(field, true);
      const expected = {
        required: undefined,
        pattern: undefined,
      };
      expect(input).toEqual(expected);
    });

    it('should return pattern rule if regexPattern and validationMessage exist', () => {
      const field: Field = {
        dataType: 'TEXT',
        nullable: false,
        regexPattern: '^[a-zA-Zа-яА-Я\\s]+$',
        validationMessage: 'Только буквы',
      };
      const input = getRules(field);
      const expected = {
        required: 'Обязательное поле',
        pattern: {
          value: new RegExp('^[a-zA-Zа-яА-Я\\s]+$'),
          message: 'Только буквы',
        },
      };
      expect(input).toEqual(expected);
    });

    it('should not return pattern rule if regexPattern or validationMessage is missing', () => {
      const field: Field = {
        dataType: 'TEXT',
        nullable: false,
        validationMessage: 'Только буквы',
      };
      const input = getRules(field);
      const expected = {
        required: 'Обязательное поле',
        pattern: undefined,
      };
      expect(input).toEqual(expected);
    });
  });
});
