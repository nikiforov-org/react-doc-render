import { TreeNode } from 'primereact/treenode';

export function findNodeByField<T extends TreeNode, V>(
  fieldName: keyof T,
  fieldValue: V,
  nodes: T[],
): T | null {
  for (const node of nodes) {
    if (node[fieldName] === fieldValue) {
      return node;
    }
    if (node.children && node.children.length > 0) {
      const foundNode = findNodeByField(
        fieldName,
        fieldValue,
        node.children as T[],
      );
      if (foundNode) {
        return foundNode;
      }
    }
  }
  return null;
}
