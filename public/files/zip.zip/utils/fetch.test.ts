import { fetchWithErrorHandling } from './fetch';

describe('fetch utility', () => {
  let consoleErrorMock: jest.SpyInstance;
  const originalEnv = { ...process.env };

  beforeEach(() => {
    process.env = {
      ...originalEnv,
      NODE_ENV: 'development',
    };
    consoleErrorMock = jest
      .spyOn(console, 'error')
      .mockImplementation(() => {});
  });

  afterEach(() => {
    process.env = originalEnv;
    jest.restoreAllMocks();
  });

  describe('fetchWithErrorHandling', () => {
    it('returns response when fetch is successful', async () => {
      const mockFetch = jest.fn().mockResolvedValue({
        ok: true,
        status: 200,
        json: async () => ({ success: true }),
      });

      const fetchWithHandler = fetchWithErrorHandling(mockFetch);
      const response = await fetchWithHandler('https://api.example.com/data');
      expect(mockFetch).toHaveBeenCalledWith(
        'https://api.example.com/data',
        undefined,
      );

      const data = await response.json();
      expect(data).toEqual({ success: true });
    });

    it('throws error when response is not ok', async () => {
      const mockFetch = jest.fn().mockResolvedValue({
        ok: false,
        status: 404,
        statusText: 'Not Found',
      });

      const fetchWithHandler = fetchWithErrorHandling(mockFetch);
      await expect(
        fetchWithHandler('https://api.example.com/data-not-found'),
      ).rejects.toThrow('Fetch response is not ok: 404');

      if (process.env.NODE_ENV === 'development') {
        expect(consoleErrorMock).toHaveBeenCalledWith(
          'Fetch response is not ok: 404',
          expect.any(Object),
        );
      }
    });

    it('handles network errors and logs them', async () => {
      const mockFetch = jest.fn().mockRejectedValue(new Error('Network Error'));

      const fetchWithHandler = fetchWithErrorHandling(mockFetch);
      await expect(
        fetchWithHandler('https://api.example.com/data'),
      ).rejects.toThrow('Network Error');

      if (process.env.NODE_ENV === 'development') {
        expect(consoleErrorMock).toHaveBeenCalledWith(
          new Error('Network Error'),
        );
      }
    });
  });
});
