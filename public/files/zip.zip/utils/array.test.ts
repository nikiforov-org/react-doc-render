import { objectToArray } from './array';

describe('objectToArray', () => {
  it('should convert a simple object into an array of objects', () => {
    const input = { a: 1, b: 2, c: 3 };
    const expected: { key: string; value: number }[] = [
      { key: 'a', value: 1 },
      { key: 'b', value: 2 },
      { key: 'c', value: 3 },
    ];

    expect(objectToArray(input)).toEqual(expected);
  });

  it('should merge nested objects with the key', () => {
    const input = {
      a: { x: 10, y: 20 },
      b: { x: 30, y: 40 },
    };
    const expected: { key: string; x?: number; y?: number }[] = [
      { key: 'a', x: 10, y: 20 },
      { key: 'b', x: 30, y: 40 },
    ];

    expect(objectToArray(input)).toEqual(expected);
  });

  it('should handle nested arrays correctly', () => {
    const input = {
      a: [1, 2, 3],
      b: { x: 10, y: 20 },
    };
    const expected: {
      key: string;
      value?: number[];
      x?: number;
      y?: number;
    }[] = [
      { key: 'a', value: [1, 2, 3] },
      { key: 'b', x: 10, y: 20 },
    ];

    expect(objectToArray(input)).toEqual(expected);
  });

  it('should return an empty array for an empty object', () => {
    const input = {};
    const expected: any[] = []; // Explicitly typed as any[]

    expect(objectToArray(input)).toEqual(expected);
  });

  it('should handle null and undefined values correctly', () => {
    const input = {
      a: null,
      b: undefined,
      c: { x: 10 },
    };
    const expected: { key: string; value?: any; x?: number }[] = [
      { key: 'a', value: null },
      { key: 'b', value: undefined },
      { key: 'c', x: 10 },
    ];

    expect(objectToArray(input)).toEqual(expected);
  });
});
