import { getFilterValues } from './getFiltersValue';

describe('getFilterValues', () => {
  it('should return an empty array if filterValues is empty', () => {
    const filterValues = {};
    const labels = { name: 'Name' };

    const input = getFilterValues(filterValues, labels);

    expect(input).toEqual([]);
  });

  it('should return correctly formatted date if value is an ISO string', () => {
    const filterValues = { date: '2024-09-19T12:30:30.123Z', name: 'Test' };
    const labels = { date: 'Дата', name: 'Наименование' };

    const input = getFilterValues(filterValues, labels);

    const expected = [
      { key: 'date', value: 'Дата: 19.09.2024' },
      { key: 'name', value: 'Наименование: Test' },
    ];

    expect(input).toEqual(expected);
  });

  it('should return null for a null value in filterValues', () => {
    const filterValues = { name: null };
    const labels = { name: 'Name' };

    const input = getFilterValues(filterValues, labels);

    expect(input).toEqual([null]);
  });
});
