import { Field } from '@/components/MetaData';

export const getRules = (field: Field | undefined, isFilter?: boolean) => {
  let result:
    | {
        required: string | undefined;
        pattern: { value: RegExp; message: string } | undefined;
      }
    | undefined;

  if (field) {
    result = {
      required:
        field.dataType !== 'BOOLEAN' && !field.nullable && !isFilter
          ? 'Обязательное поле'
          : undefined,
      pattern:
        field.regexPattern && field.validationMessage
          ? {
              value: new RegExp(field.regexPattern),
              message: field.validationMessage,
            }
          : undefined,
    };
  }

  return result;
};
