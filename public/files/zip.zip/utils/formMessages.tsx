import { Toast } from 'primereact/toast';
import React, { ReactNode, createContext, useContext, useRef } from 'react';
import { FieldErrors } from 'react-hook-form';

export const getFormErrorMessage = (errors: FieldErrors, name: string) => {
  const errorMessage = errors[name]?.message;
  return errorMessage ? (
    <small className="p-error">{errorMessage as ReactNode}</small>
  ) : null;
};

const ToastStyle = {
  content: { className: 'border-none' },
  text: { className: 'ml-2' },
  detail: { className: 'm-0 text-sm font-normal' },
  closeButton: { className: 'w-4 h-4' },
};

export const ToastContext = createContext<{
  showToast: (type: 'success' | 'error', message: string) => void;
}>({ showToast: () => {} });

export const ToastProvider = ({ children }: React.PropsWithChildren) => {
  const toastRef = useRef<Toast>(null);

  const showToast = (type: 'success' | 'error', message?: string) => {
    let defaultMessage = '';
    if (type === 'success') {
      defaultMessage = 'Успех!';
    } else if (type === 'error') {
      defaultMessage = 'Ошибка!';
    }
    toastRef.current?.show({
      severity: type,
      icon: <div className="icon-warning-round" />,
      detail: message ?? defaultMessage,
      life: 5000,
    });
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      <Toast ref={toastRef} pt={ToastStyle} />
      {children}
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  return useContext(ToastContext);
};
