import { render } from '@testing-library/react';
import { FieldErrors } from 'react-hook-form';
import { getFormErrorMessage } from './formMessages';

describe('formMessages utility', () => {
  describe('getFormErrorMessage', () => {
    it('returns error message if field has an error', () => {
      const errors: FieldErrors = {
        doc_name: {
          type: 'required',
          message: 'Обязательное поле',
        },
      };
      const { container } = render(getFormErrorMessage(errors, 'doc_name'));

      expect(container.textContent).toBe('Обязательное поле');
    });

    it('returns null if field has no error', () => {
      const errors: FieldErrors = {};

      const input = getFormErrorMessage(errors, 'doc_name');

      expect(input).toBeNull();
    });
  });
});
