import dayjs from 'dayjs';

export const isIsoString = (value: string) => {
  if (!/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z/.test(value)) return false;
  const d = new Date(value);
  return !isNaN(d.getTime()) && d.toISOString() === value;
};

export const formatDateToISO = (value: Date | string) => {
  return value && dayjs(value).format('YYYY-MM-DD');
};

export const formatDateToEuropean = (value: Date | string) => {
  return value && dayjs(value).format('DD-MM-YYYY');
};

export const formatDateToRussian = (value: Date | string) => {
  return value && dayjs(value).format('DD.MM.YYYY');
};

export const formatTime = (value: Date | string) => {
  return value && dayjs(value).format('HH:mm:ss');
};
