import { formatDateToRussian, isIsoString } from './date';

export const getFilterValues = <Key extends string>(
  filterValues: Partial<Record<Key, string | Date | null>>,
  labels: Record<string, string | undefined>,
) => {
  return (Object.entries(filterValues) as [Key, string | Date | null][]).map(
    ([key, value]) => {
      let result: { key: Key; value: string } | null = null;

      if (value && isIsoString(value as string)) {
        result = {
          key,
          value: `${labels[key]}: ${formatDateToRussian(value)}`,
        };
      } else if (typeof value === 'string') {
        result = { key, value: `${labels[key]}: ${value}` };
      }

      return result;
    },
  );
};
