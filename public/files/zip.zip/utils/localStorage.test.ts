/**
 * @jest-environment jsdom
 */

import {
  clearLocalStorageOnLogout,
  getItemFromLocalStorage,
  removeItemFromLocalStorage,
  setItemToLocalStorage,
} from './localStorage';

describe('localStorage utility', () => {
  beforeEach(() => {
    localStorage.clear();
    jest.spyOn(Storage.prototype, 'setItem');
    jest.spyOn(Storage.prototype, 'getItem');
    jest.spyOn(Storage.prototype, 'removeItem');
    jest.spyOn(Storage.prototype, 'clear');
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('setItemToLocalStorage', () => {
    it('should set an item to localStorage', () => {
      const key = 'test';
      const value = { name: 'Test' };

      setItemToLocalStorage(key, value);

      expect(localStorage.setItem).toHaveBeenCalledWith(
        key,
        JSON.stringify(value),
      );
      expect(localStorage.getItem(key)).toEqual(JSON.stringify(value));
    });

    it('should handle errors when JSON serialization fails', () => {
      const key = 'test';
      const value = { name: 'Test' };

      jest.spyOn(JSON, 'stringify').mockImplementation(() => {
        throw new Error('Serialization failed');
      });
      setItemToLocalStorage(key, value);

      expect(console.error).toHaveBeenCalledWith(
        'LocalStorage',
        expect.any(Error),
      );
      expect(localStorage.getItem(key)).toBeNull();
    });
  });

  describe('getItemFromLocalStorage', () => {
    it('should get an item from localStorage', () => {
      const key = 'test';
      const value = { name: 'Test' };
      localStorage.setItem(key, JSON.stringify(value));

      const input = getItemFromLocalStorage(key);

      expect(localStorage.getItem).toHaveBeenCalledWith(key);
      expect(input).toEqual(value);
    });

    it('should return null if item does not exist', () => {
      const key = 'non-existent-key';

      const input = getItemFromLocalStorage(key);

      expect(localStorage.getItem).toHaveBeenCalledWith(key);
      expect(input).toBeNull();
    });

    it('should handle errors when JSON parsing fails', () => {
      const key = 'test';
      localStorage.setItem(key, 'invalid-json');

      const input = getItemFromLocalStorage(key);

      expect(console.error).toHaveBeenCalledWith(
        'LocalStorage',
        expect.any(Error),
      );
      expect(input).toBeNull();
    });
  });

  describe('removeItemFromLocalStorage', () => {
    it('should remove an item from localStorage', () => {
      const key = 'test';
      const value = { name: 'Test' };
      localStorage.setItem(key, JSON.stringify(value));

      removeItemFromLocalStorage(key);

      expect(localStorage.removeItem).toHaveBeenCalledWith(key);
      expect(localStorage.getItem(key)).toBeNull();
    });

    it('should handle errors when removing item fails', () => {
      const key = 'test';
      const value = { name: 'Test' };
      localStorage.setItem(key, JSON.stringify(value));

      jest.spyOn(Storage.prototype, 'removeItem').mockImplementation(() => {
        throw new Error('Remove failed');
      });
      removeItemFromLocalStorage(key);

      expect(console.error).toHaveBeenCalledWith(
        'LocalStorage',
        expect.any(Error),
      );
      expect(localStorage.getItem(key)).toEqual(JSON.stringify(value));
    });
  });

  describe('clearLocalStorageOnLogout', () => {
    it('should clear localStorage', () => {
      localStorage.setItem('key1', 'value1');
      localStorage.setItem('key2', 'value2');

      clearLocalStorageOnLogout();

      expect(localStorage.clear).toHaveBeenCalled();
      expect(localStorage.getItem('key1')).toBeNull();
      expect(localStorage.getItem('key2')).toBeNull();
    });
  });
});
