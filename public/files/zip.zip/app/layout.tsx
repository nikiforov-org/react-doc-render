'use client';

import { PrimeReactProvider } from 'primereact/api';
import "./tailwind.css";
import { Roboto } from "next/font/google";
import '../primereact-sass-theme-main/themes/lara/lara-light/cyan/theme.scss';
import 'primeicons/primeicons.css';
import { Provider as ReduxToolkitProvider } from 'react-redux';
import { makeStore } from '@/store/store';

import AuthWrapper from "@/components/AuthWrapper";
import { MetaData } from '@/components/MetaData';
import { ToastProvider } from '@/utils/formMessages';

const roboto = Roboto({
  subsets: ['cyrillic-ext'],
  weight: ['100', '300', '400', '500', '700', '900'],
  variable: '--font-family',
});

const store = makeStore();

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <>
      <html lang="ru">
        <head>
          <link rel="icon" href="/favicon.ico" />
          <title>R-chive - электронный архив документов</title>
          <meta name="description" content="Электронный Архив Документов 4.0" />
        </head>
        <body className={`${roboto.className} ${roboto.variable}`}>
          <ReduxToolkitProvider store={store}>
            <ToastProvider>
              <AuthWrapper>
                <MetaData>
                  <PrimeReactProvider value={{ locale: 'ru' }}>
                    {children}
                  </PrimeReactProvider>
                </MetaData>
              </AuthWrapper>
            </ToastProvider>
          </ReduxToolkitProvider>
        </body>
      </html>
    </>
  );
}
