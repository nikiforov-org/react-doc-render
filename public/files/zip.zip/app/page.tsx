import AppRouter from '@/components/AppRouter';

export default function Page() {
  return <AppRouter />;
}
