'use client';
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { TabPanel, TabView } from 'primereact/tabview';
import {
  INDIVIDUAL,
  LEGAL_ENTITY,
  individualTableColumn,
  legalTableColumn,
} from '@/app/pages/clients/constants';
import Drawer from '@/components/Drawer';
import Form from '@/app/pages/clients/components/Form';
import ClientsTable from '@/app/pages/clients/components/ClientsTable';
import { getFilteredObjectTypes } from '@/utils/getFilteredObjectTypes';
import { useMetadata } from '@/components/MetaData';

const ClientsPage = () => {
  const { loadingMetadata, getMetadata } = useMetadata();
  const [formVisible, setFormVisible] = useState(false);
  const [objectTypes, setObjectTypes] = useState<string[]>([]);

  const searchParams = useSearchParams();

  const formAction = () => {
    setFormVisible((prev) => !prev);
  };

  useEffect(() => {
    const isFormOpen = searchParams.get('open');
    isFormOpen && setFormVisible(true);
  }, []);

  useEffect(() => {
    if (!loadingMetadata) {
      const objectTypesData = getMetadata('objectTypes');
      if (objectTypesData) {
        const filteredObjectTypes = getFilteredObjectTypes(objectTypesData);
        setObjectTypes(filteredObjectTypes);
      }
    }
  }, [loadingMetadata, getMetadata]);

  return (
    <>
      <TabView
        pt={{
          root: { className: 'flex-1 flex flex-col items-start' },
          panelContainer: {
            className: 'w-full h-full flex-1 px-0 pt-4 pb-0 flex flex-col',
          },
          nav: { className: 'border-b' },
          navContent: { className: '-mt-4' },
        }}
      >
        <TabPanel
          header="Физические лица"
          pt={{
            root: { className: 'flex-1 flex flex-col' },
            headerTitle: { className: 'font-medium' },
          }}
        >
          <ClientsTable
            type={INDIVIDUAL}
            column={individualTableColumn}
            formAction={formAction}
            objectTypes={objectTypes}
          />
        </TabPanel>

        <TabPanel
          header="Юридические лица"
          pt={{ headerTitle: { className: 'font-medium' } }}
        >
          <ClientsTable
            type={LEGAL_ENTITY}
            column={legalTableColumn}
            formAction={formAction}
            objectTypes={objectTypes}
          />
        </TabPanel>
      </TabView>

      {formVisible && (
        <Drawer
          header="Добавить клиента"
          formVisible={formVisible}
          onHide={formAction}
        >
          <Form onHide={formAction} />
        </Drawer>
      )}
    </>
  );
};

export default ClientsPage;
