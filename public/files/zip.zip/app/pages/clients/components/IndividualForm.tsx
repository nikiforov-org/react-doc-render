import { useForm } from 'react-hook-form';
import { Button } from 'primereact/button';
import {
  FormProps,
  IndividualFormValues,
} from '@/app/pages/clients/types';
import { formStyle, individualFormValues } from '@/app/pages/clients/constants';
import { FormField } from '@/components/FormField';
import { useMetadata } from '@/components/MetaData';
import { useContext } from 'react';
import { ToastContext } from '@/utils/formMessages';

const IndividualForm = ({ onHide }: FormProps) => {
  const { getMetadata } = useMetadata();
  const fieldsMetadata = getMetadata(
    'objectTypeMap.individual_clients.fieldMap',
  );

  const { showToast } = useContext(ToastContext);

  const {
    control,
    formState: { errors, dirtyFields: _dirtyFieldsEventSubscription },
    handleSubmit,
    reset,
    getValues,
    setValue,
  } = useForm<IndividualFormValues>({ defaultValues: individualFormValues });
  const formValues = getValues();
  const isFormDisabled = !Object.entries(formValues).every(
    ([key, value]) =>
      (fieldsMetadata?.[key]?.nullable ?? true) || Boolean(value),
  );

  const generateId = () => {
    return Math.floor(10000000 + Math.random() * 90000000).toString();
  };

  const createIndividualClient = async (data: IndividualFormValues) => {
    const id = generateId();

    const dataCopy = {
      ...data,
      status: 'Активный',
    };

    try {
      await fetch(
        `${process.env.NEXT_PUBLIC_APP_API}/dictionary-records/individual_clients/${id}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(dataCopy),
        },
      );
    } catch (e) {}
  };

  const onSubmit = (data: IndividualFormValues) => {
    void createIndividualClient(data);
    showToast('success', 'Клиент успешно создан!');
    reset();
    onHide();
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="p-fluid pt-8 h-full flex flex-col justify-between"
    >
      <div className={formStyle.container}>
        <FormField<IndividualFormValues>
          name="last_name"
          label="Фамилия"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="first_name"
          label="Имя"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="patronymic"
          label="Отчество"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="inn"
          label="ИНН"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="ident_doc_type"
          label="Тип ДУЛ"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="ident_doc_series"
          label="Серия ДУЛ"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="ident_doc_number"
          label="Номер ДУЛ"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="ident_doc_begin_date"
          label="Дата выдачи"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="birth_date"
          label="Дата рождения"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<IndividualFormValues>
          name="birth_region"
          label="Место рождения клиента"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
      </div>

      <div className="flex justify-between border-t mt-5 p-5">
        <Button className="w-fit" type="submit" disabled={isFormDisabled}>
          Добавить
        </Button>
        <Button className="w-fit" text type="button" onClick={onHide}>
          Отменить
        </Button>
      </div>
    </form>
  );
};

export default IndividualForm;
