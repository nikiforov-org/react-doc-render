'use client';
import React, { useEffect, useState } from 'react';
import { Button } from 'primereact/button';
import SearchInput from '@/components/SearchInput';
import {
  ClientsTableProps,
  FilterFormValues,
  ClientTableData,
  ClientTableColumn,
  TransformedTableData,
} from '@/app/pages/clients/types';
import {
  CLIENT_FILTER_KEY,
  INDIVIDUAL,
  initialFilterValues,
  SEARCH_INDIVIDUAL_KEY,
  SEARCH_LEGAL_KEY,
} from '@/app/pages/clients/constants';
import Drawer from '@/components/Drawer';
import Filter from '@/app/pages/clients/components/Filter';
import { Badge } from 'primereact/badge';
import { DataTable, DataTableSelectEvent } from 'primereact/datatable';
import { useNavigate } from 'react-router-dom';
import { Column } from 'primereact/column';
import EmptyList from '@/components/EmptyList';
import { Chip } from 'primereact/chip';
import { FormProvider, useForm } from 'react-hook-form';
import { IndividualClient, IndividualClientProperties } from '@/types';
import { getFilterValues } from '@/utils/getFiltersValue';
import {
  getItemFromLocalStorage,
  setItemToLocalStorage,
} from '@/utils/localStorage';
import { findClientByFilter } from '@/app/pages/clients/services';
import { formatDateToRussian } from '@/utils/date';
import { classNames } from 'primereact/utils';
import { Spinner } from '@/components/Spinner';
import InfiniteScrollWrapper from '@/components/InfiniteScrollWrapper';

type FilterKeys = keyof FilterFormValues;
const filterLabels: Record<FilterKeys, string> = {
  ident_doc_type: 'Тип ДУЛ',
  ident_doc_begin_date: 'Дата выдачи',
  birth_date: 'Дата рождения',
};

const ClientsTable = ({
  type,
  formAction,
  column,
  objectTypes,
}: ClientsTableProps) => {
  const [formVisible, setFormVisible] = useState(false);
  const [searchValue, setSearchValue] = useState<string>('');
  const [clientData, setClientData] = useState<ClientTableData[] | []>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const navigate = useNavigate();

  const isIndividual = type === INDIVIDUAL;

  const savedFilters = getItemFromLocalStorage(CLIENT_FILTER_KEY);
  let chipsValues: Partial<FilterFormValues> | null = null;
  if (savedFilters) {
    chipsValues = Object.fromEntries(
      Object.entries(savedFilters).filter(
        ([key, value]) =>
          Object.hasOwn(initialFilterValues, key) &&
          (value instanceof Date || typeof value === 'string'),
      ),
    ) as Partial<FilterFormValues>;
  }
  const storageFilterValues: FilterFormValues = {
    ...initialFilterValues,
    ...(chipsValues ?? {}),
  };
  const methods = useForm<FilterFormValues>({
    defaultValues: storageFilterValues,
    mode: 'all',
  });

  const filterChipsValues = chipsValues
    ? getFilterValues<FilterKeys>(chipsValues, filterLabels)
    : [];

  const hasAnyFilter =
    chipsValues &&
    Object.values(chipsValues)?.some((element) => Boolean(element));

  const formActionFilter = () => {
    setFormVisible((prev) => !prev);
  };

  const onRowSelect = (e: DataTableSelectEvent) => {
    e.data.id && navigate(`/clients/${e.data.id}`);
  };

  const handleClientData = async (
    newSearchValue?: string,
    currentOffset?: number,
    type?: string,
  ) => {
    const data = methods.getValues();

    try {
      const objectType = isIndividual ? 'individual_clients' : 'legal_clients';

      if (!currentOffset) {
        setClientData([]);
        setIsLoading(true);
      }

      const clients = await findClientByFilter(
        isIndividual,
        data,
        objectType,
        newSearchValue ?? searchValue,
        currentOffset ?? offset,
      );

      const clientTableData = await clients.json();

      if (type === 'add') {
        setClientData((prev) => [...prev, ...clientTableData]);
        setHasMore(clientTableData.length > 0);
      } else {
        setClientData(clientTableData);
        setOffset(0);
        setHasMore(clientTableData.length >= 30);
      }
    } catch (error) {}

    setIsLoading(false);
  };

  const searchButtonClick = (newSearchValue: string) => {
    const data = methods.getValues();
    setItemToLocalStorage(CLIENT_FILTER_KEY, data);
    void handleClientData(newSearchValue, 0);

    setSearchValue(newSearchValue);
    const storageKey = isIndividual ? SEARCH_INDIVIDUAL_KEY : SEARCH_LEGAL_KEY;
    setItemToLocalStorage(storageKey, newSearchValue);
  };

  useEffect(() => {
    const savedIndividualValue = getItemFromLocalStorage(SEARCH_INDIVIDUAL_KEY);
    const savedLegalValue = getItemFromLocalStorage(SEARCH_LEGAL_KEY);
    const clientValue = isIndividual ? savedIndividualValue : savedLegalValue;

    const shouldSearch =
      (hasAnyFilter && isIndividual) || savedIndividualValue || savedLegalValue;

    if (shouldSearch) {
      void handleClientData(clientValue, 0);
    }
  }, [objectTypes]);

  useEffect(() => {
    const key = isIndividual ? SEARCH_INDIVIDUAL_KEY : SEARCH_LEGAL_KEY;
    const savedSearchValue = getItemFromLocalStorage(key);

    if (savedSearchValue) {
      setSearchValue(savedSearchValue);
    }
  }, [isIndividual]);

  const onFilterValueReset = (key: FilterKeys) => {
    const data = methods.getValues();
    methods.resetField(key);

    if (data.hasOwnProperty(key)) data[key] = null;

    methods.setValue(key, null, { shouldDirty: true });
    setItemToLocalStorage(CLIENT_FILTER_KEY, data);
    void handleClientData();
  };

  const transformedClientData = clientData?.map((item) => ({
    ...item,
    ...item.properties,
    properties: undefined,
  }));

  const template = (
    data: Omit<IndividualClient, 'properties'> & IndividualClientProperties,
    col: ClientTableColumn,
  ) => {
    if (col.field === 'fio')
      return (
        <p>
          {data.last_name} {data.first_name} {data.patronymic}
        </p>
      );

    if (col.field === 'birth_date')
      return <p>{formatDateToRussian(data.birth_date)}</p>;
  };

  const infiniteScrollNext = () => {
    if (transformedClientData?.length > 0) {
      void handleClientData('', offset + 30, 'add');
      setOffset((prev) => prev + 30);
    }
  };

  return (
    <>
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <SearchInput
              search={searchValue}
              setSearch={setSearchValue}
              onSearch={searchButtonClick}
              className="min-w-100"
              placeholder={
                isIndividual
                  ? 'ФИО, ИНН, серия и номер ДУЛ'
                  : 'Наименование организации, ИНН, КПП'
              }
            />

            {isIndividual && (
              <Button
                className="p-overlay-badge overflow-visible"
                type="button"
                outlined
                onClick={formActionFilter}
              >
                Фильтр {hasAnyFilter && <Badge severity="danger" />}
              </Button>
            )}
          </div>
          <Button label="Добавить клиента" onClick={formAction} />
        </div>

        {isIndividual &&
        filterChipsValues?.length &&
        filterChipsValues.some((chip) => Boolean(chip)) ? (
          <div className="flex gap-2">
            {filterChipsValues?.map(
              (chip) =>
                chip && (
                  <Chip
                    key={chip.key}
                    label={chip.value}
                    removable
                    onRemove={() => onFilterValueReset(chip.key)}
                  />
                ),
            )}
          </div>
        ) : null}

        <InfiniteScrollWrapper<TransformedTableData>
          data={transformedClientData}
          hasMore={hasMore}
          endMessage="Вы просмотрели все данные"
          onNextChange={infiniteScrollNext}
        >
          <DataTable
            value={transformedClientData}
            scrollable
            selectionMode="single"
            onRowSelect={onRowSelect}
            dataKey="id"
            pt={{
              root: {
                className: classNames({
                  ['pb-2']: transformedClientData?.length,
                }),
              },
              column: {
                headerCell: {
                  className: classNames({ 'opacity-40': isLoading }),
                },
                bodyCell: {
                  className: classNames({
                    ['border-none p-0']:
                      !transformedClientData?.length || isLoading,
                  }),
                },
              },
            }}
            emptyMessage=" "
          >
            {column?.map((col, index) => (
              <Column
                key={index}
                field={col.field}
                header={col.header}
                style={{ minWidth: col.width }}
                body={col.body ? (data) => template(data, col) : undefined}
              />
            ))}
          </DataTable>
        </InfiniteScrollWrapper>
      </div>

      {isLoading ? <Spinner /> : null}

      {!transformedClientData?.length && !isLoading ? (
        <EmptyList
          title="Нет данных для отображения"
          message="Воспользуйтесь поисковой строкой и введите данные для поиска по клиентам"
        />
      ) : null}

      {formVisible && (
        <Drawer
          header="Параметры поиска"
          formVisible={formVisible}
          onHide={formActionFilter}
        >
          <FormProvider {...methods}>
            <Filter findClient={handleClientData} onHide={formActionFilter} />
          </FormProvider>
        </Drawer>
      )}
    </>
  );
};

export default ClientsTable;
