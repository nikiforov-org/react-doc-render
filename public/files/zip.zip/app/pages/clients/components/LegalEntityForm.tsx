import { useForm } from 'react-hook-form';
import { Button } from 'primereact/button';
import { FormProps, LegalFormValues } from '@/app/pages/clients/types';
import { formStyle, legalFormValues } from '@/app/pages/clients/constants';
import { useMetadata } from '@/components/MetaData';
import { FormField } from '@/components/FormField';
import { useContext } from 'react';
import { ToastContext } from '@/utils/formMessages';

const LegalEntityForm = ({ onHide }: FormProps) => {
  const { getMetadata } = useMetadata();
  const fieldsMetadata = getMetadata('objectTypeMap.legal_clients.fieldMap');

  const { showToast } = useContext(ToastContext);

  const {
    control,
    formState: { errors, dirtyFields: _dirtyFieldsEventSubscription },
    handleSubmit,
    reset,
    getValues,
    setValue,
  } = useForm<LegalFormValues>({ defaultValues: legalFormValues });
  const formValues = getValues();
  const isFormDisabled = !Object.entries(formValues).every(
    ([key, value]) =>
      (fieldsMetadata?.[key]?.nullable ?? true) || Boolean(value),
  );

  const generateId = () => {
    return Math.floor(10000000 + Math.random() * 90000000).toString();
  };

  const createLegalClient = async (data: LegalFormValues) => {
    const id = generateId();

    const dataCopy = {
      ...data,
      status: 'Активный',
    };

    try {
      await fetch(
        `${process.env.NEXT_PUBLIC_APP_API}/dictionary-records/legal_clients/${id}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(dataCopy),
        },
      );
    } catch (e) {}
  };

  const onSubmit = (data: LegalFormValues) => {
    void createLegalClient(data);
    showToast('success', 'Клиент успешно создан!');
    reset();
    onHide();
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="p-fluid pt-8 h-full flex flex-col justify-between"
    >
      <div className={formStyle.container}>
        <FormField<LegalFormValues>
          name="name"
          label="Полное наименование организации"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<LegalFormValues>
          name="short_name"
          label="Наименование организации"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<LegalFormValues>
          name="inn"
          label="ИНН"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<LegalFormValues>
          name="ogrn"
          label="ОГРН"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<LegalFormValues>
          name="kio"
          label="КИО"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
        <FormField<LegalFormValues>
          name="kpp"
          label="КПП"
          fieldsMetadata={fieldsMetadata}
          control={control}
          setValue={setValue}
          errors={errors}
        />
      </div>

      <div className="flex justify-between border-t mt-5 p-5">
        <Button className="w-fit" type="submit" disabled={isFormDisabled}>
          Добавить
        </Button>
        <Button className="w-fit" text type="button" onClick={onHide}>
          Отменить
        </Button>
      </div>
    </form>
  );
};

export default LegalEntityForm;
