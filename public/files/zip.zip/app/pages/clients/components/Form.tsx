'use client';
import React, { useState } from 'react';
import { RadioButton, RadioButtonChangeEvent } from 'primereact/radiobutton';
import IndividualForm from '@/app/pages/clients/components/IndividualForm';
import LegalEntityForm from '@/app/pages/clients/components/LegalEntityForm';
import { INDIVIDUAL, LEGAL_ENTITY } from '@/app/pages/clients/constants';
import { FormProps } from '@/app/pages/clients/types';

const Form = ({ onHide }: FormProps) => {
  const [clientRole, setClientRole] = useState(INDIVIDUAL);
  const isIndividual = clientRole === INDIVIDUAL;

  const handleRoleChange = (e: RadioButtonChangeEvent) => {
    setClientRole(e.value);
  };

  return (
    <div className="h-full flex flex-col pt-3">
      <div className="px-5 flex flex-wrap gap-6">
        <div className="flex items-center">
          <RadioButton
            inputId={INDIVIDUAL}
            value={INDIVIDUAL}
            onChange={handleRoleChange}
            checked={clientRole === INDIVIDUAL}
          />
          <label htmlFor={INDIVIDUAL} className="ml-2">
            {INDIVIDUAL}
          </label>
        </div>
        <div className="flex items-center">
          <RadioButton
            inputId={LEGAL_ENTITY}
            value={LEGAL_ENTITY}
            onChange={handleRoleChange}
            checked={clientRole === LEGAL_ENTITY}
          />
          <label htmlFor={LEGAL_ENTITY} className="ml-2">
            {LEGAL_ENTITY}
          </label>
        </div>
      </div>

      <div className="w-full flex-1">
        {isIndividual ? (
          <IndividualForm onHide={onHide} />
        ) : (
          <LegalEntityForm onHide={onHide} />
        )}
      </div>
    </div>
  );
};

export default Form;
