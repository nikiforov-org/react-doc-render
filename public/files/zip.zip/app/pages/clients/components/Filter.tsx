import { useFormContext } from 'react-hook-form';
import { Button } from 'primereact/button';
import { formStyle } from '@/app/pages/clients/constants';
import { FilterFormValues } from '@/app/pages/clients/types';
import { setItemToLocalStorage } from '@/utils/localStorage';
import { useMetadata } from '@/components/MetaData';
import { FormField } from '@/components/FormField';

interface FilterProps {
  onHide: () => void;
  findClient: () => void;
}

const Filter = ({ findClient, onHide }: FilterProps) => {
  const { getMetadata } = useMetadata();
  const fieldsMetadata = getMetadata(
    'objectTypeMap.individual_clients.fieldMap',
  );

  const {
    control,
    formState: { errors },
    handleSubmit,
    setValue,
  } = useFormContext<FilterFormValues>();

  const onSubmit = (data: FilterFormValues) => {
    findClient();
    setItemToLocalStorage('clientFilterValues', data);
    onHide();
  };

  return (
    <div className="flex flex-col w-full h-full pt-3">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-fluid mt-2 h-full flex flex-col justify-between"
      >
        <div className={formStyle.container}>
          <FormField<FilterFormValues>
            name="ident_doc_type"
            label="Тип ДУЛ"
            isFilter
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<FilterFormValues>
            name="ident_doc_begin_date"
            label="Дата выдачи"
            isFilter
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<FilterFormValues>
            name="birth_date"
            label="Дата рождения"
            isFilter
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
        </div>

        <div className="flex justify-between border-t mt-5 p-5">
          <Button className="w-fit" type="submit">
            Применить фильтр
          </Button>
          <Button className="w-fit" text type="button" onClick={onHide}>
            Отменить
          </Button>
        </div>
      </form>
    </div>
  );
};

export default Filter;
