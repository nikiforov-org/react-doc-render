import { formatDateToISO } from '@/utils/date';
import { FilterFormValues } from './types';

export const findClientByFilter = async (
  isIndividual: boolean,
  data: FilterFormValues,
  objectType: string,
  searchValue: string,
  offset: number = 0,
) => {
  const body = {
    query: {
      bool: {
        must: [
          ...(isIndividual
            ? [
                data.ident_doc_type && {
                  match: {
                    ident_doc_type: data.ident_doc_type,
                  },
                },
                data.ident_doc_begin_date && {
                  term: {
                    ident_doc_begin_date: formatDateToISO(
                      data.ident_doc_begin_date,
                    ),
                  },
                },
                data.birth_date && {
                  term: {
                    birth_date: formatDateToISO(data.birth_date),
                  },
                },
              ]
            : []),
          searchValue && {
            query_string: {
              query: `*${searchValue}*`,
              fields: isIndividual
                ? [
                    'first_name',
                    'last_name',
                    'patronymic',
                    'inn',
                    'ident_doc_number',
                    'ident_doc_series',
                  ]
                : ['name', 'short_name', 'inn', 'kpp'],
              type: 'phrase_prefix',
              default_operator: 'and',
            },
          },
        ].filter(Boolean),
      },
    },
    offset: offset,
    limit: 30,
    // sortOrderList: [
    //   {
    //     fieldName: "last_name",
    //     sortOrder: "Asc"
    //   }
    // ],
    dictionaryNames: [objectType],
  };

  return await fetch(`${process.env.NEXT_PUBLIC_APP_API}/search-dictionary`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
};
