import { createAppSlice } from '@/store/createAppSlice';

const slice = createAppSlice({
  name: 'clients',
  initialState: { selectedClient: null },
  reducers: {
    selectClient: (state, action) => {
      state.selectedClient = action.payload;
    },
  },
});

export const { selectClient } = slice.actions;
export default slice.reducer;
