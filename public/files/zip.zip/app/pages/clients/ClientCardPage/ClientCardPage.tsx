'use client';

import React, {
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import dayjs from 'dayjs';
import FilesPanel from './components/FilesPanel';
import FoldersTree from './components/FoldersTree';
import Drawer from '@/components/Drawer';
import UploadForm from './components/UploadForm';
import { useMetadata } from '@/components/MetaData';
import {
  ClientDocumentWithProperties,
  IndividualClientWithProperties,
  LegalClientWithProperties,
  ClientFolderWithProperties,
  TreeFolderNode,
} from './types';
import {
  ClientDocument,
  ClientFolder,
  IndividualClient,
  LegalClient,
} from '@/types';
import { getFilteredObjectTypes } from '@/utils/getFilteredObjectTypes';
import { formatDateToRussian } from '@/utils/date';
import {
  INDIVIDUAL_CLIENT_OBJECT_TYPE,
  LEGAL_CLIENT_OBJECT_TYPE,
} from './constants';
import { useParams } from 'react-router-dom';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { selectDocument } from '@/app/pages/documents/slice';
import FolderForm from './components/FolderForm';
import { ToastContext } from '@/utils/formMessages';

export function getFormattedDate(date: string | undefined) {
  return date ? formatDateToRussian(date) : '';
}

function transformDocument(item: ClientDocument) {
  return {
    ...item,
    ...item.properties,
    invalid: !item.properties.is_actual,
    expired: item.properties.validity
      ? dayjs().isAfter(dayjs(item.properties.validity).endOf('day'))
      : false,
    formattedCreationDate: getFormattedDate(
      item.properties.system_creation_date,
    ),
    formattedValidity: getFormattedDate(item.properties.validity),
  };
}

export function isIndividualClient(
  client: IndividualClient | LegalClient,
): client is IndividualClient {
  return client.objectType === INDIVIDUAL_CLIENT_OBJECT_TYPE;
}

export function isLegalClient(
  client: IndividualClient | LegalClient,
): client is LegalClient {
  return client.objectType === LEGAL_CLIENT_OBJECT_TYPE;
}

export default function ClientCardPage() {
  const { id } = useParams();
  const { showToast } = useContext(ToastContext);
  const [fileDrawerVisible, setFileDrawerVisible] = useState(false);
  const [folderDrawerVisible, setFolderDrawerVisible] = useState(false);
  const [lastUpdatedItemType, setLastUpdatedItemType] = useState<
    'document' | 'folder' | null
  >(null);

  const { selectedDocumentID } = useAppSelector((state) => state.documents);
  const dispatch = useAppDispatch();

  const { loadingMetadata, getMetadata } = useMetadata();
  const [objectTypes, setObjectTypes] = useState<string[]>([]);

  const [client, setClient] = useState<IndividualClient | LegalClient | null>(
    null,
  );
  const [isClientLoading, setIsClientLoading] = useState(true);
  const [files, setFiles] = useState<ClientDocument[]>([]);
  const [clientFolders, setClientFolders] = useState<ClientFolder[]>([]);
  const [areFilesAndFoldersLoading, setAreFilesAndFoldersLoading] =
    useState(true);
  const [nodes, setNodes] = useState<TreeFolderNode[]>([]);
  const [selectedFolder, setSelectedFolder] = useState<TreeFolderNode | null>(
    null,
  );
  const [selectedFile, setSelectedFile] =
    useState<ClientDocumentWithProperties | null>(null);

  const fetchClientInfo = useCallback(async () => {
    try {
      setIsClientLoading(true);
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_APP_API}/search-dictionary`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            query: {
              bool: {
                must: [
                  {
                    term: {
                      _id: id,
                    },
                  },
                ],
              },
            },
            dictionaryNames: ['individual_clients', 'legal_clients'],
          }),
        },
      );
      const data = await response.json();
      if (!Array.isArray(data) || !data.length) {
        throw new Error('Клиент не найден');
      }
      setClient(data[0]);
      setIsClientLoading(false);
    } catch (error) {
      showToast('error', 'Ошибка при загрузке информации о клиенте');
    }
  }, [id]);

  const fetchClientDocumentsAndFolders = useCallback(async () => {
    if (client) {
      try {
        setAreFilesAndFoldersLoading(true);
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/search-objects`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              query: {
                bool: {
                  should: [
                    {
                      match: {
                        client_inn: client.properties.inn,
                      },
                    },
                    {
                      match: {
                        client_id: id,
                      },
                    },
                  ],
                },
              },
              sortOrderList: [
                {
                  fieldName: 'system_key',
                  sortOrder: 'Asc',
                },
              ],
              objectType: objectTypes,
            }),
          },
        );
        const data = await response.json();
        const fileList: ClientDocument[] = [];
        const clientFolderList: ClientFolder[] = [];
        data.forEach((el: ClientDocument | ClientFolder) => {
          if (el.properties.system_object_role === 'file') {
            fileList.push(el as ClientDocument);
          } else if (el.properties.system_object_role === 'folder') {
            clientFolderList.push(el as ClientFolder);
          }
        });
        setFiles(fileList);

        if (selectedFile) {
          // update selected file after adding/editing/deleting document
          const updatedSelectedFile = fileList.find(
            (file) => file.id === selectedFile.id,
          );
          setSelectedFile(
            updatedSelectedFile ? transformDocument(updatedSelectedFile) : null,
          );
        }

        setClientFolders(clientFolderList);
        setAreFilesAndFoldersLoading(false);
      } catch (error) {
        showToast('error', 'Ошибка при загрузке документов клиента');
      }
    }
  }, [id, objectTypes, client, selectedFile]);

  useEffect(() => {
    if (!loadingMetadata) {
      const objectTypesData = getMetadata('objectTypes');
      if (objectTypesData) {
        const filteredObjectTypes = getFilteredObjectTypes(objectTypesData);
        setObjectTypes(filteredObjectTypes);
      }
    }
  }, [loadingMetadata, getMetadata]);

  useEffect(() => {
    fetchClientInfo();
  }, []);

  useEffect(() => {
    if (client && !!objectTypes.length) {
      fetchClientDocumentsAndFolders();
    }
  }, [objectTypes, client]);

  const clientInfo:
    | IndividualClientWithProperties
    | LegalClientWithProperties
    | null = useMemo(() => {
    if (client) {
      if (isIndividualClient(client)) {
        return {
          ...client,
          ...client.properties,
          fio: [
            client.properties.last_name,
            client.properties.first_name,
            client.properties.patronymic,
          ].join(' '),
          formattedIdentDocBeginDate: getFormattedDate(
            client.properties.ident_doc_begin_date,
          ),
          formattedBirthDate: getFormattedDate(client.properties.birth_date),
          formattedCreatedDate: getFormattedDate(
            client.properties.system_creation_date,
          ),
        };
      } else if (isLegalClient(client)) {
        return {
          ...client,
          ...client.properties,
          formattedCreatedDate: getFormattedDate(
            client.properties.system_creation_date,
          ),
        };
      }
    }
    return null;
  }, [client]);

  const clientName = useMemo(() => {
    if (client && clientInfo) {
      if (isIndividualClient(client)) {
        return (clientInfo as IndividualClientWithProperties).fio;
      } else if (isLegalClient(client)) {
        return (clientInfo as LegalClientWithProperties).name;
      }
    }
    return '';
  }, [client, clientInfo]);

  const fileList: ClientDocumentWithProperties[] = useMemo(() => {
    return files.map((file) => transformDocument(file));
  }, [files]);

  useEffect(() => {
    // set the document that was selected in the documents section or that was created in the upload form
    if (selectedDocumentID) {
      const file = fileList.find((el) => el.id === selectedDocumentID);
      if (file) {
        setSelectedFile(file);
        dispatch(selectDocument(null));
      }
    }
  }, [selectedDocumentID, fileList]);

  const clientFolderList: ClientFolderWithProperties[] = useMemo(() => {
    return clientFolders.map((folder) => ({
      ...folder,
      ...folder.properties,
      isActual: folder.properties.is_actual ? 'Да' : 'Нет',
    }));
  }, [clientFolders]);

  return (
    <div className="flex h-[calc(100vh-104px)]">
      <FoldersTree
        clientName={clientName}
        files={fileList}
        isLoading={isClientLoading || areFilesAndFoldersLoading}
        nodes={nodes}
        selectedFolder={selectedFolder}
        selectedFile={selectedFile}
        clientFolders={clientFolderList}
        setNodes={setNodes}
        setSelectedFolder={setSelectedFolder}
        setSelectedFile={setSelectedFile}
      />
      <FilesPanel
        clientInfo={clientInfo}
        isClientLoading={isClientLoading}
        files={selectedFolder ? selectedFolder.files : fileList}
        areFilesLoading={areFilesAndFoldersLoading}
        selectedFolder={selectedFolder}
        selectedFile={selectedFile}
        lastUpdatedItemType={lastUpdatedItemType}
        setSelectedFile={setSelectedFile}
        setLastUpdatedItemType={setLastUpdatedItemType}
        refreshList={fetchClientDocumentsAndFolders}
        setFileDrawerVisible={setFileDrawerVisible}
        setFolderDrawerVisible={setFolderDrawerVisible}
      />
      <Drawer
        formVisible={fileDrawerVisible}
        onHide={() => setFileDrawerVisible(false)}
        header={selectedFile ? 'Редактирование документа' : 'Загрузка файла'}
      >
        <div className="w-full h-full pt-3">
          <UploadForm
            selectedFolder={selectedFolder}
            selectedFile={selectedFile}
            clientInfo={clientInfo!}
            folders={!!nodes.length ? nodes[0].children : []}
            refreshList={fetchClientDocumentsAndFolders}
            onCreatingCallback={(id: string) => dispatch(selectDocument(id))}
            onHide={() => setFileDrawerVisible(false)}
            onSuccess={() => setLastUpdatedItemType('document')}
          />
        </div>
      </Drawer>
      <Drawer
        formVisible={folderDrawerVisible}
        onHide={() => setFolderDrawerVisible(false)}
        header={
          selectedFolder && selectedFolder.type === 'client'
            ? 'Редактирование договора'
            : ''
        }
      >
        <div className="w-full h-full pt-3">
          <FolderForm
            selectedFolderInfo={selectedFolder ? selectedFolder.info : null}
            clientInfo={clientInfo!}
            refreshList={fetchClientDocumentsAndFolders}
            onHide={() => setFolderDrawerVisible(false)}
            onSuccess={() => setLastUpdatedItemType('folder')}
          />
        </div>
      </Drawer>
    </div>
  );
}
