import React from 'react';
import { InputSwitch } from 'primereact/inputswitch';
import SearchInput from '@/components/SearchInput';
import {
  DataTableFilterMeta,
  DataTableFilterMetaData,
} from 'primereact/datatable';

const inputSwitchStyles = {
  root: { className: 'h-[14px] w-[26px] leading-[14px]' },
  input: { className: 'peer' },
  slider: {
    className:
      'rounded-[20px] before:mt-0 before:top-[1px] before:left-[1px] before:w-[10px] before:h-[10px] peer-checked:before:translate-x-[12px]',
  },
};

interface FilesListFilterProps {
  filters: DataTableFilterMeta;
  setFilters: React.Dispatch<React.SetStateAction<DataTableFilterMeta>>;
  nameFilterValue: string;
  setNameFilterValue: React.Dispatch<React.SetStateAction<string>>;
  invalidFilterValue: boolean | null;
  setInvalidFilterValue: React.Dispatch<React.SetStateAction<boolean | null>>;
  expiredFilterValue: boolean | null;
  setExpiredFilterValue: React.Dispatch<React.SetStateAction<boolean | null>>;
  filterCallback: () => void;
}

const FilesListFilter: React.FC<FilesListFilterProps> = ({
  filters,
  setFilters,
  nameFilterValue,
  setNameFilterValue,
  invalidFilterValue,
  setInvalidFilterValue,
  expiredFilterValue,
  setExpiredFilterValue,
  filterCallback,
}) => {
  const onNameFilterChange = (value: string) => {
    const _filters = { ...filters };

    (_filters['doc_name'] as DataTableFilterMetaData).value = value.trim();

    setFilters(_filters);
    setNameFilterValue(value);

    filterCallback();
  };

  const onInvalidFilterChange = (e: { value: boolean }) => {
    const value = e.value;
    const _filters = { ...filters };

    (_filters['invalid'] as DataTableFilterMetaData).value = value
      ? value
      : null;

    setFilters(_filters);
    setInvalidFilterValue(value);

    filterCallback();
  };

  const onExpiredFilterChange = (e: { value: boolean }) => {
    const value = e.value;
    const _filters = { ...filters };

    (_filters['expired'] as DataTableFilterMetaData).value = value
      ? value
      : null;

    setFilters(_filters);
    setExpiredFilterValue(value);

    filterCallback();
  };

  return (
    <>
      <SearchInput
        search={nameFilterValue}
        setSearch={onNameFilterChange}
        placeholder="Поиск по документам"
        className=" min-w-[300px]"
      />
      <div className="flex items-center ml-6">
        <InputSwitch
          checked={invalidFilterValue ?? false}
          onChange={onInvalidFilterChange}
          inputId="invalidFilter"
          pt={inputSwitchStyles}
        />
        <label
          htmlFor="invalidFilter"
          className="font-sm text-surface-800 cursor-pointer ml-3"
        >
          Недействительные
        </label>
      </div>
      <div className="flex items-center ml-6">
        <InputSwitch
          checked={expiredFilterValue ?? false}
          onChange={onExpiredFilterChange}
          inputId="expiredFilter"
          pt={inputSwitchStyles}
        />
        <label
          htmlFor="expiredFilter"
          className="font-sm text-surface-800 cursor-pointer ml-3"
        >
          Истёк срок годности
        </label>
      </div>
    </>
  );
};

export default FilesListFilter;
