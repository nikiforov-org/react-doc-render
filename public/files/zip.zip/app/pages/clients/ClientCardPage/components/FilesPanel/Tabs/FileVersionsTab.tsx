'use client';
import { useContext, useEffect, useState } from 'react';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import { formatDateToRussian, formatTime } from '@/utils/date';
import {
  ClientDocumentWithProperties,
  DocumentVersion,
} from '@/app/pages/clients/ClientCardPage/types';
import AttributesBlock from './AttributesBlock';
import { documentAttributes } from '@/app/pages/clients/ClientCardPage/constants';
import { getFormattedDate } from '@/app/pages/clients/ClientCardPage/ClientCardPage';
import { Spinner } from '@/components/Spinner';
import { classNames } from 'primereact/utils';
import { ToastContext } from '@/utils/formMessages';

type DocumentVersionWithProperties = DocumentVersion & {
  path: string;
  name: string;
  date: string;
  time: string;
  onBack: (status: 'success' | 'error', message: string) => void;
  onRowExpand: (rowData: DocumentVersionWithProperties) => Promise<void>;
};

interface FileVersionsTabProps {
  selectedFile: ClientDocumentWithProperties;
}

const expanderColumnTemplate = (
  rowData: DocumentVersionWithProperties,
  expandedRows: Record<string, boolean>,
  setExpandedRows: React.Dispatch<
    React.SetStateAction<Record<string, boolean>>
  >,
) => {
  const isExpanded = !!expandedRows[rowData.versionId];

  const toggleExpansion = () => {
    setExpandedRows((prevExpandedRows) => {
      const currentExpandedRows = { ...prevExpandedRows };
      if (isExpanded) {
        delete currentExpandedRows[rowData.versionId];
      } else {
        currentExpandedRows[rowData.versionId] = true;
      }
      return currentExpandedRows;
    });

    if (!isExpanded) {
      rowData.onRowExpand(rowData);
    }
  };

  return (
    <div className="flex items-center">
      <Button
        text
        icon={`pi ${isExpanded ? 'pi-angle-down' : 'pi-angle-right'}`}
        className="p-0 mr-2 w-4"
        onClick={toggleExpansion}
      />
      <span>{rowData.name}</span>
    </div>
  );
};

const actionsCellTemplate = (rowData: DocumentVersionWithProperties) => {
  const { versionId, path, onBack } = rowData;

  const onDownloadFile = async () => {
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_APP_API}/files/${path}?versionId=${versionId}`,
      );
      const data = await response.blob();
      const url = window.URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      const pathParts = path.split('/');
      a.download = pathParts[pathParts.length - 1];
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
      onBack('success', 'Файл успешно скачан');
    } catch (error) {
      onBack('error', 'Ошибка при скачивании файла');
    }
  };

  return (
    <div className="flex justify-end">
      <Button
        text
        icon="pi pi-download"
        className="p-0"
        onClick={onDownloadFile}
      />
    </div>
  );
};

const rowExpansionTemplate = (
  fileInfo: ClientDocumentWithProperties | undefined,
) => {
  return (
    <>
      {fileInfo && (
        <AttributesBlock
          item={fileInfo}
          itemAttributes={documentAttributes.slice(1)}
        />
      )}
    </>
  );
};

const FileVersionsTab = ({ selectedFile }: FileVersionsTabProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [fileVersions, setFileVersions] = useState<DocumentVersion[]>([]);
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});
  const [fileInfoByVersion, setFileInfoByVersion] = useState<
    Record<string, ClientDocumentWithProperties>
  >({});

  const { showToast } = useContext(ToastContext);

  useEffect(() => {
    (async () => {
      try {
        setIsLoading(true);
        // reset state if tab is active and selected file was changed
        setFileVersions([]);
        setExpandedRows({});
        setFileInfoByVersion({});

        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/versions/${selectedFile.system_key}`,
        );
        const data = await response.json();
        setFileVersions(data);
      } catch (error) {
        showToast(
          'error',
          `Ошибка при загрузке данных о версиях документа "${selectedFile.doc_name}"`,
        );
      } finally {
        setIsLoading(false);
      }
    })();
  }, [selectedFile]);

  const onRowExpand = async (rowData: DocumentVersionWithProperties) => {
    const { versionId, path, name: version } = rowData;
    if (versionId && !fileInfoByVersion[versionId]) {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/file-properties/${selectedFile.objectType}/${path}?versionId=${versionId}`,
        );
        const data = await response.json();
        const fileInfo = {
          ...data,
          formattedCreationDate: getFormattedDate(data.system_creation_date),
          formattedValidity: getFormattedDate(data.validity),
        };
        setFileInfoByVersion((prev) => ({
          ...prev,
          [versionId]: fileInfo,
        }));
      } catch (error) {
        showToast(
          "error",
          `Ошибка при загрузке атрибутов документа "${selectedFile.doc_name}" версии ${version}`,
        );
      }
    }
  };

  const versionsList: DocumentVersionWithProperties[] = [...fileVersions]
    .sort((a, b) => b.lastModified - a.lastModified)
    .map((versionItem, index, array) => ({
      ...versionItem,
      path: selectedFile.system_key,
      name: `${array.length - index}.0`,
      date: formatDateToRussian(new Date(versionItem.lastModified * 1000)),
      time: formatTime(new Date(versionItem.lastModified * 1000)),
      onBack: showToast,
      onRowExpand: onRowExpand,
    }));

  const cellBodyClassName = (rowData: DocumentVersionWithProperties) => {
    return expandedRows[rowData.versionId] ? 'border-b-0' : '';
  };

  return (
    <>
      <DataTable
        value={versionsList}
        dataKey="versionId"
        expandedRows={expandedRows}
        rowExpansionTemplate={(rowData) =>
          rowExpansionTemplate(fileInfoByVersion[rowData.versionId])
        }
        emptyMessage=" "
        pt={{
          column: {
            bodyCell: {
              className: classNames({
                ['border-none p-0']: !versionsList?.length || isLoading,
              }),
            },
            headerCell: { className: classNames({ 'opacity-40': isLoading }) },
          },
        }}
        className="w-full"
      >
        <Column
          header="Номер"
          body={(rowData) =>
            expanderColumnTemplate(rowData, expandedRows, setExpandedRows)
          }
          bodyClassName={cellBodyClassName}
          className="py-3"
        />
        <Column
          field="date"
          header="Дата"
          bodyClassName={cellBodyClassName}
          className="py-3"
        />
        <Column
          field="time"
          header="Время"
          bodyClassName={cellBodyClassName}
          className="py-3"
        />
        <Column
          header="Действия"
          body={actionsCellTemplate}
          bodyClassName={cellBodyClassName}
          alignHeader="right"
          className="py-3"
        />
      </DataTable>

      {isLoading ? <Spinner /> : null}
    </>
  );
};

export default FileVersionsTab;
