'use client';
import { useMetadata } from '@/components/MetaData';
import { useForm } from 'react-hook-form';
import { useContext, useState } from 'react';
import { Button } from 'primereact/button';
import {
  ClientFolderWithProperties,
  IndividualClientWithProperties,
  LegalClientWithProperties,
} from '../types';
import { ClientFolderProperties } from '@/types';
import { FormField } from '@/components/FormField';
import { formStyle } from '../constants';
import { ToastContext } from '@/utils/formMessages';

interface FolderFormValues {
  folder_name: string;
  description: string;
  is_actual: boolean;
}

const folderFormValues: FolderFormValues = {
  folder_name: '',
  description: '',
  is_actual: true,
};

const editFormRequiredFields: (keyof FolderFormValues)[] = [
  'folder_name',
  'is_actual',
];

interface FolderFormProps {
  selectedFolderInfo: ClientFolderWithProperties | null;
  clientInfo: IndividualClientWithProperties | LegalClientWithProperties;
  refreshList: () => Promise<void>;
  onHide: () => void;
  onSuccess: () => void;
}

const FolderForm = ({
  selectedFolderInfo,
  clientInfo,
  refreshList,
  onHide,
  onSuccess,
}: FolderFormProps) => {
  const { getMetadata } = useMetadata();
  const fieldsMetadata = getMetadata('objectTypeMap.client_folders.fieldMap');

  const { showToast } = useContext(ToastContext);

  const isEditing = !!selectedFolderInfo;
  const [isLoading, setIsLoading] = useState(false);

  const {
    control,
    formState: { errors },
    handleSubmit,
    setValue,
    watch,
  } = useForm<FolderFormValues>({
    defaultValues: (() => {
      if (!isEditing) {
        return folderFormValues;
      } else {
        if (selectedFolderInfo) {
          return {
            folder_name: selectedFolderInfo.folder_name,
            description: selectedFolderInfo.description || '',
            is_actual: selectedFolderInfo.is_actual,
          };
        }
        return folderFormValues;
      }
    })(),
  });

  const formValues = watch();

  const onSubmit = async (data: FolderFormValues) => {
    const { folder_name, description, is_actual } = data;

    const folder: Partial<ClientFolderProperties> = {
      client_inn: clientInfo.inn,
      client_id: clientInfo.id,
      folder_name,
      is_actual,
    };

    if (description) {
      folder.description = description;
    }

    try {
      setIsLoading(true);
      if (isEditing) {
        await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/folder-descriptor-properties/${selectedFolderInfo.objectType}/${selectedFolderInfo.system_key}`,
          {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(folder),
          },
        );
        onHide();
        onSuccess();
        // wait 1 sec for updating list
        setTimeout(() => {
          refreshList();
          showToast(
            'success',
            `Атрибуты договора "${selectedFolderInfo.folder_name}" успешно обновлены`,
          );
        }, 1000);
      }
    } catch (error) {
      showToast(
        'error',
        `Ошибка при ${isEditing ? `обновлении атрибутов договора "${selectedFolderInfo.folder_name}"` : ''}`,
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="h-full flex flex-col justify-between"
      >
        <div className={formStyle.container}>
          <FormField<FolderFormValues>
            name="folder_name"
            label="Название договора"
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
            disabled={isEditing}
          />
          <FormField<FolderFormValues>
            name="description"
            label="Описание"
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<FolderFormValues>
            name="is_actual"
            label="Актульность"
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
        </div>

        <div className="flex justify-between border-t mt-6 p-5">
          <Button
            className="w-fit"
            type="submit"
            disabled={
              isLoading ||
              !(isEditing ? editFormRequiredFields : []).every(
                (requiredField) => {
                  if (!(typeof formValues[requiredField] === 'boolean')) {
                    return formValues[requiredField];
                  }
                  return true;
                },
              )
            }
          >
            {isEditing ? 'Редактировать договор' : ''}
          </Button>
          <Button className="w-fit" text type="button" onClick={onHide}>
            Отменить
          </Button>
        </div>
      </form>
    </>
  );
};

export default FolderForm;
