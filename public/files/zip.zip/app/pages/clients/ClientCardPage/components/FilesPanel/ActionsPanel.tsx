import React from 'react';
import { Button, ButtonProps } from 'primereact/button';

interface ActionsPanelProps {
  text: string;
  buttons: ButtonProps[];
}

const buttonClassName = 'text-sm text-surface-0 font-medium p-0';

const ActionsPanel: React.FC<ActionsPanelProps> = ({ text, buttons }) => {
  return (
    <div className="sticky bottom-0 flex justify-between items-center bg-surface-800 rounded py-4 px-6">
      <div className="text-sm text-surface-0 font-medium">{text}</div>
      <div className="flex gap-x-4">
        {buttons.map((button, index) => (
          <Button
            key={index}
            text
            icon={button.icon}
            label={button.label}
            onClick={button.onClick}
            className={button.className || buttonClassName}
          />
        ))}
      </div>
    </div>
  );
};

export default ActionsPanel;
