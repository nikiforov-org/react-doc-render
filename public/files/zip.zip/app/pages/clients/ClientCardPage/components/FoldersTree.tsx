'use client';
import React, { useContext, useEffect, useState } from 'react';
import { Tree, TreeEventNodeEvent } from 'primereact/tree';
import {
  ClientDocumentWithProperties,
  ClientFolderWithProperties,
  TreeFolderNode,
} from '@/app/pages/clients/ClientCardPage/types';
import { GlobalFolder } from '@/types';
import { findNodeByField } from '@/utils/tree';
import { Spinner } from '@/components/Spinner';
import { ToastContext } from '@/utils/formMessages';

function buildFolderTree(
  rootFolderName: string,
  globalFolders: GlobalFolder[],
  clientFolderMap: Record<string, ClientFolderWithProperties>,
  objects: ClientDocumentWithProperties[],
): TreeFolderNode[] {
  const tree: TreeFolderNode = {
    key: '0',
    label: rootFolderName,
    children: [],
    type: 'root',
    parent: null,
    info: null,
    files: [],
  };

  const folderMap: Record<string, TreeFolderNode> = {};
  globalFolders.forEach((folder, index) => {
    const folderName = folder.properties.folder_name;
    const folderNode: TreeFolderNode = {
      key: `0-${index}`,
      label: folderName,
      children: [],
      type: 'global',
      parent: tree,
      info: null,
      files: [],
    };
    folderMap[folderName] = folderNode;
    tree.children.push(folderNode);
  });

  objects.forEach((obj) => {
    const pathParts = obj.system_key.split('/');

    const [, globalFolderName, ...clientFolderNames] = pathParts.slice(1, -1);

    if (folderMap[globalFolderName]) {
      let currentNode = folderMap[globalFolderName];
      let currentKey = folderMap[globalFolderName].key;
      let currentChildren = folderMap[globalFolderName].children;

      let clientFolderPath = pathParts.slice(0, 3).join('/');

      clientFolderNames.forEach((folderName) => {
        clientFolderPath += `/${folderName}`;

        let existingNode = currentChildren.find(
          (node) => node.label === folderName,
        );

        if (!existingNode) {
          const newKey = `${currentKey}-${currentChildren.length}`;
          existingNode = {
            key: newKey,
            label: folderName,
            children: [],
            type: 'client',
            parent: currentNode,
            info: clientFolderMap[clientFolderPath] || null,
            files: [],
          };
          currentChildren.push(existingNode);
        }

        currentNode = existingNode;
        currentKey = existingNode.key;
        currentChildren = existingNode.children;
      });

      currentNode.files.push(obj);
    }
  });

  return [tree];
}

function expandNodesBySystemKey(systemKey: string, nodes: TreeFolderNode[]) {
  const result: {
    node: TreeFolderNode | null;
    nodeKey: string;
    expandedKeys: Record<string, boolean>;
  } = {
    node: null,
    nodeKey: '',
    expandedKeys: {},
  };

  const [, globalFolderName, ...clientFolderNames] = systemKey
    .split('/')
    .slice(1, -1);

  const rootNode = nodes.length ? nodes[0] : null;

  if (rootNode) {
    result.node = rootNode;
    result.nodeKey = rootNode.key;
    result.expandedKeys[rootNode.key] = true;

    const globalFolderNode = findNodeByField(
      'label',
      globalFolderName,
      rootNode.children,
    );

    if (globalFolderNode) {
      result.node = globalFolderNode;
      result.nodeKey = globalFolderNode.key;
      result.expandedKeys[globalFolderNode.key] = true;

      let currentNode = globalFolderNode;
      const currentFolderNames = clientFolderNames;

      while (currentFolderNames.length > 0) {
        const clientFolderName = currentFolderNames.shift();
        const clientFolderNode = findNodeByField(
          'label',
          clientFolderName,
          currentNode.children,
        );

        if (clientFolderNode) {
          result.node = clientFolderNode;
          result.nodeKey = clientFolderNode.key;
          result.expandedKeys[clientFolderNode.key] = true;
          currentNode = clientFolderNode;
        } else {
          break;
        }
      }
    }
  }
  return result;
}

interface FoldersTreeProps {
  clientName: string;
  files: ClientDocumentWithProperties[];
  nodes: TreeFolderNode[];
  isLoading: boolean;
  selectedFolder: TreeFolderNode | null;
  selectedFile: ClientDocumentWithProperties | null;
  clientFolders: ClientFolderWithProperties[];
  setNodes: React.Dispatch<React.SetStateAction<TreeFolderNode[]>>;
  setSelectedFolder: React.Dispatch<
    React.SetStateAction<TreeFolderNode | null>
  >;
  setSelectedFile: React.Dispatch<
    React.SetStateAction<ClientDocumentWithProperties | null>
  >;
}

interface CustomTreeEventNodeEvent extends TreeEventNodeEvent {
  node: TreeFolderNode;
}

export default function DocTree({
  clientName,
  files,
  nodes,
  isLoading,
  selectedFolder,
  selectedFile,
  clientFolders,
  setNodes,
  setSelectedFolder,
  setSelectedFile,
}: FoldersTreeProps) {
  const [globalFolders, setGlobalFolders] = useState<GlobalFolder[]>([]);
  const [expandedKeys, setExpandedKeys] = useState<Record<string, boolean>>({
    '0': true,
  });
  const [selectedKey, setSelectedKey] = useState('');

  const { showToast } = useContext(ToastContext);

  const onSelect = (e: CustomTreeEventNodeEvent) => {
    const { node } = e;
    setSelectedKey(node.key);
    setSelectedFolder(node);
    setSelectedFile(null);
  };

  const onUnselect = () => {
    setSelectedKey('');
    setSelectedFolder(null);
    setSelectedFile(null);
  };

  useEffect(() => {
    (async () => {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/search-dictionary`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              dictionaryNames: ['global_folders'],
              query: {
                match_all: {},
              },
            }),
          },
        );
        const data = await response.json();
        const orderedGlobalFolders: GlobalFolder[] = [...data].sort(
          (a, b) => a.properties.order_number - b.properties.order_number,
        );
        setGlobalFolders(orderedGlobalFolders);
      } catch (error) {
        showToast('error', 'Не удалось загрузить список глобальных папок');
      }
    })();
  }, []);

  useEffect(() => {
    const clientFolderBySystemKey = clientFolders.reduce(
      (acc, current) => {
        acc[current.properties.system_key] = current;
        return acc;
      },
      {} as Record<string, ClientFolderWithProperties>,
    );
    setNodes(
      buildFolderTree(
        clientName,
        globalFolders,
        clientFolderBySystemKey,
        files,
      ),
    );
  }, [globalFolders, clientFolders, clientName, files]);

  useEffect(() => {
    // update selected folder after adding/editing/deleting document
    if (selectedFolder && selectedFolder.key) {
      const updatedSelectedFolder = findNodeByField(
        'key',
        selectedFolder.key,
        nodes,
      );
      setSelectedFolder(updatedSelectedFolder);
      setSelectedKey(updatedSelectedFolder ? updatedSelectedFolder.key : '');
    }
  }, [nodes, selectedFolder]);

  useEffect(() => {
    // expand folder nodes after selecting document
    if (selectedFile) {
      const { node, nodeKey, expandedKeys } = expandNodesBySystemKey(
        selectedFile.system_key,
        nodes,
      );
      setExpandedKeys((prev) => ({ ...prev, ...expandedKeys }));
      setSelectedFolder(node);
      setSelectedKey(nodeKey);
    }
  }, [nodes, selectedFile]);

  return (
    <div className="card flex justify-content-center w-80">
      {!isLoading ? (
        <Tree
          value={nodes}
          expandedKeys={expandedKeys}
          selectionMode="single"
          selectionKeys={selectedKey}
          onSelect={onSelect}
          onUnselect={onUnselect}
          onToggle={(e) => setExpandedKeys(e.value)}
          className="w-full p-0"
        />
      ) : (
        <div className="w-full border border-surface-200 rounded-md">
          <Spinner />
        </div>
      )}
    </div>
  );
}