// ./DocPanel/Tabs.tsx
'use client';
import React, { useEffect } from 'react';
import { TabPanel, TabView } from 'primereact/tabview';
import {
  ClientDocumentWithProperties,
  IndividualClientWithProperties,
  LegalClientWithProperties,
  TreeFolderNode,
} from '@/app/pages/clients/ClientCardPage/types';
import AttributesBlock from './Tabs/AttributesBlock';
import {
  INDIVIDUAL_CLIENT_OBJECT_TYPE,
  LEGAL_CLIENT_OBJECT_TYPE,
  clientFolderAttributes,
  documentAttributes,
  individualClientAttributes,
  legalClientAttributes,
} from '@/app/pages/clients/ClientCardPage/constants';
import FileVersionsTab from './Tabs/FileVersionsTab';
import { ClientProps, setBreadcrumbs } from '@/components/breadcrumbsSlice';
import { useDispatch } from 'react-redux';
import { Spinner } from '@/components/Spinner';
import { Button } from 'primereact/button';

interface TabsProps {
  activeTabIndex: number;
  setActiveTabIndex: React.Dispatch<React.SetStateAction<number>>;
  clientInfo: IndividualClientWithProperties | LegalClientWithProperties | null;
  isClientLoading: boolean;
  selectedFolder: TreeFolderNode | null;
  selectedFile: ClientDocumentWithProperties | null;
  onEditFolderAttributes: () => void;
}

const Tabs: React.FC<TabsProps> = ({
  activeTabIndex,
  setActiveTabIndex,
  clientInfo,
  isClientLoading,
  selectedFolder,
  selectedFile,
  onEditFolderAttributes,
}) => {
  const dispatch = useDispatch();

  useEffect(() => {
    if (clientInfo) {
      dispatch(setBreadcrumbs(clientInfo as ClientProps));
    }
  }, [clientInfo]);

  return (
    <TabView
      activeIndex={activeTabIndex}
      onTabChange={(e) => setActiveTabIndex(e.index)}
      className="w-full h-full flex flex-col"
      pt={{
        panelContainer: {
          className: 'min-h-0 flex-1 overflow-y-auto flex flex-col',
        },
      }}
    >
      <TabPanel
        header="Атрибуты клиента"
        pt={{ content: { className: 'flex-1' } }}
      >
        {clientInfo &&
          clientInfo.objectType === INDIVIDUAL_CLIENT_OBJECT_TYPE && (
            <AttributesBlock
              item={clientInfo as IndividualClientWithProperties}
              itemAttributes={individualClientAttributes}
            />
          )}
        {clientInfo && clientInfo.objectType === LEGAL_CLIENT_OBJECT_TYPE && (
          <AttributesBlock
            item={clientInfo as LegalClientWithProperties}
            itemAttributes={legalClientAttributes}
          />
        )}
        {isClientLoading ? <Spinner /> : null}
      </TabPanel>
      <TabPanel header="Атрибуты документа">
        {selectedFile ? (
          <AttributesBlock
            item={selectedFile}
            itemAttributes={documentAttributes}
          />
        ) : (
          <div className="text-surface-700 text-center py-8">
            Для отображения данных выберите документ.
          </div>
        )}
      </TabPanel>
      <TabPanel header="Атрибуты договора">
        {selectedFolder &&
          selectedFolder.type === 'client' &&
          selectedFolder.info && (
            <>
              <AttributesBlock
                item={selectedFolder.info}
                itemAttributes={clientFolderAttributes}
              />
              <Button
                outlined
                label="Обновить атрибуты договора"
                onClick={onEditFolderAttributes}
                className="text-sm font-medium mt-6"
              />
            </>
          )}
      </TabPanel>
      <TabPanel
        header="Версии документа"
        pt={{ content: { className: 'flex-1' } }}
      >
        {selectedFile ? (
          <FileVersionsTab selectedFile={selectedFile} />
        ) : (
          <div className="text-surface-700 text-center py-8">
            Для отображения данных выберите документ.
          </div>
        )}
      </TabPanel>
    </TabView>
  );
};

export default Tabs;
