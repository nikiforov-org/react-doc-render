import React from 'react';
import { DataTable, DataTableFilterMeta } from 'primereact/datatable';
import { Column } from 'primereact/column';
import MimeIcon from '@/components/MimeIcon';
import { ClientDocumentWithProperties } from '@/app/pages/clients/ClientCardPage/types';
import { Spinner } from '@/components/Spinner';
import { classNames } from 'primereact/utils';

const iconTemplate = (rowData: { system_type: string }) => {
  return (
    <>
      <MimeIcon mimeType={rowData.system_type} className="w-6" />
    </>
  );
};

interface FilesListProps {
  filters: DataTableFilterMeta;
  list: ClientDocumentWithProperties[];
  areFilesLoading: boolean;
  selectedFile: ClientDocumentWithProperties | null;
  setSelectedFile: React.Dispatch<
    React.SetStateAction<ClientDocumentWithProperties | null>
  >;
  onSelectCallback: () => void;
}

const FilesList: React.FC<FilesListProps> = ({
  filters,
  list,
  areFilesLoading,
  selectedFile,
  setSelectedFile,
  onSelectCallback,
}) => {
  return (
    <div className="w-full">
      <DataTable
        value={list}
        selectionMode="single"
        selection={selectedFile}
        scrollable
        scrollHeight="100%"
        dataKey="id"
        className="w-full"
        filters={filters}
        globalFilterFields={['doc_name', 'invalid', 'expired']}
        emptyMessage={
          !areFilesLoading ? 'По данному запросу ничего не найдено' : ' '
        }
        onRowSelect={(e) => {
          onSelectCallback();
          setSelectedFile(e.data);
        }}
        onRowUnselect={() => setSelectedFile(null)}
        pt={{
          column: {
            headerCell: {
              className: classNames({ 'opacity-40': areFilesLoading }),
            },
            bodyCell: {
              className: classNames({
                ['border-none p-0']: !list.length,
              }),
            },
          },
        }}
      >
        <Column
          field="icon"
          body={iconTemplate}
          className="py-3 w-13 min-w-13"
          pt={{ headerCell: { className: 'w-13 min-w-13' } }}
        />
        <Column field="doc_name" header="Название документа" className="py-3" />
        <Column field="doc_number" header="Номер документа" className="py-3" />
        <Column
          field="formattedCreationDate"
          header="Дата создания документа"
          className="py-3"
        />
        <Column field="status" header="Статус документа" className="py-3" />
      </DataTable>
      {areFilesLoading ? <Spinner /> : null}
    </div>
  );
};

export default FilesList;
