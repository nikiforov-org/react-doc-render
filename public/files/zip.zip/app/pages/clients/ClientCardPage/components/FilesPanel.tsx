'use client';
import React, { useState, useEffect, useContext } from 'react';
import { Splitter, SplitterPanel } from 'primereact/splitter';
import { Dialog } from 'primereact/dialog';
import Tabs from './FilesPanel/Tabs';
import FilesList from './FilesPanel/FilesList';
import { FilterMatchMode } from 'primereact/api';
import FilesListFilter from './FilesPanel/FilesListFilter';
import { Button } from 'primereact/button';
import {
  ClientDocumentWithProperties,
  IndividualClientWithProperties,
  LegalClientWithProperties,
  TreeFolderNode,
} from '@/app/pages/clients/ClientCardPage/types';
import ActionsPanel from './FilesPanel/ActionsPanel';
import { DataTableFilterMeta } from 'primereact/datatable';
import MimeIcon from '@/components/MimeIcon';
import FilePreview from '@/components/FilePreview';
import { ToastContext } from '@/utils/formMessages';

interface FilesPanelProps {
  clientInfo: IndividualClientWithProperties | LegalClientWithProperties | null;
  isClientLoading: boolean;
  files: ClientDocumentWithProperties[];
  areFilesLoading: boolean;
  selectedFolder: TreeFolderNode | null;
  selectedFile: ClientDocumentWithProperties | null;
  setSelectedFile: React.Dispatch<
    React.SetStateAction<ClientDocumentWithProperties | null>
  >;
  lastUpdatedItemType: 'document' | 'folder' | null;
  setLastUpdatedItemType: React.Dispatch<
    React.SetStateAction<'document' | 'folder' | null>
  >;
  refreshList: () => Promise<void>;
  setFileDrawerVisible: React.Dispatch<React.SetStateAction<boolean>>;
  setFolderDrawerVisible: React.Dispatch<React.SetStateAction<boolean>>;
}

export default function FilesPanel({
  clientInfo,
  isClientLoading,
  files,
  areFilesLoading,
  selectedFolder,
  selectedFile,
  lastUpdatedItemType,
  setSelectedFile,
  setLastUpdatedItemType,
  refreshList,
  setFileDrawerVisible,
  setFolderDrawerVisible,
}: FilesPanelProps) {
  const [splitterHeight, setSplitterHeight] = useState(0);
  const [filters, setFilters] = useState<DataTableFilterMeta>({
    doc_name: { value: '', matchMode: FilterMatchMode.CONTAINS },
    invalid: { value: null, matchMode: FilterMatchMode.EQUALS },
    expired: { value: null, matchMode: FilterMatchMode.EQUALS },
  });
  const [nameFilterValue, setNameFilterValue] = useState<string>('');
  const [invalidFilterValue, setInvalidFilterValue] = useState<boolean | null>(
    null,
  );
  const [expiredFilterValue, setExpiredFilterValue] = useState<boolean | null>(
    null,
  );
  const [activeTabIndex, setActiveTabIndex] = useState(0);
  const [showDialog, setShowDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [previewUri, setPreviewUri] = useState<string | null>(null);
  const [previewVisible, setPreviewVisible] = useState<boolean>(false);

  const { showToast } = useContext(ToastContext);

  useEffect(() => {
    function setDocumentTab() {
      setActiveTabIndex(1);
    }

    function setFolderTab() {
      if (selectedFolder) {
        if (selectedFolder.type === 'client') {
          setActiveTabIndex(2);
        } else {
          setActiveTabIndex(0);
        }
      }
    }

    // set active tab
    if (selectedFile && selectedFolder) {
      if (!lastUpdatedItemType || lastUpdatedItemType === 'document') {
        setDocumentTab();
      } else if (lastUpdatedItemType === 'folder') {
        setFolderTab();
      }
    } else if (selectedFile) {
      setDocumentTab();
    } else if (selectedFolder) {
      setFolderTab();
    } else {
      setActiveTabIndex(0);
    }
  }, [selectedFile, selectedFolder]);

  useEffect(() => {
    const updateHeight = () => {
      const height = window.innerHeight - 165;
      setSplitterHeight(height);
    };

    updateHeight();

    window.addEventListener('resize', updateHeight);

    return () => {
      window.removeEventListener('resize', updateHeight);
    };
  }, []);

  const onCreateDocument = () => {
    setSelectedFile(null);
    setFileDrawerVisible(true);
  };

  const onOpenPreview = () => {
    if (selectedFile) {
      setPreviewUri(
        `${process.env.NEXT_PUBLIC_APP_API}/files${selectedFile.system_key}`,
      );
      setPreviewVisible(true);
    }
  };

  const onDownloadFile = async () => {
    if (selectedFile) {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/files/${selectedFile.system_key}`,
        );
        const data = await response.blob();
        const url = window.URL.createObjectURL(data);
        const a = document.createElement('a');
        a.href = url;
        const pathParts = selectedFile.system_key.split('/');
        a.download = pathParts[pathParts.length - 1];
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        showToast('success', 'Файл успешно скачан');
      } catch (error) {
        showToast('error', 'Ошибка при скачивании файла');
      }
    }
  };

  const onConfirmDeleting = async () => {
    if (selectedFile) {
      try {
        setIsLoading(true);
        await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/files/${selectedFile.objectType}/${selectedFile.system_key}`,
          {
            method: 'DELETE',
          },
        );
        // wait 1 sec for updating list
        setTimeout(() => {
          refreshList();
          showToast(
            'success',
            `Документ "${selectedFile.doc_name}" успешно удален`,
          );
        }, 1000);
      } catch (error) {
        showToast(
          'error',
          `Ошибка при удалении документа "${selectedFile.doc_name}"`,
        );
      } finally {
        setIsLoading(false);
        setShowDialog(false);
      }
    }
  };

  return (
    <>
      <div className="flex-1 ml-4">
        <div className="flex">
          <FilesListFilter
            filters={filters}
            setFilters={setFilters}
            nameFilterValue={nameFilterValue}
            setNameFilterValue={setNameFilterValue}
            invalidFilterValue={invalidFilterValue}
            setInvalidFilterValue={setInvalidFilterValue}
            expiredFilterValue={expiredFilterValue}
            setExpiredFilterValue={setExpiredFilterValue}
            filterCallback={() => setSelectedFile(null)}
          />
          <div className="flex-1 items-center text-right">
            <Button onClick={onCreateDocument}>Загрузить файл</Button>
          </div>
        </div>
        <Splitter
          style={{ height: `${splitterHeight}px` }}
          layout="vertical"
          className="mt-4 border-0"
        >
          <SplitterPanel className="min-h-[140px] overflow-hidden" size={60}>
            <FilesList
              filters={filters}
              list={files}
              areFilesLoading={areFilesLoading}
              selectedFile={selectedFile}
              setSelectedFile={setSelectedFile}
              onSelectCallback={() => setLastUpdatedItemType(null)}
            />
          </SplitterPanel>
          <SplitterPanel size={45} className="min-h-[240px] flex flex-col">
            <div className="flex-1 overflow-auto">
              <Tabs
                activeTabIndex={activeTabIndex}
                setActiveTabIndex={setActiveTabIndex}
                clientInfo={clientInfo}
                isClientLoading={isClientLoading}
                selectedFolder={selectedFolder}
                selectedFile={selectedFile}
                onEditFolderAttributes={() => setFolderDrawerVisible(true)}
              />
            </div>
            {selectedFile && (
              <ActionsPanel
                text={selectedFile.doc_name}
                buttons={[
                  {
                    icon: 'pi pi-eye',
                    label: 'Просмотр',
                    onClick: onOpenPreview,
                  },
                  {
                    icon: 'pi pi-download',
                    label: 'Скачать',
                    onClick: onDownloadFile,
                  },
                  {
                    icon: 'pi pi-pencil',
                    label: 'Редактировать',
                    onClick: () => setFileDrawerVisible(true),
                  },
                  {
                    icon: 'pi pi-trash',
                    label: 'Удалить',
                    onClick: () => setShowDialog(true),
                  },
                ]}
              />
            )}
          </SplitterPanel>
        </Splitter>
      </div>
      <Dialog
        visible={showDialog}
        style={{ width: '450px' }}
        header="Подтверждение удаления"
        modal
        footer={
          <>
            <Button
              label="Нет"
              icon="pi pi-times"
              onClick={() => setShowDialog(false)}
              className="p-button-text"
            />
            <Button
              label="Да"
              icon="pi pi-check"
              onClick={onConfirmDeleting}
              autoFocus
              disabled={isLoading}
            />
          </>
        }
        onHide={() => setShowDialog(false)}
      >
        <p>
          Вы уверены, что хотите удалить документ &quot;
          {selectedFile?.doc_name}&quot;?
        </p>
      </Dialog>
      <Dialog
        visible={previewVisible}
        maximizable
        dismissableMask
        header={
          <div className="flex items-start gap-2">
            <MimeIcon
              mimeType={selectedFile?.system_type as string}
              className="w-6"
            />
            <span className="text-sm font-normal break-all">
              {selectedFile?.doc_name}
            </span>
          </div>
        }
        onHide={() => {
          if (!previewVisible) return;
          setPreviewVisible(false);
        }}
        className="w-1/2"
      >
        {previewUri && <FilePreview uri={previewUri} />}
      </Dialog>
    </>
  );
}
