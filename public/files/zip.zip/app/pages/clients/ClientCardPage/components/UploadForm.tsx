'use client';
import React, { useContext, useMemo, useState } from 'react';
import { InputText } from 'primereact/inputtext';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { Divider } from 'primereact/divider';
import { FileUpload } from 'primereact/fileupload';
import { Button } from 'primereact/button';
import { classNames } from 'primereact/utils';
import { Controller, useForm } from 'react-hook-form';
import {
  CLIENT_FOLDER_OBJECT_TYPE,
  INDIVIDUAL_CLIENT_OBJECT_TYPE,
  LEGAL_CLIENT_OBJECT_TYPE,
  formStyle,
} from '@/app/pages/clients/ClientCardPage/constants';
import {
  ClientDocumentWithProperties,
  IndividualClientWithProperties,
  LegalClientWithProperties,
  TreeFolderNode,
} from '@/app/pages/clients/ClientCardPage/types';
import { DocumentProperties } from '@/types';
import { formatBytes } from '@/utils/format';
import { ToastContext, getFormErrorMessage } from '@/utils/formMessages';
import { useMetadata } from '@/components/MetaData';
import { isIndividualClient, isLegalClient } from '../ClientCardPage';
import { FormField } from '@/components/FormField';
import StorageInput from '@/components/StorageInput';

const contractDropdownStyles = {
  item: {
    className: 'last:bg-surface-50 last:text-primary-500 text-wrap break-words',
  },
  wrapper: { className: 'max-w-[376px]' },
  itemLabel: { className: 'min-w-0' },
};

interface DropdownOption {
  name: string;
  id: string;
}

interface FileUploadObject {
  name: string;
  size: number;
}

interface AddFormValues {
  folder: string | null;
  contract: string | null;
  newContract: string;
  status: string | null;
  doc_number: string;
  original_type: string;
  original_status: string | null;
  validity: string | null;
  storage: string | null;
  uploadedFile: File | null;
}

type EditFormValues = Omit<AddFormValues, 'newContract' | 'uploadedFile'>;

const addFormDefaultValues: AddFormValues = {
  folder: null,
  contract: null,
  newContract: '',
  status: null,
  doc_number: '',
  original_type: '',
  original_status: null,
  validity: null,
  storage: null,
  uploadedFile: null,
};

const addFormRequiredFields: (keyof AddFormValues)[] = [
  'folder',
  'contract',
  'status',
  'doc_number',
  'original_type',
  'uploadedFile',
];

const editFormRequiredFields: (keyof EditFormValues)[] = [
  'folder',
  'contract',
  'status',
  'doc_number',
  'original_type',
];

interface UploadFormProps {
  selectedFolder: TreeFolderNode | null;
  selectedFile: ClientDocumentWithProperties | null;
  clientInfo: IndividualClientWithProperties | LegalClientWithProperties;
  folders: TreeFolderNode[];
  refreshList: () => Promise<void>;
  onCreatingCallback: (id: string) => void;
  onHide: () => void;
  onSuccess: () => void;
}

const UploadForm = ({
  selectedFolder,
  selectedFile,
  clientInfo,
  folders,
  refreshList,
  onCreatingCallback,
  onHide,
  onSuccess,
}: UploadFormProps) => {
  const { getMetadata } = useMetadata();
  const fieldsMetadata = isIndividualClient(clientInfo)
    ? getMetadata('objectTypeMap.individual_clients_documents.fieldMap')
    : isLegalClient(clientInfo)
      ? getMetadata('objectTypeMap.legal_clients_documents.fieldMap')
      : null;

  const clientFolderNameMetadata = getMetadata(
    'objectTypeMap.client_folders.fieldMap.folder_name',
  );

  const { showToast } = useContext(ToastContext);

  const isEditing = !!selectedFile;
  const [isLoading, setIsLoading] = useState(false);
  const [showNewContractInput, setShowNewContractInput] = useState(false);

  const {
    control,
    formState: { errors },
    handleSubmit,
    setValue,
    watch,
  } = useForm<AddFormValues>({
    defaultValues: (() => {
      if (!isEditing) {
        const formValues = { ...addFormDefaultValues };
        if (selectedFolder && selectedFolder.type === 'global') {
          formValues['folder'] = selectedFolder.label;
        } else if (selectedFolder && selectedFolder.type === 'client') {
          formValues['folder'] = selectedFolder.parent?.label || null;
          formValues['contract'] = selectedFolder.label;
        }
        return formValues;
      } else {
        if (selectedFile) {
          const [, folderName, contractName] = selectedFile.system_key
            .split('/')
            .slice(1, -1);
          return {
            folder: folderName,
            contract: contractName,
            newContract: '',
            status: selectedFile.status,
            doc_number: selectedFile.doc_number,
            original_type: selectedFile.original_type,
            original_status: selectedFile.original_status || null,
            validity: selectedFile.validity || null,
            storage: selectedFile.storage || null,
          };
        }
        return addFormDefaultValues;
      }
    })(),
  });

  const formValues = watch();
  const folder = watch('folder');

  const folderOptions = folders.map((folderItem) => ({
    name: folderItem.label,
    id: folderItem.label,
  }));

  const contractOptions = useMemo(() => {
    const options: DropdownOption[] = [];
    if (folder) {
      const selectedFolderIndex = folders.findIndex(
        (folderItem) => folderItem.label === folder,
      );
      if (selectedFolderIndex >= 0) {
        folders[selectedFolderIndex].children.forEach((contractItem) => {
          options.push({
            name: contractItem.label,
            id: contractItem.label,
          });
        });
      }
    }
    return [...options, { name: 'Создать новый', id: 'newContract' }];
  }, [folder, folders]);

  const onChangeFolder = (e: DropdownChangeEvent) => {
    setValue('folder', e.value, { shouldValidate: true });
    setValue('contract', null);
    setValue('newContract', '');
    setShowNewContractInput(false);
  };

  const onChangeContract = (e: DropdownChangeEvent) => {
    const selectedContract = e.value;
    setShowNewContractInput(selectedContract === 'newContract');
    setValue('contract', selectedContract, { shouldValidate: true });
    setValue('newContract', '');
  };

  const onSubmit = async (data: AddFormValues) => {
    const {
      folder,
      contract,
      newContract,
      status,
      doc_number,
      original_type,
      original_status,
      validity,
      storage,
      uploadedFile,
    } = data;

    const newContractName = newContract.trim();

    const document: Partial<DocumentProperties> = {
      original_type,
      client_id: clientInfo.id,
      client_inn: clientInfo.inn,
      doc_number,
      is_actual: true,
      status: status as string,
    };

    if (original_status) {
      document.original_status = original_status;
    }
    if (storage) {
      document.storage = storage;
    }
    if (validity) {
      document.validity = validity;
    }

    const path = `/${clientInfo.inn}/${folder}/${showNewContractInput ? newContractName : contract}`;

    try {
      setIsLoading(true);

      // if client folder does not exist
      if (
        showNewContractInput &&
        !contractOptions.find((contract) => contract.name === newContractName)
      ) {
        await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/folder-descriptors/${CLIENT_FOLDER_OBJECT_TYPE}/${path}`,
          {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              client_inn: clientInfo.inn,
              client_id: clientInfo.id,
              folder_name: newContractName,
              is_actual: true,
            }),
          },
        );
      }

      if (isEditing) {
        document.doc_name = selectedFile.doc_name;

        await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/file-properties/${selectedFile.objectType}/${selectedFile.system_key}`,
          {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(document),
          },
        );
        onHide();
        onSuccess();
        // wait 1 sec for updating list
        setTimeout(() => {
          refreshList();
          showToast(
            'success',
            `Атрибуты документа "${selectedFile.doc_name}" успешно обновлены`,
          );
        }, 1000);
      } else {
        document.doc_name = uploadedFile!.name;

        let objectType = '';
        if (clientInfo.objectType === INDIVIDUAL_CLIENT_OBJECT_TYPE) {
          objectType = 'individual_clients_documents';
        } else if (clientInfo.objectType === LEGAL_CLIENT_OBJECT_TYPE) {
          objectType = 'legal_clients_documents';
        }

        const formData = new FormData();
        if (uploadedFile) {
          formData.set('content', uploadedFile);
        }
        formData.set('properties', JSON.stringify(document));

        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/files/${objectType}/${path}`,
          {
            method: 'PUT',
            body: formData,
          },
        );
        onHide();
        onSuccess();
        const createdDocumentID = await response.text();
        // wait 1 sec for updating list
        setTimeout(() => {
          refreshList();
          onCreatingCallback(createdDocumentID);
          showToast('success', `Файл "${document.doc_name}" успешно загружен`);
        }, 1000);
      }
    } catch (error) {
      showToast(
        'error',
        `Ошибка при ${isEditing ? `обновлении атрибутов документа "${selectedFile.doc_name}"` : `загрузке файла "${uploadedFile?.name}"`}`,
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="h-full flex flex-col justify-between"
      >
        <div className={formStyle.container}>
          <div className={formStyle.field}>
            <label
              htmlFor="folder"
              className={classNames({ 'p-error': errors.folder })}
            >
              Папка
            </label>
            <Controller
              name="folder"
              control={control}
              rules={{ required: 'Обязательное поле' }}
              render={({ field, fieldState }) => (
                <Dropdown
                  id={field.name}
                  {...field}
                  options={folderOptions}
                  optionLabel="name"
                  optionValue="id"
                  placeholder="Выберите из списка"
                  disabled={isEditing}
                  onChange={onChangeFolder}
                  className={classNames({ 'p-invalid': fieldState.invalid })}
                />
              )}
            />
            {getFormErrorMessage(errors, 'folder')}
          </div>
          <div className={formStyle.field}>
            <label
              htmlFor="contract"
              className={classNames({ 'p-error': errors.contract })}
            >
              Договор
            </label>
            <Controller
              name="contract"
              control={control}
              rules={{ required: 'Обязательное поле' }}
              render={({ field, fieldState }) => (
                <Dropdown
                  id={field.name}
                  {...field}
                  options={contractOptions}
                  optionLabel="name"
                  optionValue="id"
                  placeholder="Выберите из списка"
                  disabled={!folder || isEditing}
                  onChange={onChangeContract}
                  pt={contractDropdownStyles}
                  className={classNames({ 'p-invalid': fieldState.invalid })}
                />
              )}
            />
            {getFormErrorMessage(errors, 'contract')}
          </div>
          {showNewContractInput && (
            <div className={formStyle.field}>
              <label
                htmlFor="newContract"
                className={classNames({ 'p-error': errors.newContract })}
              >
                Название нового договора
              </label>
              <Controller
                name="newContract"
                control={control}
                rules={{
                  required: 'Обязательное поле',
                  validate: {
                    ...(clientFolderNameMetadata?.regexPattern &&
                      clientFolderNameMetadata?.validationMessage && {
                        pattern: (value: string) => {
                          return (
                            new RegExp(
                              clientFolderNameMetadata.regexPattern!,
                            ).test(value) ||
                            clientFolderNameMetadata.validationMessage!
                          );
                        },
                      }),
                  },
                }}
                render={({ field, fieldState }) => (
                  <InputText
                    id={field.name}
                    {...field}
                    maxLength={clientFolderNameMetadata?.maxLength}
                    onBlur={() => field.onChange(field.value.trim())}
                    className={classNames({
                      'p-invalid': fieldState.invalid,
                    })}
                  />
                )}
              />
              {getFormErrorMessage(errors, 'newContract')}
            </div>
          )}

          <Divider className="my-2" />

          <FormField<AddFormValues>
            name="status"
            label="Статус документа"
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<AddFormValues>
            name="doc_number"
            label="Номер документа"
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<AddFormValues>
            name="original_type"
            label="Вид оригинала"
            preferRadioButtons
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<AddFormValues>
            name="original_status"
            label="Статус оригинала"
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<AddFormValues>
            name="validity"
            label="Срок действия документа"
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <div className={formStyle.field}>
            <label htmlFor="storage">Место хранения (необязательно)</label>
            <Controller
              name="storage"
              control={control}
              render={({ field }) => (
                <StorageInput
                  id={field.name}
                  placeholder="Выберите из списка"
                  value={field.value}
                  onChange={(e) => field.onChange(e.value)}
                  onSelect={(e) => field.onChange(e.value)}
                  onBlur={() =>
                    field.onChange(field.value && field.value.trim())
                  }
                  inputClassName="w-full"
                />
              )}
            />
          </div>

          {!isEditing && (
            <>
              <Divider className="my-2" />

              <div className={formStyle.field}>
                <Controller
                  name="uploadedFile"
                  control={control}
                  rules={{
                    required: 'Обязательное поле',
                    validate: {
                      ...(fieldsMetadata?.doc_name?.regexPattern &&
                        fieldsMetadata?.doc_name?.validationMessage && {
                          pattern: (value: File | null) => {
                            if (!value) return true;
                            return (
                              new RegExp(
                                fieldsMetadata.doc_name!.regexPattern!,
                              ).test(value.name) ||
                              fieldsMetadata.doc_name!.validationMessage!
                            );
                          },
                        }),
                      ...(fieldsMetadata?.doc_name?.maxLength && {
                        maxLength: (value: File | null) => {
                          if (!value) return true;
                          const maxLength = fieldsMetadata.doc_name!.maxLength!;
                          return (
                            value.name.length <= maxLength ||
                            `Максимальное количество символов: ${maxLength}`
                          );
                        },
                      }),
                    },
                  }}
                  render={({ field }) => (
                    <FileUpload
                      maxFileSize={1000000}
                      emptyTemplate={
                        <>
                          <p className="text-base font-medium text-center">
                            Выберите файл
                          </p>
                          <p className="mt-1 text-small text-surface-500 text-center">
                            или перетащите с компьютера
                          </p>
                        </>
                      }
                      itemTemplate={(file, props) => (
                        <div className="p-0 flex align-items-center">
                          <div>
                            <p className="text-left break-all">
                              {(file as FileUploadObject).name}
                            </p>
                            <p className="mt-1 text-left">
                              {formatBytes((file as FileUploadObject).size)}
                            </p>
                          </div>
                          <Button
                            type="button"
                            icon="pi pi-trash"
                            className="p-button-text p-button-rounded p-button-danger ml-auto flex-shrink-0"
                            onClick={props.onRemove}
                          />
                        </div>
                      )}
                      chooseLabel="Выбрать файл"
                      chooseOptions={{ className: 'p-button-outlined' }}
                      uploadOptions={{ className: 'hidden' }}
                      cancelOptions={{ className: 'hidden' }}
                      pt={{ progressbar: { root: { className: 'hidden' } } }}
                      onSelect={(e) => field.onChange(e.files[0])}
                      onRemove={() => field.onChange(null)}
                    />
                  )}
                />
                {getFormErrorMessage(errors, 'uploadedFile')}
              </div>
            </>
          )}
        </div>

        <div className="flex justify-between border-t mt-6 p-5">
          <Button
            className="w-fit"
            type="submit"
            disabled={
              isLoading ||
              !(
                isEditing
                  ? editFormRequiredFields
                  : [
                      ...addFormRequiredFields,
                      ...(showNewContractInput
                        ? ['newContract' as keyof AddFormValues]
                        : []),
                    ]
              ).every((requiredField) => formValues[requiredField])
            }
          >
            {isEditing ? 'Редактировать документ' : 'Загрузить файл'}
          </Button>
          <Button className="w-fit" text type="button" onClick={onHide}>
            Отменить
          </Button>
        </div>
      </form>
    </>
  );
};

export default UploadForm;
