import React from 'react';
import { ItemAttribute } from '@/app/pages/clients/ClientCardPage/types';

interface AttributesBlockProps<T> {
  item: T;
  itemAttributes: ItemAttribute<T>[];
}

const AttributesBlock = <T,>({
  item,
  itemAttributes,
}: AttributesBlockProps<T>) => {
  return (
    <div className="flex flex-col gap-y-2 overflow-y-auto min-h-50">
      {itemAttributes.map(({ title, field }) => (
        <div
          key={title}
          className="grid grid-cols-[230px_auto] gap-x-6 items-center"
        >
          <div className="text-sm text-surface-500">{title}</div>
          <div className="text-sm text-surface-900">
            {item[field] as string}
          </div>
        </div>
      ))}
    </div>
  );
};

export default AttributesBlock;
