import {
  ClientDocument,
  ClientFolder,
  ClientFolderProperties,
  DocumentProperties,
  IndividualClient,
  IndividualClientProperties,
  LegalClient,
  LegalClientProperties,
} from '@/types';

export type IndividualClientWithProperties = IndividualClient &
  IndividualClientProperties & {
    fio: string;
    formattedIdentDocBeginDate: string;
    formattedBirthDate: string;
    formattedCreatedDate: string;
  };

export type LegalClientWithProperties = LegalClient &
  LegalClientProperties & {
    formattedCreatedDate: string;
  };

export type ClientDocumentWithProperties = ClientDocument &
  DocumentProperties & {
    invalid: boolean;
    expired: boolean;
    formattedCreationDate: string;
    formattedValidity: string;
  };

export type ClientFolderWithProperties = ClientFolder &
  ClientFolderProperties & {
    isActual: string;
  };

export interface ItemAttribute<T> {
  title: string;
  field: keyof T;
}

// T - type for folder, V - type for folder items
interface FolderNode<T, V> {
  key: string;
  label: string;
  children: FolderNode<T, V>[];
  type: 'root' | 'global' | 'client';
  parent: FolderNode<T, V> | null;
  info: T | null;
  files: V[];
}

export type TreeFolderNode = FolderNode<
  ClientFolderWithProperties,
  ClientDocumentWithProperties
>;

export interface DocumentVersion {
  lastModified: number;
  latest: boolean;
  versionId: string;
}
