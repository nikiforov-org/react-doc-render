import {
  ClientDocumentWithProperties,
  ClientFolderWithProperties,
  IndividualClientWithProperties,
  ItemAttribute,
  LegalClientWithProperties,
} from '@/app/pages/clients/ClientCardPage/types';

export const INDIVIDUAL_CLIENT_OBJECT_TYPE = 'individual_clients';
export const LEGAL_CLIENT_OBJECT_TYPE = 'legal_clients';
export const CLIENT_FOLDER_OBJECT_TYPE = 'client_folders';

export const formStyle = {
  container: 'px-5 flex flex-col gap-6',
  field: 'flex flex-col gap-2',
};

export const clientFolderAttributes: ItemAttribute<ClientFolderWithProperties>[] =
  [
    {
      title: 'Наименование',
      field: 'folder_name',
    },
    {
      title: 'Описание',
      field: 'description',
    },
    {
      title: 'Статус активности',
      field: 'isActual',
    },
  ];

export const documentAttributes: ItemAttribute<ClientDocumentWithProperties>[] =
  [
    {
      title: 'Идентификатор документа',
      field: 'id',
    },
    {
      title: 'Номер документа',
      field: 'doc_number',
    },
    {
      title: 'Дата создания документа',
      field: 'formattedCreationDate',
    },
    {
      title: 'Статус документа',
      field: 'status',
    },
    {
      title: 'Вид оригинала',
      field: 'original_type',
    },
    {
      title: 'Статус оригинала',
      field: 'original_status',
    },
    {
      title: 'Срок действия документа',
      field: 'formattedValidity',
    },
    {
      title: 'Место хранения документа',
      field: 'storage',
    },
  ];

export const individualClientAttributes: ItemAttribute<IndividualClientWithProperties>[] =
  [
    {
      title: 'Идентификатор клиента',
      field: 'id',
    },
    {
      title: 'ФИО',
      field: 'fio',
    },
    {
      title: 'ИНН',
      field: 'inn',
    },
    {
      title: 'Тип ДУЛ',
      field: 'ident_doc_type',
    },
    {
      title: 'Серия ДУЛ',
      field: 'ident_doc_series',
    },
    {
      title: 'Номер ДУЛ',
      field: 'ident_doc_number',
    },
    {
      title: 'Дата выдачи ДУЛ',
      field: 'formattedIdentDocBeginDate',
    },
    {
      title: 'День рождения',
      field: 'formattedBirthDate',
    },
    {
      title: 'Место рождения',
      field: 'birth_region',
    },
    {
      title: 'Дата добавления клиента',
      field: 'formattedCreatedDate',
    },
    {
      title: 'Статус',
      field: 'status',
    },
  ];

export const legalClientAttributes: ItemAttribute<LegalClientWithProperties>[] =
  [
    {
      title: 'Идентификатор клиента',
      field: 'id',
    },
    {
      title: 'ИНН',
      field: 'inn',
    },
    {
      title: 'Наименование клиента',
      field: 'name',
    },
    {
      title: 'Краткое наименование клиента',
      field: 'short_name',
    },
    {
      title: 'ОГРН',
      field: 'ogrn',
    },
    {
      title: 'КИО',
      field: 'kio',
    },
    {
      title: 'КПП',
      field: 'kpp',
    },
    {
      title: 'Дата добавления клиента',
      field: 'formattedCreatedDate',
    },
    {
      title: 'Статус',
      field: 'status',
    },
  ];
