import { ClientTableColumn, FilterFormValues } from './types';

export const INDIVIDUAL = 'Физическое лицо';
export const LEGAL_ENTITY = 'Юридическое лицо';
export const SEARCH_INDIVIDUAL_KEY = 'searchIndividualValue';
export const SEARCH_LEGAL_KEY = 'searchLegalValue';
export const CLIENT_FILTER_KEY = 'clientFilterValues';

export const docType = {
  query: {
    match_all: {},
  },
  dictionaryNames: 'identity_types',
};

export const individualFormValues = {
  first_name: '',
  last_name: '',
  patronymic: '',
  inn: '',
  ident_doc_type: null,
  ident_doc_series: '',
  ident_doc_number: '',
  ident_doc_begin_date: null,
  birth_date: null,
  birth_region: null,
};

export const legalFormValues = {
  name: '',
  short_name: '',
  inn: '',
  ogrn: '',
  kio: '',
  kpp: '',
};

export const initialFilterValues: FilterFormValues = {
  ident_doc_type: null,
  ident_doc_begin_date: null,
  birth_date: null,
};

export const formStyle = {
  container: 'px-5 flex flex-col gap-6',
  field: 'flex flex-col gap-2',
};

export const individualTableColumn: ClientTableColumn[] = [
  { field: 'fio', header: 'ФИО', width: '300px', body: true },
  { field: 'birth_date', header: 'Дата рождения', width: '200px', body: true },
  { field: 'inn', header: 'ИНН', width: '200px' },
  { field: 'status', header: 'Статус', width: 'full' },
];

export const legalTableColumn: ClientTableColumn[] = [
  { field: 'name', header: 'Наименование организации', width: '450px' },
  { field: 'inn', header: 'ИНН', width: '200px' },
  { field: 'kpp', header: 'КПП', width: '200px' },
  { field: 'status', header: 'Статус', width: 'full' },
];
