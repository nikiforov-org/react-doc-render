import { LegalClient, IndividualClient } from '@/types';

export interface FormProps {
  onHide: () => void;
  identDocTypes?: { name: string; value: string }[];
}

export interface IndividualFormValues {
  first_name: string;
  last_name: string;
  patronymic: string;
  inn: string;
  ident_doc_type: string | null;
  ident_doc_series: string;
  ident_doc_number: string;
  ident_doc_begin_date: Date | null;
  birth_date: Date | null;
  birth_region: string | null;
}

export interface LegalFormValues {
  name: string;
  short_name: string;
  inn: string;
  ogrn: string;
  kio: string;
  kpp: string;
}

export type IndividualFormKeys = keyof IndividualFormValues;
export type LegalFormKeys = keyof LegalFormValues;

export type FilterFormValues = {
  ident_doc_type: string | null;
  ident_doc_begin_date: Date | null;
  birth_date: Date | null;
};

export type ClientTableData = LegalClient | IndividualClient;

export interface TransformedTableData extends Omit<ClientTableData['properties'], keyof ClientTableData>{
  id?: string;
}

export interface ClientTableColumn {
  field: string;
  header: string;
  width: string;
  body?: boolean;
}

export interface ClientsTableProps {
  type?: string;
  formAction?: () => void;
  column?: ClientTableColumn[];
  objectTypes?: string[];
}
