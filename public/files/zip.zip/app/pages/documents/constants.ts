import { DocumentFilterFormValues } from './types';

export const DOCUMENTS = 'Документы';
export const SEARCH_DOCUMENT_KEY = 'searchDocumentValue';

export const documentInitialFilterValues: DocumentFilterFormValues = {
  status: null,
  system_creation_date: null,
  validity: null,
  original_type: null,
  original_status: null,
  storage: null,
};

export const statusesQueryJson = {
  match: {
    match_all: {},
  },
  dictionaryName: 'original_statuses',
};

export const isDate = /^\d{2}-\d{2}-\d{4}$/;
