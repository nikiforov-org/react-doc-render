'use client';
import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FormProvider, useForm } from 'react-hook-form';
import { Badge } from 'primereact/badge';
import { Button } from 'primereact/button';
import { Chip } from 'primereact/chip';
import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import Drawer from '@/components/Drawer';
import EmptyList from '@/components/EmptyList';
import SearchInput from '@/components/SearchInput';
import DocumentFilter from '@/app/pages/documents/components/DocumentFilter';
import {
  documentInitialFilterValues,
  SEARCH_DOCUMENT_KEY,
} from '@/app/pages/documents/constants';
import {
  DocumentFilterFormValues,
  DocumentsData,
  DocumentTableProps,
} from '@/app/pages/documents/types';
import { getFilterValues } from '@/utils/getFiltersValue';
import {
  getItemFromLocalStorage,
  setItemToLocalStorage,
} from '@/utils/localStorage';
import {
  findDocumentByFilter,
} from '@/app/pages/documents/services';
import { classNames } from 'primereact/utils';
import MimeIcon from '@/components/MimeIcon';
import { useAppDispatch } from '@/store/hooks';
import { selectDocument } from '@/app/pages/documents/slice';
import { Spinner } from '@/components/Spinner';
import InfiniteScrollWrapper from '@/components/InfiniteScrollWrapper';
import FilePreview from '@/components/FilePreview';
import { Dialog } from 'primereact/dialog';
import { ClientDocument } from '@/types';
import SmallIconButton from '@/components/SmallIconButton';

type FilterKeys = keyof DocumentFilterFormValues;
const filterLabels: Record<FilterKeys, string> = {
  status: 'Статус документа',
  validity: 'Срок действия',
  original_type: 'Вид оригинала',
  original_status: 'Статус оригинала',
  storage: 'Место хранения',
  system_creation_date: 'Дата размещения документа в ЭА',
};

const DocumentsTable = ({ objectTypes }: DocumentTableProps) => {
  const [formVisible, setFormVisible] = useState(false);
  const [selectedRow, setSelectedRow] = useState<ClientDocument | null>(null);
  const [searchValue, setSearchValue] = useState<string>('');
  const [documentsData, setDocumentsData] = useState<DocumentsData[] | []>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [previewUri, setPreviewUri] = useState<string | null>(null);
  const [previewVisible, setPreviewVisible] = useState<boolean>(false);

  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const savedFilters = getItemFromLocalStorage('filterValues');
  let chipsValues: Partial<DocumentFilterFormValues> | null = null;
  if (savedFilters) {
    chipsValues = Object.fromEntries(
      Object.entries(savedFilters).filter(
        ([key, value]) =>
          Object.hasOwn(documentInitialFilterValues, key) &&
          (value instanceof Date || typeof value === 'string'),
      ),
    ) as Partial<DocumentFilterFormValues>;
  }
  const storageFilterValues: DocumentFilterFormValues = {
    ...documentInitialFilterValues,
    ...(chipsValues ?? {}),
  };
  const methods = useForm<DocumentFilterFormValues>({
    defaultValues: storageFilterValues,
    mode: 'all',
  });

  const filterChipsValues = chipsValues
    ? getFilterValues<FilterKeys>(chipsValues, filterLabels)
    : [];

  const hasAnyFilter =
    chipsValues &&
    Object.values(chipsValues)?.some((element) => Boolean(element));

  const onFilterValueReset = (key: FilterKeys) => {
    const data = methods.getValues();
    methods.resetField(key);

    if (data.hasOwnProperty(key)) data[key] = null;

    methods.setValue(key, null, { shouldDirty: true });
    setItemToLocalStorage('filterValues', data);
    void handleDocumentData();
  };

  const handleDocumentData = async (
    newSearchValue?: string,
    currentOffset?: number,
    type?: string,
  ) => {
    const data = methods.getValues();
    try {
      if (!currentOffset) {
        setDocumentsData([]);
        setIsLoading(true);
      }
      const documents = await findDocumentByFilter(
        data,
        objectTypes,
        newSearchValue ?? searchValue,
        currentOffset ?? offset,
      );
      const newDocs = await documents.json();

      if (type === 'add') {
        setDocumentsData((prev) => [...prev, ...newDocs]);
        setHasMore(newDocs.length > 0);
      } else {
        setDocumentsData(newDocs);
        setOffset(0);
        setHasMore(newDocs.length >= 30);
      }
    } catch (error) {}

    setIsLoading(false);
  };

  useEffect(() => {
    const savedDocumentValue = getItemFromLocalStorage(SEARCH_DOCUMENT_KEY);
    if (hasAnyFilter || savedDocumentValue) {
      void handleDocumentData(savedDocumentValue, 0);
    }
  }, []);

  useEffect(() => {
    const savedSearchValue = getItemFromLocalStorage(SEARCH_DOCUMENT_KEY);
    if (savedSearchValue) {
      setSearchValue(savedSearchValue);
    }
  }, []);

  const handleDrawerOpen = () => {
    setFormVisible((prev) => !prev);
  };

  const handlePreview = useCallback((uri: string) => {
    setPreviewUri(uri);
    setPreviewVisible(true);
  }, []);

  const searchButtonClick = (newSearchValue: string) => {
    setSearchValue(newSearchValue);
    setItemToLocalStorage(SEARCH_DOCUMENT_KEY, newSearchValue);
    const data = methods.getValues();
    setItemToLocalStorage('filterValues', data);
    void handleDocumentData(newSearchValue, 0);
  };

  const infiniteScrollNext = () => {
    if (documentsData?.length > 0) {
      void handleDocumentData('', offset + 30, 'add');
      setOffset((prev) => prev + 30);
    }
  };

  const folderNameCellTemplate = (rowData: ClientDocument) => {
    const [folderName] = rowData.properties.system_key.split('/').slice(-2, -1);
    const onClick = () => {
      dispatch(selectDocument(rowData.id));
      navigate(`/clients/${rowData.properties.client_id}`);
    };

    return (
      <span
        onClick={onClick}
        className="cursor-pointer text-primary-500 break-all"
      >
        {folderName}
      </span>
    );
  };

  return (
    <>
      <div className="flex flex-col gap-4">
        <div className="flex justify-between">
          <div className="flex items-center gap-4">
            <SearchInput
              onSearch={searchButtonClick}
              search={searchValue}
              setSearch={setSearchValue}
              className="min-w-100"
              placeholder="Поиск"
            />
            <Button
              className="p-overlay-badge overflow-visible"
              type="button"
              outlined
              onClick={handleDrawerOpen}
            >
              Фильтр {hasAnyFilter && <Badge severity="danger" />}
            </Button>
          </div>
        </div>

        {filterChipsValues?.length &&
        filterChipsValues.some((chip) => Boolean(chip)) ? (
          <div className="flex flex-wrap gap-2">
            {filterChipsValues?.map(
              (chip) =>
                chip && (
                  <Chip
                    key={chip.key}
                    label={chip.value}
                    removable
                    onRemove={() => onFilterValueReset(chip.key)}
                  />
                ),
            )}
          </div>
        ) : null}

        <InfiniteScrollWrapper<DocumentsData>
          data={documentsData}
          hasMore={hasMore}
          endMessage="Вы просмотрели все данные"
          onNextChange={infiniteScrollNext}
        >
          <DataTable
            value={documentsData}
            scrollable
            dataKey="id"
            emptyMessage=" "
            pt={{
              root: {
                className: classNames({ ['pb-2']: documentsData?.length }),
              },
              column: {
                headerCell: {
                  className: classNames({ 'opacity-40': isLoading }),
                },
                bodyCell: {
                  className: classNames({
                    ['border-none p-0']: !documentsData?.length || isLoading,
                  }),
                },
              },
            }}
          >
            <Column
              field="icon"
              body={(rowData) => (
                <SmallIconButton
                  icon="pi pi-eye"
                  onClick={() => {
                    setSelectedRow(rowData);
                    handlePreview(
                      `${process.env.NEXT_PUBLIC_APP_API}/files${rowData.properties.system_key}`,
                    );
                  }}
                  className="p-0"
                />
              )}
              className="w-11 min-w-11 px-1.5 py-2.5"
              pt={{ headerCell: { className: 'w-11 min-w-11' } }}
            />
            <Column
              header="Название"
              body={(rowData) => (
                <div className="flex items-center gap-2">
                  <MimeIcon
                    mimeType={rowData.properties.system_type}
                    className="w-6"
                  />
                  <span className="break-all">
                    {rowData.properties.doc_name}
                  </span>
                </div>
              )}
              className="w-[500px]"
            />
            <Column
              header="Наименование договора"
              body={folderNameCellTemplate}
              className="w-[500px]"
            />
            <Column field="properties.status" header="Статус" />
            <Column field="properties.doc_number" header="Номер" />
          </DataTable>
        </InfiniteScrollWrapper>
      </div>

      {isLoading ? <Spinner /> : null}

      {!documentsData?.length && !isLoading ? (
        <EmptyList
          title="Нет данных для отображения"
          message="Воспользуйтесь поисковой строкой и введите данные для поиска по документам"
        />
      ) : null}

      {formVisible && (
        <Drawer
          header="Параметры поиска"
          formVisible={formVisible}
          onHide={handleDrawerOpen}
        >
          <FormProvider {...methods}>
            <DocumentFilter
              findDocument={handleDocumentData}
              onHide={handleDrawerOpen}
            />
          </FormProvider>
        </Drawer>
      )}

      <Dialog
        visible={previewVisible}
        maximizable
        dismissableMask
        header={
          <div className="flex items-start gap-2">
            <MimeIcon
              mimeType={selectedRow?.properties.system_type as string}
              className="w-6"
            />
            <span className="text-sm font-normal break-all">
              {selectedRow?.properties.doc_name}
            </span>
          </div>
        }
        onHide={() => {
          if (!previewVisible) return;
          setPreviewVisible(false);
        }}
        className="w-1/2"
      >
        {previewUri && <FilePreview uri={previewUri} />}
      </Dialog>
    </>
  );
};

export default DocumentsTable;
