import React from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { DocumentFilterFormValues } from '@/app/pages/documents/types';
import { formStyle } from '@/app/pages/clients/constants';
import { setItemToLocalStorage } from '@/utils/localStorage';
import { FormField } from '@/components/FormField';
import { useMetadata } from '@/components/MetaData';
import StorageInput from '@/components/StorageInput';

interface FilterProps {
  onHide: () => void;
  findDocument: () => void;
}

const DocumentFilter = ({ findDocument, onHide }: FilterProps) => {
  const { getMetadata } = useMetadata();
  const fieldsMetadata = {
    ...(getMetadata('objectTypeMap.individual_clients_documents.fieldMap') ??
      {}),
    ...(getMetadata('objectTypeMap.legal_clients_documents.fieldMap') ?? {}),
  };

  const {
    control,
    formState: { errors },
    setValue,
    handleSubmit,
  } = useFormContext<DocumentFilterFormValues>();
  const onSubmit = (data: DocumentFilterFormValues) => {
    void findDocument();
    setItemToLocalStorage('filterValues', data);
    onHide();
  };

  return (
    <div className="flex flex-col w-full h-full pt-3">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-fluid h-full flex flex-col justify-between"
      >
        <div className={formStyle.container}>
          <FormField<DocumentFilterFormValues>
            name="status"
            label="Статус документа"
            isFilter
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<DocumentFilterFormValues>
            name="validity"
            label="Срок действия"
            isFilter
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<DocumentFilterFormValues>
            name="original_type"
            label="Вид оригинала"
            isFilter
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <FormField<DocumentFilterFormValues>
            name="original_status"
            label="Статус оригинала"
            isFilter
            fieldsMetadata={fieldsMetadata}
            control={control}
            setValue={setValue}
            errors={errors}
          />
          <div className={formStyle.field}>
            <label htmlFor="storage">Место хранения</label>
            <Controller
              name="storage"
              control={control}
              render={({ field }) => (
                <StorageInput
                  id={field.name}
                  placeholder="Выберите из списка"
                  value={field.value}
                  onChange={(e) => field.onChange(e.value)}
                  onSelect={(e) => field.onChange(e.value)}
                  onBlur={() =>
                    field.onChange(field.value && field.value.trim())
                  }
                  inputClassName="w-full"
                />
              )}
            />
          </div>

          <div className={formStyle.field}>
            <label htmlFor="system_creation_date">
              Дата размещения документа в ЭА
            </label>
            <Controller
              name="system_creation_date"
              control={control}
              render={({ field }) => {
                return (
                  <Calendar
                    id={field.name}
                    value={field.value && new Date(field.value)}
                    onChange={field.onChange}
                    dateFormat="dd.mm.yy"
                    mask="99.99.9999"
                    placeholder="__.__.____"
                    showIcon
                    pt={{ buttonbar: { className: 'bg-red-500' } }}
                  />
                );
              }}
            />
          </div>
        </div>

        <div className="flex justify-between border-t p-5 mt-5">
          <Button className="w-fit" type="submit">
            Применить фильтр
          </Button>
          <Button className="w-fit" text type="button" onClick={onHide}>
            Отменить
          </Button>
        </div>
      </form>
    </div>
  );
};

export default DocumentFilter;
