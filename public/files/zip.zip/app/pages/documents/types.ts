export interface DocumentFilterFormValues {
  status: string | null;
  system_creation_date: Date | null;
  validity: Date | null;
  original_type: string | null;
  original_status: string | null;
  storage: string | null;
}

export interface DocumentTableData {
  id: '113b39f0-b54c-49f8-930a-8293f7336f3c';
  objectType: 'legal_clients_documents';
  properties: {
    client_inn: '1234567890';
    name: 'Договор аренды';
  };
}

export interface DocumentsData {
  id: string;
  name: string;
  dossierName: string;
  status: string;
  number: string;
}

interface Column {
  field: string;
  header: string;
  width: string;
}

export interface DocumentTableProps {
  type?: string;
  column?: Column[];
  objectTypes: string[];
}

export interface DictionaryTypeResponse<T> {
  id: string;
  objectType: string;
  properties: T;
}

export interface DictionaryType {
  name: string;
  id: string;
}
