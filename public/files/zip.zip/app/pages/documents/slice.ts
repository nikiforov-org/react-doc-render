import { createAppSlice } from '@/store/createAppSlice';
import { PayloadAction } from '@reduxjs/toolkit';

interface DocumentSliceState {
  selectedDocumentID: string | null;
}

const initialState: DocumentSliceState = {
  selectedDocumentID: null,
};

const slice = createAppSlice({
  name: 'documents',
  initialState,
  reducers: {
    selectDocument: (state, action: PayloadAction<string | null>) => {
      state.selectedDocumentID = action.payload;
    },
  },
});

export const { selectDocument } = slice.actions;
export default slice.reducer;
