'use client';
import { TabPanel, TabView } from 'primereact/tabview';
import DocumentsTable from '@/app/pages/documents/components/DocumentsTable';
import { DOCUMENTS } from '@/app/pages/documents/constants';
import { useMetadata } from '@/components/MetaData';
import { useEffect, useState } from 'react';
import { getFilteredObjectTypes } from '@/utils/getFilteredObjectTypes';

const DocumentsPage = () => {
  const { loadingMetadata, getMetadata } = useMetadata();
  const [objectTypes, setObjectTypes] = useState<string[]>([]);
  /**
   * 1. getMetadata('objectTypes.individual_clients.fieldMap.id.description') возвращает 'Уникальный идентификатор клиента'
   * 2. getMetadata('objectTypes.individual_clients.fieldMap.status') возвращает 
          {
            "dataType": "TEXT",
            "nullable": false,
            "description": "Статус клиента",
            "enumValues": [
                "Активный",
                "Неактивный"
            ]
          } 
      и т. д.
   */

  useEffect(() => {
    if (!loadingMetadata) {
      const objectTypesData = getMetadata('objectTypes');
      if (objectTypesData) {
        const filteredObjectTypes = getFilteredObjectTypes(objectTypesData);
        setObjectTypes(filteredObjectTypes);
      }
    }
  }, [loadingMetadata, getMetadata]);

  return (
    <>
      <TabView
        pt={{
          root: { className: 'flex-1 flex flex-col items-start' },
          panelContainer: {
            className: 'w-full h-full flex-1 px-0 pt-4 pb-0 flex flex-col',
          },
          navContent: { className: '-mt-4' },
        }}
      >
        <TabPanel
          header={DOCUMENTS}
          pt={{ root: { className: 'flex-1 flex flex-col' } }}
        >
          <DocumentsTable objectTypes={objectTypes} type={DOCUMENTS} />
        </TabPanel>
      </TabView>
    </>
  );
};

export default DocumentsPage;
