import {
  DictionaryTypeResponse,
  DocumentFilterFormValues,
} from '@/app/pages/documents/types';
import { formatDateToISO } from '@/utils/date';

export const getDictionaryService = async <
  DictionaryValues = { [key: string]: string },
>(
  dictionaryNames: string,
  query: { [key: string]: unknown },
) => {
  const body = {
    dictionaryNames: [dictionaryNames],
    query,
    offset: 0,
    limit: 100,
  };

  try {
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_APP_API}/search-dictionary`,
      {
        method: 'POST',
        body: JSON.stringify(body),
        headers: { 'Content-Type': 'application/json' },
      },
    );
    return (await response.json()) as DictionaryTypeResponse<DictionaryValues>[];
  } catch (error) {}
};

export const findDocumentByFilter = async (
  data: DocumentFilterFormValues,
  objectTypes: string[],
  searchValue: string,
  offset: number = 0,
) => {
  const body = {
    query: {
      bool: {
        must: [
          searchValue && {
            multi_match: {
              query: searchValue,
              fields: ['doc_name'],
              type: 'phrase_prefix',
            },
          },
          data.status && {
            match: {
              status: data.status,
            },
          },
          data.system_creation_date && {
            term: {
              system_creation_date: formatDateToISO(data.system_creation_date),
            },
          },
          data.validity && {
            term: {
              validity: formatDateToISO(data.validity),
            },
          },
          data.original_type && {
            match: {
              original_type: data.original_type,
            },
          },
          data.original_status && {
            match: {
              original_status: data.original_status,
            },
          },
          data.storage && {
            match: {
              storage: data.storage,
            },
          },
          // id && {
          //   match: {
          //     created_by: id
          //   }
          // },
        ].filter(Boolean),
      },
    },
    offset: offset,
    limit: 30,
    sortOrderList: [
      {
        fieldName: 'doc_name',
        sortOrder: 'Asc',
      },
    ],
    objectType: objectTypes,
  };

  return await fetch(`${process.env.NEXT_PUBLIC_APP_API}/search-objects`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
};
