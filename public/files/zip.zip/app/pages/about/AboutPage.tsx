import { mainFeaturesOfProduct } from './constants';

export default function AboutPage() {
  return (
    <div className="flex flex-col gap-y-8 max-w-[1300px]">
      <div className="text-surface-900">
        <span className="font-medium">Электронный Архив 4.0</span> - программный
        продукт, предназначенный для формирования и поддержки единого хранилища
        электронных документов организации с возможностью гибкой адаптации
        системы под конкретную предметную область на уровне типов документов,
        структуры хранения данных, правил документооборота, прав доступа к
        данным, интеграции с другими корпоративными системами и подключения
        дополнительных сервисных возможностей.
      </div>
      <div className="flex flex-col gap-y-4 text-surface-900">
        <div className="font-medium">Основные возможности продукта:</div>
        <ul className="list-disc marker:text-primary-500 space-y-2 px-3.5 mx-4">
          {mainFeaturesOfProduct.map((text, index, array) => (
            <li key={text}>
              {text + (index === array.length - 1 ? '.' : ';')}
            </li>
          ))}
        </ul>
      </div>
      <hr className="border-surface-200" />
      <div className="flex flex-col gap-y-1">
        <div className="flex gap-x-1">
          <span className="text-surface-600">Разработчик:</span>
          <span className="font-medium text-surface-900">AO «РДТЕХ»</span>
          <a
            href="https://rdtex.ru/"
            target="_blank"
            className="underline text-surface-600"
          >
            https://rdtex.ru/
          </a>
        </div>
        <div className="flex gap-x-1">
          <span className="text-surface-600">Версия:</span>
          <span className="font-medium text-surface-900">4.1.0</span>
        </div>
      </div>
      <hr className="border-surface-200" />
      <div className="flex flex-col gap-y-1 text-surface-600">
        <div className="flex gap-x-1">
          <span>Тех.поддержка:</span>
          <a href="mailto:support@rdtex.ru" className="underline">
            support@rdtex.ru
          </a>
        </div>
        <div className="flex gap-x-1">
          <span>Телефон для справок:</span>
          <a href="tel:+74959950999" className="underline">
            +7 (495) 995-09-99
          </a>
        </div>
        <div className="flex gap-x-1">
          <span>Telegram канал:</span>
          <a
            href="https://t.me/edocarchive"
            target="_blank"
            className="underline"
          >
            @edocarchive
          </a>
        </div>
      </div>
    </div>
  );
}
