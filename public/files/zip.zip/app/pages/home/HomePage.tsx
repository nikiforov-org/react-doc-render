'use client';
import { useNavigate } from 'react-router-dom';
import { Timeline } from 'primereact/timeline';
import { Button } from 'primereact/button';

interface GuideItem {
  id: string;
  title: string;
  message: string;
  button: string;
}

export default function HomePage() {
  const navigate = useNavigate();

  const guideItems: GuideItem[] = [
    {
      id: 'client-form',
      title: 'Создайте в базе нового клиента',
      message:
        'Это нужно для начала работы с документооборотом в рамках системы. Клиенты могут быть физическими и юридическими лицами.',
      button: 'Добавить клиента',
    },
    {
      id: 'clients',
      title: 'Совершайте поиск клиентов',
      message:
        'Поиск по клиентам осуществляется в рамках юридических и физических лиц, с возможностью дополнительного применения фильтрации по типу документов и их даты выдачи.',
      button: 'Найти клиента',
    },
    {
      id: 'documents',
      title: 'Найдите архивный документ',
      message:
        'В системе доступен поиск всех типов документов по ключевым словам и критериям, которые можно указать в детальной настройке фильтра.',
      button: 'Найти документ',
    },
    {
      id: 'knowledge',
      title: 'Еще больше об архиве',
      message:
        'Познакомиться  с основными функциями продукта, узнать статус текущей версии и  обратиться в техническую поддержку вы можете на странице «О продукте». А еще можно узнать о команде и присоединиться к телеграм-каналу «Архив  4.0: Без бумаги».',
      button: 'О продукте',
    },
  ];

  const handleNavigation = (id: string) => {
    switch (id) {
      case 'client-form':
      case 'clients':
        navigate('/clients?open=clients');
        break;
      case 'documents':
        navigate('/documents');
        break;
      case 'knowledge':
        navigate('/about');
        break;
      default:
        navigate('/');
        break;
    }
  };

  const customizedContent = (item: GuideItem) => {
    const isKnowledge = item.id === 'knowledge';

    return (
      <div
        className={`${isKnowledge ? 'pb-0' : 'pb-10'} pl-2 flex flex-col items-start gap-2`}
      >
        <h2 className="text-base font-medium text-surface-900">{item.title}</h2>
        <p className="text-sm text-surface-600 mb-2">{item.message}</p>
        <Button onClick={() => handleNavigation(item.id)}>{item.button}</Button>
      </div>
    );
  };

  return (
    <div className="w-[750px] border border-surface-200 rounded-md p-6 flex flex-col gap-2">
      <h1 className="text-xl font-medium text-surface-900">Быстрый старт</h1>
      <p className="text-base font-normal text-surface-700 pb-8">
        Создали для вас путеводитель по ключевым разделам электронного архива.
      </p>
      <Timeline
        value={guideItems}
        content={customizedContent}
        pt={{ opposite: { className: 'hidden' } }}
      />
    </div>
  );
}
