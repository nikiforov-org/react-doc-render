'use client';
import React, { useContext, useEffect, useState } from 'react';
import { Button } from 'primereact/button';
import Table from '@/components/Table';
import Drawer from '@/components/Drawer';
import SearchInput from '@/components/SearchInput';
import { tableColumn } from '@/app/pages/users/constants';
import ManageUserForm from '@/app/pages/users/components/ManageUserForm';
import { TableData } from '@/app/pages/users/types';
import { ToastContext } from '@/utils/formMessages';

const UsersPage = () => {
  const [search, setSearch] = useState<string>('');

  const { showToast } = useContext(ToastContext);

  const [tableData, setTableData] = useState<TableData[]>();
  const [isLoading, setIsLoading] = useState(true);
  const updateTableData = async () => {
    try {
      setIsLoading(true);
      setTableData([]);
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_APP_API}/users/search?offset=${0}&limit=${20}${search ? `&searchText=${search}` : ''}`,
      );
      const data = (await response.json()) as TableData[];
      setTableData(data);
      setIsLoading(false);
    } catch (error) {
      showToast('error', 'Произошла ошибка при запросе пользователей');
    }
  };
  useEffect(
    function getTableData() {
      updateTableData();
    },
    [search],
  );

  const [openForm, setOpenForm] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState<TableData | null>(
    null,
  );
  const formType = !selectedRowData ? 'add' : 'edit';
  const openCreateForm = () => {
    setOpenForm(true);
    setSelectedRowData(null);
  };
  const openEditForm = (data: TableData) => {
    setOpenForm(true);
    setSelectedRowData(data);
  };
  const closeForm = () => {
    setOpenForm(false);
    setSelectedRowData(null);
  };
  const toggleEnabledUser = async (data: TableData) => {
    if (data?.id) {
      try {
        await fetch(`${process.env.NEXT_PUBLIC_APP_API}/users/${data.id}`, {
          method: 'PUT',
          body: JSON.stringify({ enabled: !data.enabled }),
          headers: { 'Content-Type': 'application/json' },
        });
        showToast(
          'success',
          data.enabled
            ? 'Пользователь успешно заблокирован!'
            : 'Пользователь успешно разблокирован!',
        );
        await updateTableData();
      } catch (error) {
        showToast('error', 'Произошла ошибка при изменении пользователя');
      }
    }
  };
  const deleteUser = async (data: TableData) => {
    if (data?.id) {
      try {
        await fetch(`${process.env.NEXT_PUBLIC_APP_API}/users/${data.id}`, {
          method: 'DELETE',
        });
        showToast('success', 'Пользователь успешно удален!');
        await updateTableData();
      } catch (error) {
        showToast('error', 'Произошла ошибка при удалении пользователя');
      }
    }
  };

  return (
    <>
      <div className="h-full flex-1 flex flex-col gap-4">
        <div className="flex justify-between items-center">
          <SearchInput
            search={search}
            setSearch={setSearch}
            className="min-w-112"
            placeholder="Найти пользователя"
            maxLength={255}
          />
          <Button
            label="Добавить пользователя"
            onClick={openCreateForm}
            className="ml-auto"
          />
        </div>

        <Table<TableData>
          editAction={openEditForm}
          toggleEnabledAction={toggleEnabledUser}
          deleteAction={deleteUser}
          tableData={tableData}
          isLoading={isLoading}
          tableColumn={tableColumn}
          areActionsEnabled
        />

        {openForm && (
          <Drawer
            header={
              formType === 'add'
                ? 'Добавление нового пользователя'
                : 'Редактирование пользователя'
            }
            formVisible={openForm}
            onHide={closeForm}
          >
            <ManageUserForm
              selectedRowData={selectedRowData}
              onTableDataChange={updateTableData}
              onHide={closeForm}
            />
          </Drawer>
        )}
      </div>
    </>
  );
};

export default UsersPage;
