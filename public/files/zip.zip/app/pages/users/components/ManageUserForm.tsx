'use client';
import React, { useContext, useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { classNames } from 'primereact/utils';
import { Checkbox } from 'primereact/checkbox';
import { formStyle } from '@/app/pages/users/constants';
import {
  AddFormValues,
  EditFormValues,
  Group,
  ManageUserFormProps,
  TableData,
} from '@/app/pages/users/types';
import { ToastContext, getFormErrorMessage } from '@/utils/formMessages';
import { MultiSelect } from 'primereact/multiselect';

const addFormDefaultValues: AddFormValues = {
  username: '',
  email: '',
  password: '',
  passwordTemporary: false,
  firstName: '',
  lastName: '',
  group: undefined,
};
const addFormRequiredFields: (keyof AddFormValues)[] = [
  'username',
  'email',
  'password',
  'lastName',
  'firstName',
];
const editFormRequiredFields: (keyof EditFormValues)[] = [
  'email',
  'lastName',
  'firstName',
];

const ManageUserForm = ({
  selectedRowData,
  onTableDataChange,
  onHide,
}: ManageUserFormProps) => {
  const type = !selectedRowData ? 'add' : 'edit';

  const { showToast } = useContext(ToastContext);

  const {
    control,
    formState: { errors, isDirty, dirtyFields: _dirtyFieldsEventSubscription },
    handleSubmit,
    reset,
    getValues,
  } = useForm<AddFormValues /*| EditFormValues*/>({
    defaultValues:
      type === 'add'
        ? addFormDefaultValues
        : {
            email: selectedRowData?.email ?? '',
            lastName: selectedRowData?.lastName ?? '',
            firstName: selectedRowData?.firstName ?? '',
            group: undefined,
          },
  });
  const formValues = getValues();
  const isFormDisabled =
    !isDirty ||
    !(type === 'add' ? addFormRequiredFields : editFormRequiredFields).every(
      (requiredField) => formValues[requiredField],
    );

  useEffect(function getSelectedUserGroup() {
    (async () => {
      if (selectedRowData) {
        try {
          const response = await fetch(
            `${process.env.NEXT_PUBLIC_APP_API}/users/${selectedRowData.id}/groups`,
          );
          const result = (await response.json()) as Group[];
          if (result.length) {
            reset(
              {
                email: selectedRowData?.email ?? '',
                lastName: selectedRowData?.lastName ?? '',
                firstName: selectedRowData?.firstName ?? '',
                group: result.map((group) => group.id),
              },
              { keepDirtyValues: true },
            );
          }
        } catch (error) {
          showToast('error', 'Произошла ошибка при запросе групп пользователя');
        }
      }
    })();
  }, []);

  const createUser = async (data: AddFormValues) => {
    try {
      const { group, ...userData } = data;
      const response = await fetch(`${process.env.NEXT_PUBLIC_APP_API}/users`, {
        method: 'POST',
        body: JSON.stringify({
          ...userData,
          enabled: true,
        }),
        headers: { 'Content-Type': 'application/json' },
      });
      const result = (await response.json()) as TableData;

      if (group && result.id) {
        await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/users/${result.id}/groups`,
          {
            method: 'PUT',
            body: JSON.stringify(group),
            headers: { 'Content-Type': 'application/json' },
          },
        );
      }

      onHide();
      showToast('success', 'Пользователь успешно добавлен!');
      reset();
      await onTableDataChange();
    } catch (error) {
      let errorMessage = 'Произошла ошибка при создании пользователя';
      if (error instanceof Error && error.cause instanceof Response) {
        if (error.cause.status === 409) {
          errorMessage = 'Пользователь с такими данными уже существует';
        }
      }
      showToast('error', errorMessage);
    }
  };

  const editUser = async (data: EditFormValues) => {
    if (selectedRowData?.id) {
      try {
        const { group, ...userData } = data;
        await Promise.all([
          fetch(
            `${process.env.NEXT_PUBLIC_APP_API}/users/${selectedRowData.id}`,
            {
              method: 'PUT',
              body: JSON.stringify(userData),
              headers: { 'Content-Type': 'application/json' },
            },
          ),
          fetch(
            `${process.env.NEXT_PUBLIC_APP_API}/users/${selectedRowData.id}/groups`,
            {
              method: 'PUT',
              body: JSON.stringify(group ? group : []),
              headers: { 'Content-Type': 'application/json' },
            },
          ),
        ]);

        onHide();
        showToast('success', 'Пользователь успешно сохранен!');
        reset();
        await onTableDataChange();
      } catch (error) {
        let errorMessage = 'Произошла ошибка при сохранении пользователя';
        if (error instanceof Error && error.cause instanceof Response) {
          if (error.cause.status === 409) {
            errorMessage = 'Пользователь с такими данными уже существует';
          }
        }
        showToast('error', errorMessage);
      }
    }
  };

  const onSubmit = (data: AddFormValues | EditFormValues) => {
    if (type === 'add') {
      createUser(data as AddFormValues);
    } else {
      editUser(data as EditFormValues);
    }
  };

  const [groups, setGroups] = useState<Group[]>([]);
  useEffect(function getGroups() {
    (async () => {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/groups`,
        );
        const data = (await response.json()) as Group[];
        setGroups(data);
      } catch (error) {
        showToast('error', 'Произошла ошибка при запросе групп');
      }
    })();
  }, []);

  return (
    <div className="h-full">
      <div className="flex flex-col h-full w-full pt-3">
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="p-fluid h-full flex flex-col justify-between"
        >
          <div className={formStyle.container}>
            {type === 'add' ? (
              <div className={formStyle.field}>
                <label
                  htmlFor="username"
                  className={classNames({ 'p-error': errors?.username })}
                >
                  Логин
                </label>
                <Controller
                  name="username"
                  control={control}
                  rules={{
                    required: 'Обязательное поле',
                    minLength: { value: 3, message: 'Минимум 3 символа' },
                    pattern: {
                      value: /^([A-Za-z0-9])+$/,
                      message: 'Только латиница и цифры, без пробелов',
                    },
                  }}
                  render={({ field, fieldState }) => (
                    <InputText
                      id={field.name}
                      pt={{ root: { maxLength: 50 } }}
                      {...field}
                      className={classNames({
                        'p-invalid': fieldState.invalid,
                      })}
                    />
                  )}
                />
                {getFormErrorMessage(errors, 'username')}
              </div>
            ) : null}

            <div className={formStyle.field}>
              <label
                htmlFor="email"
                className={classNames({ 'p-error': errors?.email })}
              >
                E-mail
              </label>
              <Controller
                name="email"
                control={control}
                rules={{ required: 'Обязательное поле' }}
                render={({ field, fieldState }) => (
                  <InputText
                    id={field.name}
                    type="email"
                    pt={{ root: { maxLength: 100 } }}
                    {...field}
                    className={classNames({ 'p-invalid': fieldState.invalid })}
                  />
                )}
              />
              {getFormErrorMessage(errors, 'email')}
            </div>

            {type === 'add' ? (
              <>
                <div className={formStyle.field}>
                  <label
                    htmlFor="password"
                    className={classNames({ 'p-error': errors?.password })}
                  >
                    Пароль
                  </label>
                  <Controller
                    name="password"
                    control={control}
                    rules={{
                      required: 'Обязательное поле',
                      minLength: { value: 8, message: 'Минимум 8 символов' },
                      pattern: {
                        value: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/,
                        message: 'Только латиница и цифры, минимум 1 цифра',
                      },
                    }}
                    render={({ field, fieldState }) => (
                      <InputText
                        id={field.name}
                        type="password"
                        {...field}
                        className={classNames({
                          'p-invalid': fieldState.invalid,
                        })}
                      />
                    )}
                  />
                  {getFormErrorMessage(errors, 'password')}
                </div>

                <div className="flex align-items-center">
                  <Controller
                    name="passwordTemporary"
                    control={control}
                    render={({ field }) => (
                      <Checkbox
                        inputId={field.name}
                        checked={Boolean(field.value)}
                        {...field}
                      />
                    )}
                  />
                  <label htmlFor="passwordTemporary" className="ml-2">
                    Временный пароль (необязательно)
                  </label>
                </div>
              </>
            ) : null}

            <div className={formStyle.field}>
              <label
                htmlFor="lastName"
                className={classNames({ 'p-error': errors?.lastName })}
              >
                Фамилия
              </label>
              <Controller
                name="lastName"
                control={control}
                rules={{ required: 'Обязательное поле' }}
                render={({ field, fieldState }) => (
                  <InputText
                    id={field.name}
                    pt={{ root: { maxLength: 50 } }}
                    {...field}
                    className={classNames({ 'p-invalid': fieldState.invalid })}
                  />
                )}
              />
              {getFormErrorMessage(errors, 'lastName')}
            </div>

            <div className={formStyle.field}>
              <label
                htmlFor="firstName"
                className={classNames({ 'p-error': errors?.firstName })}
              >
                Имя
              </label>
              <Controller
                name="firstName"
                control={control}
                rules={{
                  required: 'Обязательное поле',
                }}
                render={({ field, fieldState }) => (
                  <InputText
                    id={field.name}
                    pt={{ root: { maxLength: 50 } }}
                    {...field}
                    className={classNames({ 'p-invalid': fieldState.invalid })}
                  />
                )}
              />
              {getFormErrorMessage(errors, 'firstName')}
            </div>

            <div className={formStyle.field}>
              <label
                htmlFor="group"
                className={classNames({ 'p-error': errors?.group })}
              >
                Группа пользователя (необязательно)
              </label>
              <Controller
                name="group"
                control={control}
                render={({ field }) => (
                  <MultiSelect
                    placeholder="Выберите из списка"
                    id={field.name}
                    {...field}
                    options={groups}
                    optionValue="id"
                    optionLabel="name"
                    showClear
                    filter
                    pt={{
                      wrapper: { className: 'max-w-[376px]' },
                      item: { className: 'text-wrap break-words' },
                    }}
                  />
                )}
              />
              {getFormErrorMessage(errors, 'group')}
            </div>
          </div>

          <div className="flex justify-between border-t mt-5 p-5">
            <Button className="w-fit" type="submit" disabled={isFormDisabled}>
              {type === 'add' ? 'Добавить' : 'Сохранить'}
            </Button>
            <Button className="w-fit" text type="button" onClick={onHide}>
              Отменить
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ManageUserForm;
