export type TableData = {
  id: string;
  username: string;
  email: string;
  lastName: string;
  firstName: string;
  enabled: boolean;
};

export type Group = { id: string; name: string };

export type AddFormValues = {
  username: string;
  email: string;
  password: string;
  passwordTemporary: boolean;
  lastName: string;
  firstName: string;
  group: string[] | undefined;
};

export type EditFormValues = {
  email: string;
  lastName: string;
  firstName: string;
  group: string[] | undefined;
};

export type ManageUserFormProps = {
  selectedRowData: TableData | null;
  onTableDataChange: () => Promise<void>;
  onHide: () => void;
};
