import { Group, TableData } from './types';

export const groups: Group[] = [
  { id: '1', name: 'admin' },
  { id: '2', name: 'user' },
];

export const formStyle = {
  container: 'px-5 flex flex-col gap-6',
  field: 'flex flex-col gap-2',
};

export const tableData: TableData[] = [
  {
    id: '1',
    username: 'larin_daniil',
    firstName: 'Даниил',
    lastName: 'Ларин',
    email: 'larin_daniil@rdtex.ru',
    enabled: true,
  },
  {
    id: '2',
    username: 'denisova_alex',
    firstName: 'Александра',
    lastName: 'Денисова',
    email: 'denisova_alex@rdtex.ru',
    enabled: false,
  },
  {
    id: '3',
    username: 'morozov_ig',
    firstName: 'Игорь',
    lastName: 'Морозов',
    email: 'morozov_ig@rdtex.ru',
    enabled: true,
  },
  {
    id: '4',
    username: 'stepanova_tatiana',
    firstName: 'Татьяна',
    lastName: 'Степанова',
    email: 'stepanova_tatiana@rdtex.ru',
    enabled: false,
  },
  {
    id: '5',
    username: 'lukin_evg',
    firstName: 'Евгений',
    lastName: 'Лукин',
    email: 'lukin_evg@rdtex.ru',
    enabled: false,
  },
];

export const tableColumn = [
  { field: 'username', header: 'Логин', width: '170px' },
  {
    field: 'firstName',
    header: 'Полное имя',
    body: (rowData: TableData) => `${rowData.lastName} ${rowData.firstName}`,
    width: '150px',
  },
  { field: 'email', header: 'E-mail адрес', width: '180px' },
  {
    field: 'enabled',
    header: 'Заблокирован',
    body: (rowData: TableData) => (!rowData.enabled ? 'Да' : 'Нет'),
  },
];
