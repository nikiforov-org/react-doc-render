'use client';
import React, { useContext, useState } from 'react';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import {
  DataTable,
  DataTableFilterMeta,
  DataTableFilterMetaData,
} from 'primereact/datatable';
import { FilterMatchMode } from 'primereact/api';
import { IconField } from 'primereact/iconfield';
import { InputText } from 'primereact/inputtext';
import { InputIcon } from 'primereact/inputicon';
import { Dialog } from 'primereact/dialog';
import { classNames } from 'primereact/utils';
import { Spinner } from '@/components/Spinner';
import { ToastContext } from '@/utils/formMessages';
import SmallIconButton from '@/components/SmallIconButton';

interface Role {
  id: string;
  name: string;
  description: string;
}

interface RolesListProps {
  tableRolesData: Role[];
  isLoading: boolean;
  handleEditRole: (role: Role) => void;
  handleCreateRole: () => void;
  refreshRoles: () => void; // Callback to refresh the roles list
}

const RolesList: React.FC<RolesListProps> = ({
  tableRolesData,
  isLoading,
  handleEditRole,
  handleCreateRole,
  refreshRoles,
}) => {
  const [filters, setFilters] = useState<DataTableFilterMeta>({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
  });
  const [globalFilterValue, setGlobalFilterValue] = useState<string>('');
  const [showDialog, setShowDialog] = useState<boolean>(false);
  const [roleToDelete, setRoleToDelete] = useState<Role | null>(null);

  const { showToast } = useContext(ToastContext);

  const onGlobalFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const _filters = { ...filters };

    (_filters['global'] as DataTableFilterMetaData).value = value;

    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const handleClear = () => {
    setGlobalFilterValue('');
    setFilters({
      ...filters,
      global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    });
  };

  const buttonsRoleTemplate = (rowData: Role) => (
    <>
      <SmallIconButton
        variant="primary"
        icon="pi pi-pencil"
        aria-label="EditRole"
        onClick={() => handleEditRole(rowData)}
        className="m-2"
      />
      <SmallIconButton
        variant="danger"
        icon="pi pi-trash"
        aria-label="DeleteRole"
        onClick={() => {
          setRoleToDelete(rowData);
          setShowDialog(true);
        }}
        className="m-2"
      />
    </>
  );

  const confirmDelete = async () => {
    if (roleToDelete) {
      try {
        await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/roles/${roleToDelete.id}`,
          {
            method: 'DELETE',
          },
        );

        // Refresh roles list and show success message
        refreshRoles();
        showToast('success', `Роль "${roleToDelete.name}" успешно удалена`);
      } catch (error) {
        showToast('error', `Не удалось удалить роль "${roleToDelete.name}"`);
      } finally {
        setShowDialog(false);
        setRoleToDelete(null);
      }
    }
  };

  const cancelDelete = () => {
    setShowDialog(false);
    setRoleToDelete(null);
  };

  return (
    <div className="h-full flex-1 flex flex-col">
      <div className="flex justify-between mb-4">
        <IconField>
          <InputText
            value={globalFilterValue}
            className="min-w-112"
            placeholder="Поиск ролей пользователей"
            onChange={onGlobalFilterChange}
          />
          <InputIcon className="pi pi-search text-surface-500 right-3" />
          {globalFilterValue && (
            <InputIcon
              onClick={handleClear}
              className="pi pi-times text-surface-500 right-10 cursor-pointer"
            />
          )}
        </IconField>
        <Button
          label="Новая роль"
          aria-label="CreateRole"
          onClick={handleCreateRole}
        />
      </div>
      <DataTable
        value={tableRolesData}
        filters={filters}
        emptyMessage={!isLoading ? 'По данному запросу ничего не найдено' : ' '}
        pt={{
          root: {
            className: classNames({
              ['pb-2']: tableRolesData?.length && !isLoading,
            }),
          },
          column: {
            headerCell: { className: classNames({ 'opacity-40': isLoading }) },
            bodyCell: {
              className: classNames({
                ['border-none p-0']: !tableRolesData?.length || isLoading,
              }),
            },
          },
        }}
      >
        <Column
          field="name"
          header="Название роли"
          className="p-4 min-w-124 align-top"
        />
        <Column
          body={buttonsRoleTemplate}
          header="Действия"
          alignHeader="right"
          className="p-0 text-right w-0 align-top whitespace-nowrap"
        />
      </DataTable>

      {isLoading ? <Spinner /> : null}

      <Dialog
        visible={showDialog}
        style={{ width: '450px' }}
        header="Подтверждение удаления"
        modal
        footer={
          <>
            <Button
              label="Нет"
              icon="pi pi-times"
              onClick={cancelDelete}
              className="p-button-text"
            />
            <Button
              label="Да"
              icon="pi pi-check"
              onClick={confirmDelete}
              autoFocus
            />
          </>
        }
        onHide={() => setShowDialog(false)}
      >
        <p>Вы уверены, что хотите удалить эту роль?</p>
      </Dialog>
    </div>
  );
};

export default RolesList;
