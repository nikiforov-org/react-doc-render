import React, { useEffect, useState, useContext } from 'react';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Divider } from 'primereact/divider';
import { Checkbox } from 'primereact/checkbox';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { useMetadata } from '@/components/MetaData';
import { ToastContext } from '@/utils/formMessages';

const cellClassName = 'text-center w-[15%]';

interface Permission {
  objectType: string;
  permissions: string[];
}

interface RoleManagePageProps {
  roleData?: { id: string; name: string } | null;
  onBack: (success: boolean, message: string) => void;
}

const allPermissions = ['read', 'create', 'update', 'grant-access', 'delete'];

const RoleManagePage: React.FC<RoleManagePageProps> = ({
  roleData,
  onBack,
}) => {
  const { getMetadata } = useMetadata();
  const [objectTypes, setObjectTypes] = useState<
    {
      objectType: string;
      displayName: string;
    }[]
  >([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [roleName, setRoleName] = useState<string>('');
  const [isEditable, setIsEditable] = useState(true);

  const { showToast } = useContext(ToastContext);

  useEffect(() => {
    const getObjectTypes = () => {
      const metadata = getMetadata('objectTypes');
      if (metadata) {
        const formattedObjectTypes = Object.keys(metadata).map((key) => ({
          objectType: key,
          displayName: metadata[key]?.displayName || '',
        }));
        setObjectTypes(formattedObjectTypes);
      }
    };

    getObjectTypes();
  }, [getMetadata]);

  useEffect(() => {
    if (roleData?.id) {
      setRoleName(roleData.name);
      setIsEditable(true);
      fetch(
        `${process.env.NEXT_PUBLIC_APP_API}/roles/${roleData.id}/permissions`,
      )
        .then((response) => response.json())
        .then((data) => {
          if (Array.isArray(data)) {
            setPermissions(data);
          } else {
            showToast('error', 'Произошла ошибка при загрузке прав');
            setPermissions([]);
          }
        })
        .catch(() => {
          showToast('error', 'Произошла ошибка при загрузке прав');
          setPermissions([]);
        });
    } else {
      setRoleName('');
      setIsEditable(true);
    }
  }, [roleData]);

  const checkboxTemplate = (
    rowData: { objectType: string },
    permissionType: string,
  ) => {
    const hasPermission = permissions.some(
      (p) =>
        p.objectType === rowData.objectType &&
        (permissionType !== 'select-all'
          ? p.permissions.includes(permissionType)
          : allPermissions.every((permission) =>
              p.permissions.includes(permission),
            )),
    );

    return (
      <Checkbox
        inputId={`${rowData.objectType}-${permissionType}`}
        checked={hasPermission}
        onChange={(e) =>
          handleCheckboxChange(
            rowData.objectType,
            permissionType,
            e.checked ?? false,
          )
        }
        disabled={!isEditable}
      />
    );
  };

  const handleCheckboxChange = (
    objectType: string,
    permissionType: string,
    checked: boolean,
  ) => {
    setPermissions((prevPermissions) => {
      const newPermissions = [...prevPermissions];
      const objectIndex = newPermissions.findIndex(
        (p) => p.objectType === objectType,
      );

      if (objectIndex > -1) {
        let permissionsList = newPermissions[objectIndex].permissions;

        if (checked) {
          if (permissionType !== 'select-all') {
            if (!permissionsList.includes(permissionType)) {
              permissionsList.push(permissionType);
            }
            // Automatically add 'search' when 'read' is checked
            if (
              permissionType === 'read' &&
              !permissionsList.includes('search')
            ) {
              permissionsList.push('search');
            }
          } else {
            newPermissions[objectIndex].permissions = [...allPermissions];
          }
        } else {
          if (permissionType !== 'select-all') {
            const index = permissionsList.indexOf(permissionType);
            if (index > -1) {
              permissionsList.splice(index, 1);
            }
            // Automatically remove 'search' when 'read' is unchecked
            if (permissionType === 'read') {
              const searchIndex = permissionsList.indexOf('search');
              if (searchIndex > -1) {
                permissionsList.splice(searchIndex, 1);
              }
            }
          } else {
            permissionsList = [];
          }
        }

        // Remove the entire object if no permissions are left
        if (permissionsList.length === 0) {
          newPermissions.splice(objectIndex, 1);
        }
      } else if (checked) {
        // Create a new objectType entry if it doesn't exist and permission is checked
        newPermissions.push({
          objectType,
          permissions: [
            ...(permissionType !== 'select-all'
              ? [permissionType]
              : [...allPermissions]),
            ...(permissionType === 'read' ? ['search'] : []),
          ],
        });
      }

      return newPermissions;
    });
  };

  const handleSubmit = async () => {
    setRoleName(roleName.trim());
    if (!roleName.trim()) {
      // Show a toast message if the role name is empty
      showToast('error', 'Название роли не может быть пустым');
      return;
    }
    if (roleName.trim().length < 3) {
      showToast('error', 'Название роли должно содержать минимум 3 символа');
      return;
    }
    if (!/^[a-zA-Z0-9._-]{3,100}$/.test(roleName.trim())) {
      showToast(
        'error',
        'Название роли может содержать только латиницу, цифры, "_" и "-"',
      );
      return;
    }

    const roleId = roleData?.id;
    const roleNameText = roleName.trim();

    if (roleId) {
      try {
        try {
          // Update role
          await fetch(`${process.env.NEXT_PUBLIC_APP_API}/roles/${roleId}`, {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name: roleNameText }),
          });
        } catch (error) {
          let message = 'Не удалось обновить название роли';
          if (error instanceof Error) {
            if (error.cause instanceof Response) {
              if (error.cause.status === 409) {
                message = 'Роль с таким названием уже существует';
              }
            }
          }
          showToast(
            'error',
            `Ошибка при обновлении роли "${roleNameText}": ${message}`,
          );
          throw error;
        }

        try {
          await fetch(
            `${process.env.NEXT_PUBLIC_APP_API}/roles/${roleId}/permissions`,
            {
              method: 'PUT',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(permissions),
            },
          );

          onBack(true, `Роль "${roleNameText}" успешно обновлена`);
        } catch (error) {
          showToast(
            'error',
            `Ошибка при обновлении роли "${roleNameText}": Не удалось обновить права роли`,
          );
          throw error;
        }
      } catch (error) {}
    } else {
      try {
        let id: string | undefined;
        try {
          // Create role
          const response = await fetch(
            `${process.env.NEXT_PUBLIC_APP_API}/roles`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ name: roleNameText }),
            },
          );
          const data = await response.json();
          if (!data.id) throw new Error('Не удалось получить ID роли');
          id = data.id;
        } catch (error) {
          let message = 'Не удалось создать роль';
          if (error instanceof Error) {
            if (error.cause instanceof Response) {
              if (error.cause.status === 409) {
                message = 'Роль с таким названием уже существует';
              }
            } else {
              message = error.message;
            }
          }
          showToast(
            'error',
            `Ошибка при создании роли "${roleNameText}": ${message}`,
          );
        }

        if (id) {
          try {
            await fetch(
              `${process.env.NEXT_PUBLIC_APP_API}/roles/${id}/permissions`,
              {
                method: 'PUT',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify(permissions),
              },
            );

            onBack(true, `Роль "${roleNameText}" успешно создана`);
          } catch (error) {
            showToast(
              'error',
              `Ошибка при создании роли "${roleNameText}": Не удалось обновить права роли`,
            );
          }
        }
      } catch (error) {}
    }
  };

  return (
    <>
      <div className="flex items-center mb-8">
        <div>
          <h3 className="text-lg font-medium text-surface-600">
            {roleData
              ? `Редактирование роли "${roleData.name}"`
              : 'Создание новой роли'}
          </h3>
        </div>
        <div className="flex-grow flex justify-end">
          <Button
            label="Отменить"
            onClick={() => onBack(false, '')}
            text
            icon="pi pi-arrow-left"
            link
            className="text-primary-500"
          />
          <Button
            label={roleData ? 'Сохранить' : 'Создать'}
            className="ml-4"
            onClick={handleSubmit}
          />
        </div>
      </div>

      <div className="flex items-center pb-4">
        <label
          htmlFor="role-name"
          className="w-48 pr-4 text-sm text-right text-surface-800"
        >
          Название роли
        </label>
        <div className="flex-1">
          <InputText
            id="role-name"
            value={roleName}
            onChange={(e) => setRoleName(e.target.value)}
            onBlur={(e) => setRoleName(e.target.value.trim())}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            maxLength={100}
            className="w-96"
            disabled={!isEditable}
          />
        </div>
      </div>

      <Divider />

      <DataTable value={objectTypes} className="pt-4">
        <Column
          header="Наименование объекта"
          field="displayName"
          className=""
        />
        <Column
          body={(rowData) => checkboxTemplate(rowData, 'read')}
          className={cellClassName}
          alignHeader="center"
          header="Просмотр"
        />
        <Column
          body={(rowData) => checkboxTemplate(rowData, 'create')}
          className={cellClassName}
          alignHeader="center"
          header="Создание"
        />
        <Column
          body={(rowData) => checkboxTemplate(rowData, 'update')}
          className={cellClassName}
          alignHeader="center"
          header="Редактирование"
        />
        <Column
          body={(rowData) => checkboxTemplate(rowData, 'grant-access')}
          className={cellClassName}
          alignHeader="center"
          header="Назначение прав"
        />
        <Column
          body={(rowData) => checkboxTemplate(rowData, 'delete')}
          className={cellClassName}
          alignHeader="center"
          header="Удаление"
        />
        <Column
          body={(rowData) => checkboxTemplate(rowData, 'select-all')}
          className={cellClassName}
          alignHeader="center"
          header="Выделить все"
        />
      </DataTable>
    </>
  );
};

export default RoleManagePage;
