'use client';
import React, { useEffect, useState, useContext } from 'react';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Divider } from 'primereact/divider';
import { Checkbox } from 'primereact/checkbox';
import { ToastContext } from '@/utils/formMessages';

interface GroupManagePageProps {
  groupData: { id: string; name: string } | null;
  onBack: (success: boolean, message: string) => void;
}

const GroupManagePage: React.FC<GroupManagePageProps> = ({
  groupData,
  onBack,
}) => {
  const [roles, setRoles] = useState<{ id: string; name: string }[]>([]);
  const [selectedRoles, setSelectedRoles] = useState<Set<string>>(new Set());
  const [groupName, setGroupName] = useState<string>('');

  const { showToast } = useContext(ToastContext);

  useEffect(() => {
    const fetchRoles = async () => {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/roles`,
        );
        const data = await response.json();
        setRoles(data);
      } catch (error) {
        showToast('error', 'Не удалось загрузить роли');
      }
    };

    fetchRoles();
  }, []);

  useEffect(() => {
    if (groupData) {
      const fetchGroupRoles = async () => {
        try {
          const response = await fetch(
            `${process.env.NEXT_PUBLIC_APP_API}/groups/${groupData.id}/roles`,
          );
          const data = await response.json();
          setSelectedRoles(
            new Set(data.map((role: { id: string }) => role.id)),
          );
          setGroupName(groupData.name);
        } catch (error) {
          showToast(
            'error',
            `Не удалось загрузить роли группы "${groupData.name}"`,
          );
        }
      };

      fetchGroupRoles();
    } else {
      setGroupName('');
    }
  }, [groupData]);

  const handleCheckboxChange = (roleId: string) => {
    setSelectedRoles((prev) => {
      const updated = new Set(prev);
      if (updated.has(roleId)) {
        updated.delete(roleId);
      } else {
        updated.add(roleId);
      }
      return updated;
    });
  };

  const handleSave = async () => {
    setGroupName(groupName.trim());
    if (!groupName.trim()) {
      // Show a toast message if the group name is empty
      showToast('error', 'Название группы не может быть пустым');
      return;
    }
    if (groupName.trim().length < 3) {
      showToast('error', 'Название группы должно содержать минимум 3 символа');
      return;
    }
    if (!/^[a-zA-Z0-9._-]{3,100}$/.test(groupName.trim())) {
      showToast(
        'error',
        'Название группы может содержать только латиницу, цифры, "_" и "-"',
      );
      return;
    }

    const groupPayload = { name: groupName.trim() };
    try {
      let groupId = groupData?.id;

      if (!groupId) {
        try {
          // Creating a new group
          const response = await fetch(
            `${process.env.NEXT_PUBLIC_APP_API}/groups`,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(groupPayload),
            },
          );
          const newGroup = await response.json();
          groupId = newGroup.id;
        } catch (error) {
          let message = 'Не удалось создать группу';
          if (error instanceof Error) {
            if (error.cause instanceof Response) {
              if (error.cause.status === 409) {
                message = 'Группа с таким названием уже существует';
              }
            }
          }
          showToast(
            'error',
            `Не удалось сохранить группу "${groupName}": ${message}`,
          );
          throw error;
        }
      } else {
        try {
          // Updating the group
          await fetch(`${process.env.NEXT_PUBLIC_APP_API}/groups/${groupId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(groupPayload),
          });
        } catch (error) {
          let message = 'Не удалось обновить название группы';
          if (error instanceof Error) {
            if (error.cause instanceof Response) {
              if (error.cause.status === 409) {
                message = 'Группа с таким названием уже существует';
              }
            }
          }
          showToast(
            'error',
            `Не удалось сохранить группу "${groupName}": ${message}`,
          );
          throw error;
        }
      }

      try {
        // Updating the group's roles
        await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/groups/${groupId}/roles`,
          {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ roles: Array.from(selectedRoles) }),
          },
        );

        onBack(true, `Группа "${groupName}" успешно сохранена`);
      } catch (error) {
        showToast(
          'error',
          `Не удалось сохранить группу "${groupName}": Не удалось обновить роли группы`,
        );
      }
    } catch (error) {}
  };

  return (
    <>
      <div className="flex items-center mb-8">
        <div>
          <h3 className="text-lg font-medium text-surface-600">
            {groupData
              ? `Редактирование группы "${groupData.name}"`
              : 'Создание новой группы'}
          </h3>
        </div>
        <div className="flex-grow flex justify-end">
          <Button
            label="Отменить"
            onClick={() => onBack(false, '')}
            text
            icon="pi pi-arrow-left"
            link
            className="text-primary-500"
          />
          <Button
            label={groupData ? 'Сохранить' : 'Создать'}
            className="ml-4"
            onClick={handleSave}
          />
        </div>
      </div>

      <div className="pb-4 flex items-center">
        <label
          htmlFor="group-name"
          className="w-52 pr-4 text-sm text-right text-surface-800"
        >
          Название группы
        </label>
        <div className="flex-1">
          <InputText
            id="group-name"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            onBlur={(e) => setGroupName(e.target.value.trim())}
            onKeyDown={(e) => e.key === 'Enter' && handleSave()}
            maxLength={100}
            className="w-96"
          />
        </div>
      </div>

      <Divider />

      <div className="pt-4 flex">
        <p className="w-52 pr-4 text-sm text-right text-surface-800">
          Назначить роль в группу
        </p>
        <div className="flex-1">
          <div className="w-full bg-surface-100 rounded-md p-4">
            {roles.map((role) => (
              <div key={role.id} className="mb-4 last:mb-0">
                <Checkbox
                  inputId={role.id}
                  checked={selectedRoles.has(role.id)}
                  onChange={() => handleCheckboxChange(role.id)}
                />
                <label
                  htmlFor={role.id}
                  className="ml-2 text-sm text-surface-700"
                >
                  {role.name}
                </label>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default GroupManagePage;
