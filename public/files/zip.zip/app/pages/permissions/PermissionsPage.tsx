'use client';
import React, { useEffect, useState, useContext } from 'react';
import RolesList from './components/RolesList';
import GroupsList from './components/GroupsList';
import GroupManagePage from './components/GroupManagePage';
import { TabPanel, TabView } from 'primereact/tabview';
import RoleManagePage from './components/RoleManagePage';
import { ToastContext } from '@/utils/formMessages';

interface Role {
  id: string;
  name: string;
  description: string;
}

interface Group {
  id: string;
  name: string;
  source: string;
}

const PermissionsPage: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<
    'permissionsPage' | 'roleManagePage' | 'groupManagePage'
  >('permissionsPage');
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [roles, setRoles] = useState<Role[]>([]);
  const [areRolesLoading, setAreRolesLoading] = useState(true);
  const [groups, setGroups] = useState<Group[]>([]);
  const [areGroupsLoading, setAreGroupsLoading] = useState(true);

  const { showToast } = useContext(ToastContext);

  useEffect(() => {
    if (currentPage === 'permissionsPage') {
      fetchRoles();
      fetchGroups();
    }
  }, [currentPage]);

  const fetchRoles = async () => {
    try {
      setAreRolesLoading(true);
      const response = await fetch(`${process.env.NEXT_PUBLIC_APP_API}/roles`);
      const data = await response.json();
      if (data) {
        setRoles(data);
        setAreRolesLoading(false);
      }
    } catch (error) {
      showToast('error', 'Ошибка при запросе ролей');
    }
  };

  const fetchGroups = async () => {
    try {
      setAreGroupsLoading(true);
      const response = await fetch(`${process.env.NEXT_PUBLIC_APP_API}/groups`);
      const data = await response.json();
      if (data) {
        setGroups(data);
        setAreGroupsLoading(false);
      }
    } catch (error) {
      showToast('error', 'Ошибка при запросе групп');
    }
  };

  const handleEditRole = (role: Role) => {
    setSelectedRole(role);
    setCurrentPage('roleManagePage');
  };

  const handleCreateRole = () => {
    setSelectedRole(null);
    setCurrentPage('roleManagePage');
  };

  const handleEditGroup = (group: Group) => {
    setSelectedGroup(group);
    setCurrentPage('groupManagePage');
  };

  const handleCreateGroup = () => {
    setSelectedGroup(null);
    setCurrentPage('groupManagePage');
  };

  const handleBack = () => {
    setCurrentPage('permissionsPage');
  };

  const handleManagePageBack = (success: boolean, message: string) => {
    handleBack();
    if (message.length > 0) {
      showToast(success ? 'success' : 'error', message);
    }
  };

  return (
    <>
      {currentPage === 'permissionsPage' ? (
        <div className="flex-1 flex flex-col gap-4">
          <TabView
            activeIndex={activeIndex}
            onTabChange={(e) => setActiveIndex(e.index)}
            className="w-full h-full flex flex-col"
            pt={{
              panelContainer: {
                className: 'min-h-0 px-0 py-4 flex-1 flex flex-col',
              },
              navContent: { className: '-mt-4' },
            }}
          >
            <TabPanel header="Роли" pt={{ content: { className: 'flex-1' } }}>
              <RolesList
                tableRolesData={roles}
                isLoading={areRolesLoading}
                handleEditRole={handleEditRole}
                handleCreateRole={handleCreateRole}
                refreshRoles={fetchRoles}
              />
            </TabPanel>
            <TabPanel header="Группы" pt={{ content: { className: 'flex-1' } }}>
              <GroupsList
                tableGroupsData={groups}
                isLoading={areGroupsLoading}
                handleEditGroup={handleEditGroup}
                handleCreateGroup={handleCreateGroup}
                refreshGroups={fetchGroups}
              />
            </TabPanel>
          </TabView>
        </div>
      ) : currentPage === 'roleManagePage' ? (
        <RoleManagePage roleData={selectedRole} onBack={handleManagePageBack} />
      ) : (
        <GroupManagePage
          groupData={selectedGroup}
          onBack={handleManagePageBack}
        />
      )}
    </>
  );
};

export default PermissionsPage;
