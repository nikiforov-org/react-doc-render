import { configureStore } from '@reduxjs/toolkit';
import clientReducer from '@/app/pages/clients/slice';
import documentReducer from '@/app/pages/documents/slice';
import breadcrumbReducer from '@/components/breadcrumbsSlice';

const rootReducer = {
  client: clientReducer,
  documents: documentReducer,
  breadcrumb: breadcrumbReducer,
};

export const makeStore = () => {
  return configureStore({
    reducer: rootReducer,
    middleware: (getDefaultMiddleware) => {
      return getDefaultMiddleware().concat();
    },
  });
};

export type RootState = ReturnType<ReturnType<typeof makeStore>['getState']>;
export type AppStore = ReturnType<typeof makeStore>;
export type AppDispatch = AppStore['dispatch'];
