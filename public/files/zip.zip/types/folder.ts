export interface ClientFolderProperties {
  client_inn: string;
  client_id: string;
  folder_name: string;
  description?: string;
  is_actual: boolean;
  system_key: string;
  system_object_role: 'file' | 'folder';
  system_creation_date: string;
}

export interface GlobalFolderProperties {
  folder_name: string;
  description?: string;
  is_actual: boolean;
  order_number: number;
}
