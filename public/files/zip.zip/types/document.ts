export interface DocumentProperties {
  client_inn: string;
  client_id: string;
  doc_name: string;
  doc_number: string;
  status: string;
  is_actual: boolean;
  validity?: string;
  original_type: string;
  original_status?: string;
  storage?: string;
  system_type: string;
  system_key: string;
  system_object_role: 'file' | 'folder';
  system_creation_date: string;
}

export interface OriginalStatusProperties {
  status_name: string;
}

export interface StorageLocationProperties {
  location_name: string;
}
