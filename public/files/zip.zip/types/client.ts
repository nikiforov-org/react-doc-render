export interface IndividualClientProperties {
  status: string;
  last_name: string;
  first_name: string;
  patronymic?: string;
  inn: string;
  ident_doc_type: string;
  ident_doc_series?: string;
  ident_doc_number: string;
  ident_doc_begin_date: string;
  birth_date: string;
  birth_region?: string;
  system_creation_date: string;
}

export interface LegalClientProperties {
  status: string;
  short_name?: string;
  name: string;
  inn: string;
  ogrn: string;
  kio?: string;
  kpp?: string;
  system_creation_date: string;
}

export interface IdentityTypeProperties {
  identity_type_name: string;
}

export interface RegionProperties {
  region_name: string;
}
