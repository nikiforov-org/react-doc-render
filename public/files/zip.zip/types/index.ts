import {
  IdentityTypeProperties,
  IndividualClientProperties,
  LegalClientProperties,
  RegionProperties,
} from './client';
import {
  DocumentProperties,
  OriginalStatusProperties,
  StorageLocationProperties,
} from './document';
import { ClientFolderProperties, GlobalFolderProperties } from './folder';

export * from './client';
export * from './document';
export * from './folder';

export interface DictionaryTypeEntity<T> {
  objectType: string;
  id: string;
  properties: T;
}

export type IndividualClient = DictionaryTypeEntity<IndividualClientProperties>;
export type LegalClient = DictionaryTypeEntity<LegalClientProperties>;
export type ClientDocument = DictionaryTypeEntity<DocumentProperties>;
export type IdentityType = DictionaryTypeEntity<IdentityTypeProperties>;
export type Region = DictionaryTypeEntity<RegionProperties>;
export type OriginalStatus = DictionaryTypeEntity<OriginalStatusProperties>;
export type StorageLocation = DictionaryTypeEntity<StorageLocationProperties>;
export type ClientFolder = DictionaryTypeEntity<ClientFolderProperties>;
export type GlobalFolder = DictionaryTypeEntity<GlobalFolderProperties>;
