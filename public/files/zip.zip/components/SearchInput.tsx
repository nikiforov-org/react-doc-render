'use client'
import React, { ChangeEvent, useEffect, useState } from 'react';
import { IconField } from "primereact/iconfield";
import { InputIcon } from "primereact/inputicon";
import { InputText } from "primereact/inputtext";

interface SearchInputProps {
  placeholder?: string;
  className?: string;
  search: string;
  setSearch?: (value: string) => void;
  onSearch?: (newSearch: string) => void;
  maxLength?: number;
}

const SearchInput = ({ onSearch, setSearch, search, placeholder, className, maxLength }: SearchInputProps) => {
  const [inputText, setInputText] = useState("");

  const handleClear = () => {
    setInputText('');
    setSearch?.('');
    onSearch && onSearch('');
  };

  useEffect(() => {
    search && setInputText(search);
  }, [search]);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);
  };

  const handleSearch = () => {
    const trimmedInput = inputText.trim();
    setInputText(trimmedInput);
    setSearch?.(trimmedInput);
    onSearch && onSearch(trimmedInput);
  };

  const onKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      handleSearch();
    }
  }

  return (
    <IconField>
      <InputText
        value={inputText}
        placeholder={placeholder}
        onChange={handleInputChange}
        onKeyDown={onKeyDown}
        onBlur={() => setInputText(inputText.trim())}
        pt={{ root: { maxLength, className } }}
      />
      <InputIcon
        onClick={handleSearch}
        className="pi pi-search text-surface-500 right-3 cursor-pointer"
      />
      {inputText || search ? (
        <InputIcon
          onClick={handleClear}
          className="pi pi-times text-surface-500 right-10 cursor-pointer"
        />
      ) : null}
    </IconField>
  );
};

export default SearchInput;
