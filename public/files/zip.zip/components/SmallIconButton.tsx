import { Button, ButtonProps } from 'primereact/button';
import { FC } from 'react';

const baseButtonClassName = 'w-8 h-8 border-0 hover:ease-in focus:shadow-none';

const buttonDefaultStyles =
  'bg-surface-0 text-surface-600 hover:bg-surface-100';

interface SmallIconButtonProps extends Omit<ButtonProps, 'severity'> {
  variant?: 'primary' | ButtonProps['severity'];
}

const SmallIconButton: FC<SmallIconButtonProps> = ({
  variant,
  className = '',
  ...props
}) => {
  return (
    <Button
      text
      rounded
      severity={variant !== 'primary' ? variant : undefined}
      className={`${baseButtonClassName} ${variant ? '' : buttonDefaultStyles} ${className}`}
      {...props}
    />
  );
};

export default SmallIconButton;
