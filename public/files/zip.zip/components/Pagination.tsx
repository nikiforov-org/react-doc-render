'use client';
import React, {useState} from 'react';
import { Paginator, PaginatorPageChangeEvent } from 'primereact/paginator';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';

const Pagination = () => {
  const [first, setFirst] = useState(0);
  const [rowsCount, setRowsCount] = useState(10);

  const template = {layout: "FirstPageLink PageLinks LastPageLink"}
  const dropdownOptions = [
    {label: 10, value: 10},
    {label: 20, value: 20},
    {label: 30, value: 30},
  ];

  const onDropdownChange = (e: DropdownChangeEvent) => {
    setRowsCount(e.value);
  };

  const onPageChange = (event: PaginatorPageChangeEvent) => {
    setFirst(event.first);
  };

  return (
    <div className="flex justify-between items-center">
      <div>
        <span className="mx-1">На странице:</span>
        <Dropdown
          value={rowsCount}
          options={dropdownOptions}
          onChange={onDropdownChange}
        />
      </div>

      <Paginator
        template={template}
        first={first}
        rows={rowsCount}
        totalRecords={120}
        onPageChange={onPageChange}
      />
    </div>
  );
};

export default Pagination;
