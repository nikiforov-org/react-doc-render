'use client';
import { ToastContext } from '@/utils/formMessages';
import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from 'react';

export type Field = {
  dataType: 'TEXT' | 'BOOLEAN' | 'UUID' | 'TIMESTAMP';
  nullable: boolean;
  description?: string;
  enumValues?: string[];
  lookupField?: {
    field: string;
    objectType: string;
  };
  minLength?: number;
  maxLength?: number;
  regexPattern?: string;
  validationMessage?: string;
};

export type ObjectType = {
  dictionary: boolean;
  displayName: string;
  fieldMap: { [key: string]: Field };
};

export type Metadata = {
  objectTypeMap: { [key: string]: ObjectType };
  objectTypes: { [key: string]: ObjectType };
  versionId: string;
};

// utility type for accessing deep properties
type PathAccess<T, K extends string> = K extends `${infer Key}.${infer Rest}`
  ? Key extends keyof T
    ? PathAccess<T[Key], Rest>
    : undefined
  : K extends keyof T
    ? T[K]
    : undefined;

interface MetadataContextProps {
  loadingMetadata: boolean;
  getMetadata: <T extends string>(path: T) => PathAccess<Metadata, T> | null;
}

const MetadataContext = createContext<MetadataContextProps | undefined>(
  undefined,
);

interface MetaDataProps {
  children: ReactNode;
}

export const MetaData: React.FC<MetaDataProps> = ({ children }) => {
  const [metadata, setMetadata] = useState<Metadata | null>(null);
  const [loadingMetadata, setLoadingMetadata] = useState(true);

  const { showToast } = useContext(ToastContext);

  useEffect(() => {
    const fetchMetadata = async () => {
      try {
        const response = await fetch(
          `${process.env.NEXT_PUBLIC_APP_API}/meta-data`,
        );
        const data = await response.json();
        setMetadata(data);
      } catch (error) {
        showToast(
          'error',
          'Произошла ошибка при попытке соеденения с сервером, попробуйте перезагрузить страницу',
        );
      } finally {
        setLoadingMetadata(false);
      }
    };

    void fetchMetadata();
  }, []);

  const getMetadata = <T extends string>(
    path: T,
  ): PathAccess<Metadata, T> | null => {
    if (!metadata) return null;
    const keys = path.split('.');
    let result: unknown = metadata;

    for (const key of keys) {
      if (typeof result === 'object' && result !== null && key in result) {
        result = (result as { [key: string]: unknown })[key];
      } else {
        return null;
      }
    }
    return result as PathAccess<Metadata, T> | null;
  };

  return (
    <MetadataContext.Provider value={{ loadingMetadata, getMetadata }}>
      {children}
    </MetadataContext.Provider>
  );
};

export const useMetadata = () => {
  const context = useContext(MetadataContext);
  if (!context) {
    throw new Error('useMetadata must be used within a MetaData provider');
  }
  return context;
};