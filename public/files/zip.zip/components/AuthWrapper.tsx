'use client';

import React, { ReactNode, FC, useRef, useEffect } from 'react';
import { OidcProvider, OidcSecure, useOidcFetch } from '@axa-fr/react-oidc';
import { Toast } from 'primereact/toast';
import dynamic from 'next/dynamic';
import { Spinner } from './Spinner';
import { fetchWithErrorHandling } from '@/utils/fetch';

interface AuthLoadingProps {
  message?: {
    type: 'success' | 'warn' | 'error' | 'info';
    message: string;
  };
  callback?: () => void;
}

interface AuthWrapperProps {
  children: ReactNode;
}

const AuthLoading: FC<AuthLoadingProps> = ({ message, callback }) => {
  const toast = useRef<Toast>(null);

  useEffect(() => {
    if (message && toast.current) {
      toast.current.show({
        severity: message?.type,
        summary: 'Ошибка',
        detail: message?.message,
      });
    }

    if (callback) {
      callback();
    }
  }, [message, callback]);

  return (
    <div className="flex items-center justify-center h-screen">
      <Spinner />
      <Toast ref={toast} />
    </div>
  );
};

let defaultFetch:
  | ((
      input: RequestInfo | URL,
      init?: RequestInit | undefined,
    ) => Promise<Response>)
  | undefined;

if (typeof window !== 'undefined') {
  defaultFetch = window.fetch;
}

const AuthWrapper: FC<AuthWrapperProps> = ({ children }) => {
  const { fetch: oidcFetch } = useOidcFetch(defaultFetch ?? window.fetch);

  const authConfig = {
    client_id: process.env.NEXT_PUBLIC_OIDC_CLIENT_ID || '',
    redirect_uri:
      typeof window !== 'undefined'
        ? window.location.origin + '#authentication-callback'
        : '',
    scope: 'openid',
    authority: process.env.NEXT_PUBLIC_OIDC_ISSUER_URI || '',
    ...(process.env.NEXT_PUBLIC_OIDC_SERVICEWORKER !== '0' && {
      service_worker_relative_url: '/OidcServiceWorker.js',
    }),
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const fetchFunction =
        process.env.NEXT_PUBLIC_OIDC_SERVICEWORKER === '0'
          ? oidcFetch
          : defaultFetch;

      window.fetch = fetchWithErrorHandling(fetchFunction ?? window.fetch);
    }
  }, [oidcFetch]);

  if (typeof window === 'undefined') {
    return null;
  }

  return (
    <OidcProvider
      configuration={authConfig}
      loadingComponent={AuthLoading}
      sessionLostComponent={() => (
        <AuthLoading
          message={{
            type: 'error',
            message: 'Ваша сессия истекла',
          }}
          callback={() => {
            console.log('Session lost');
          }}
        />
      )}
      authenticatingComponent={AuthLoading}
      callbackSuccessComponent={AuthLoading}
      authenticatingErrorComponent={() => (
        <AuthLoading
          callback={() => {
            window.location.href = '/';
          }}
        />
      )}
      serviceWorkerNotSupportedComponent={() => (
        <AuthLoading
          message={{
            type: 'error',
            message:
              'Service Worker не поддерживается в Вашем браузере. Пожалуйста, воспользуйтесь современным браузером',
          }}
          callback={() => {
            console.log('Service worker not supported');
          }}
        />
      )}
      onSessionLost={() => {
        window.location.reload();
      }}
    >
      <OidcSecure callbackPath="/">{children}</OidcSecure>
    </OidcProvider>
  );
};

export default dynamic(() => Promise.resolve(AuthWrapper), { ssr: false });
