'use client';
import React, { useEffect, useState } from 'react';
import { addLocale } from 'primereact/api';

import Sidebar from './Sidebar';
import Breadcrumbs from "@/components/Breadcrumbs";
import { ruLocale } from '@/utils/locale';
import SmallIconButton from './SmallIconButton';

export type LayoutProps = {
  children?: React.ReactNode;
};

export default function Layout({ children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  useEffect(function addRussianPrimeReactLocale() {
    addLocale('ru', ruLocale);
  }, []);

  return (
    <div className="h-screen">
      <div
        className={`fixed top-0 left-0 h-full bg-surface-900 text-surface-50 transition-all duration-300 w-72 ${sidebarOpen ? 'translate-x-0' : '-translate-x-72'}`}
      >
        <Sidebar sidebarOpen={sidebarOpen} />
      </div>
      <div
        className={`h-screen flex flex-col flex-grow transition-all duration-300 ${sidebarOpen ? 'ml-72' : 'ml-0'}`}
      >
        <div className="p-6 flex items-center">
          <SmallIconButton
            icon="pi pi-bars text-base"
            onClick={toggleSidebar}
          />
          <Breadcrumbs />
        </div>
        <div className="px-6 flex-1 flex flex-col">{children}</div>
      </div>
    </div>
  );
}
