'use client';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { usePathname } from 'next/navigation';
import { BreadCrumb } from 'primereact/breadcrumb';
import { MenuItem } from 'primereact/menuitem';
import { useSelector } from 'react-redux';
import { RootState } from '@/store/store';

const pageTitles = {
  '/': 'Главный экран',
  '/users': 'Список пользователей',
  '/permissions': 'Роли и группы',
  '/clients': 'Клиенты',
  '/documents': 'Документы',
  '/agreement': 'Договоры',
  '/dossier': 'Досье',
  '/about': 'О продукте'
} as const;

type PageTitlesKeys = keyof typeof pageTitles;

const Breadcrumbs = () => {
  const paths = usePathname();
  const [items, setItems] = useState<MenuItem[]>([]);
  const [userId, setUserId] = useState<string | null>(null);
  const breadcrumbs = useSelector(
    (state: RootState) => state.breadcrumb.breadcrumbs,
  );

  const extractUserId = (pathNames: string[]): string | null => {
    const lastSegment = pathNames[pathNames.length - 1];
    return !isNaN(Number(lastSegment)) ? lastSegment : null;
  };

  const generateUrl = (
    pathSegments: string[],
    index: number,
  ): PageTitlesKeys => {
    const urlPath = pathSegments.slice(0, index + 1).join('/');
    return (urlPath || '/') as PageTitlesKeys;
  };

  const createBreadcrumbItems = (
    pathNames: string[],
    userId: string | null,
  ): MenuItem[] => {
    return ['', ...pathNames].map((_segment, index, pathSegments): MenuItem => {
      const url = generateUrl(pathSegments, index);

      return {
        label: pageTitles[url],
        url: url,
        template: (item) =>
          userId && index === pathSegments.length - 1 && breadcrumbs ? (
            <span className="text-primary-500">
              {breadcrumbs?.fio || breadcrumbs?.name}
            </span>
          ) : (
            <Link
              to={url}
              className={
                index === pathSegments.length - 1 && pathSegments.length > 1
                  ? 'text-primary-500'
                  : 'text-surface-600'
              }
            >
              {item.label}
            </Link>
          ),
      };
    });
  };

  useEffect(() => {
    const pathNames = paths.split('/').filter(Boolean);
    const userIdFromPath = extractUserId(pathNames);

    setUserId(userIdFromPath);
    const breadcrumbItems = createBreadcrumbItems(pathNames, userIdFromPath);
    setItems(breadcrumbItems);
  }, [paths, userId, breadcrumbs]);

  return (
    <BreadCrumb
      model={items}
      pt={{ root: { className: 'border-none bg-transparent py-0 px-2' } }}
    />
  );
};

export default Breadcrumbs;
