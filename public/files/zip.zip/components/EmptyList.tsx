interface EmptyListProps {
  title: string;
  message: string;
}

const EmptyList = ({title, message}: EmptyListProps) => {
  return (
    <div className="min-w-76 h-full py-8 flex-1 flex flex-col justify-center items-center gap-6 m-auto">
      <div className="w-full flex-1 flex flex-col justify-center items-center">
        <div>
          <img src="../../empty.svg" alt="empty" />
        </div>

        <div className="flex flex-col items-center gap-1">
          <h2 className="text-base font-medium text-gray-600">{title}</h2>
          <p className="text-sm font-light text-gray-600 text-center">
            {message}
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmptyList;
