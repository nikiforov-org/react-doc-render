import { createAppSlice } from '@/store/createAppSlice';
import { PayloadAction } from '@reduxjs/toolkit';
import {
  IndividualClientWithProperties,
  LegalClientWithProperties,
} from '@/app/pages/clients/ClientCardPage/types';

export type ClientProps =
  | (IndividualClientWithProperties & LegalClientWithProperties)
  | null;

interface BreadcrumbsState {
  breadcrumbs: ClientProps;
}

const initialState: BreadcrumbsState = {
  breadcrumbs: null,
};

const breadcrumbsSlice = createAppSlice({
  name: 'breadcrumb',
  initialState,
  reducers: {
    setBreadcrumbs: (state, action: PayloadAction<ClientProps>) => {
      state.breadcrumbs = action.payload;
    },
  },
});

export const { setBreadcrumbs } = breadcrumbsSlice.actions;
export default breadcrumbsSlice.reducer;
