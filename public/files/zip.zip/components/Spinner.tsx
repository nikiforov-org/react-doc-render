import { ProgressSpinner } from 'primereact/progressspinner';
import { classNames } from 'primereact/utils';

type SpinnerProps = {
  text?: string;
};

export const Spinner = ({ text = 'Идет загрузка данных...' }: SpinnerProps) => (
  <div
    className={classNames(
      'w-full min-w-60 h-full flex-1 flex-col flex justify-center items-center mx-auto gap-2',
    )}
  >
    <ProgressSpinner className="w-12 h-12" />
    <p className="text-sm font-normal text-surface-700">{text}</p>
  </div>
);
