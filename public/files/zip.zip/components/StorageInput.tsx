import { FC, useContext, useState } from 'react';
import { AutoComplete, AutoCompleteProps } from 'primereact/autocomplete';
import { StorageLocation } from '@/types';
import { ToastContext } from '@/utils/formMessages';

const StorageInput: FC<AutoCompleteProps> = (props) => {
  const [storages, setStorages] = useState<StorageLocation[]>([]);

  const { showToast } = useContext(ToastContext);

  const onSearch = async (query: string) => {
    const queryString = query.trim().replace(/\s+/g, ' AND ');
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_APP_API}/search-dictionary`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            dictionaryNames: ['storage_locations'],
            query: {
              query_string: {
                query: `*${queryString}*`,
                fields: ['location_name'],
              },
            },
          }),
        },
      );
      const data = await response.json();
      const storageList = data.map(
        (storage: StorageLocation) => storage.properties.location_name,
      );
      setStorages(storageList);
    } catch (error) {
      showToast('error', 'Не удалось загрузить список мест хранения');
    }
  };

  return (
    <AutoComplete
      {...props}
      suggestions={storages}
      completeMethod={({ query }) => onSearch(query)}
    />
  );
};

export default StorageInput;
