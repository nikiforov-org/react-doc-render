import React, { ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { Spinner } from '@/components/Spinner';
import InfiniteScroll from 'react-infinite-scroll-component';

interface EndMessageProps {
  message?: string;
}

const EndMessage = ({ message }: EndMessageProps) => {
  return (
    <div className="flex justify-center my-2">
      <b>{message || "Вы просмотрели все данные"}</b>
    </div>
  );
};

interface InfiniteScrollWrapperProps<T> {
  data: T[];
  hasMore: boolean;
  onNextChange: () => void;
  endMessage?: string;
  children: ReactNode;
}

const InfiniteScrollWrapper = <T,>({
  children,
  data,
  hasMore,
  onNextChange,
  endMessage,
}: InfiniteScrollWrapperProps<T>) => {
  const [height, setHeight] = useState<number | undefined>(undefined);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const calculateHeight = useMemo(() => {
    const paddingBottom = 16;
    if (data.length && scrollContainerRef.current) {
      const offsetTop = scrollContainerRef.current?.offsetTop;
      const screenHeight = window.innerHeight;
      return Math.min(screenHeight - offsetTop, screenHeight) - paddingBottom;
    }
    return 0;
  }, [data]);

  useEffect(() => {
    setHeight(calculateHeight);
  }, [calculateHeight]);

  return (
    <div ref={scrollContainerRef} className="pb-4">
      <InfiniteScroll
        dataLength={data.length}
        next={onNextChange}
        hasMore={hasMore}
        height={height ? height : 'auto'}
        loader={data.length > 0 && <Spinner />}
        endMessage={data.length > 0 && <EndMessage message={endMessage} />}
      >
        {children}
      </InfiniteScroll>
    </div>
  );
};

export default InfiniteScrollWrapper;
