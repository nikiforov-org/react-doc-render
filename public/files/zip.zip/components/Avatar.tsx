import React from 'react';
import { Avatar as PrimeAvatar } from 'primereact/avatar';

interface AvatarProps {
    name?: string;
    img?: string;
}

const getInitialAndColor = (name: string) => {
    const colours = [
        "#1abc9c", "#2ecc71", "#3498db", "#9b59b6", "#34495e", "#16a085", "#27ae60", "#2980b9", "#8e44ad", "#2c3e50",
        "#f1c40f", "#e67e22", "#e74c3c", "#ecf0f1", "#95a5a6", "#f39c12", "#d35400", "#c0392b", "#bdc3c7", "#7f8c8d"
    ];

    const initial = name.charAt(0).toUpperCase();
    const charIndex = initial.charCodeAt(0) - 64;
    const colourIndex = charIndex % 20;
    const color = colours[colourIndex - 1];

    return { initial, color };
};

const Avatar: React.FC<AvatarProps> = ({ name = '', img }) => {
    if (img) {
        return <PrimeAvatar image={img} shape="circle" className="w-10 h-10 text-white" />;
    } else {
        const { initial, color } = getInitialAndColor(name);
        return <PrimeAvatar label={initial} shape="circle" className={`w-10 h-10 text-white`} style={{ backgroundColor: color }} />;
    }
};

export default Avatar;
