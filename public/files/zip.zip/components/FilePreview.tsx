'use client';

import React from 'react';
import { DocRender } from 'react-doc-render';
import { Spinner } from './Spinner';
import './FilePreview.scss';

interface FilePreviewProps {
  uri: string;
}

const FilePreview: React.FC<FilePreviewProps> = ({ uri }) => {
  return (
    <>
      <DocRender
        uri={uri}
        loading={Spinner}
      />
    </>
  );
};

export default FilePreview;
