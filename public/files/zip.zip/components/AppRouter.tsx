'use client';

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './Layout';
import HomePage from '@/app/pages/home/HomePage';
import AboutPage from '@/app/pages/about/AboutPage';
import DocumentsPage from '@/app/pages/documents/DocumentsPage';
import PermissionsPage from '@/app/pages/permissions/PermissionsPage';
import UsersPage from '@/app/pages/users/UsersPage';
import ClientsPage from '@/app/pages/clients/ClientsPage';
import ClientCardPage from '@/app/pages/clients/ClientCardPage/ClientCardPage';

export default function AppRouter() {
  return (
    <Router>
      <Routes>
        <Route
          path="/"
          element={
            <Layout>
              <HomePage />
            </Layout>
          }
        />
        <Route
          path="/permissions"
          element={
            <Layout>
              <PermissionsPage />
            </Layout>
          }
        />
        <Route
          path="/users"
          element={
            <Layout>
              <UsersPage />
            </Layout>
          }
        />
        <Route
          path="/documents"
          element={
            <Layout>
              <DocumentsPage />
            </Layout>
          }
        />
        <Route
          path="/clients"
          element={
            <Layout>
              <ClientsPage />
            </Layout>
          }
        />
        <Route
          path="/clients/:id"
          element={
            <Layout>
              <ClientCardPage />
            </Layout>
          }
        />
        <Route
          path="/about"
          element={
            <Layout>
              <AboutPage />
            </Layout>
          }
        />
      </Routes>
    </Router>
  );
}
