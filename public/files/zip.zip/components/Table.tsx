import {Column} from "primereact/column";
import {OverlayPanel} from "primereact/overlaypanel";
import React, { ReactNode, useRef, useState } from 'react';
import {
  DataTable,
  DataTableFilterMeta,
  DataTableSelectionSingleChangeEvent,
  DataTableValue,
  DataTableValueArray,
} from 'primereact/datatable';
import { ConfirmPopup } from "primereact/confirmpopup";
import { Button } from "primereact/button";
import { classNames } from "primereact/utils";
import EmptyList from "@/components/EmptyList";
import { Spinner } from './Spinner';

interface TableColumn<
  TableData extends { [key: string]: string | number | boolean },
> {
  field: string;
  header: string;
  body?: (rowData: TableData) => ReactNode;
  width?: string;
}

interface TableProps<
  TableData extends { [key: string]: string | number | boolean },
> {
  tableColumn?: TableColumn<TableData>[];
  tableData?: TableData[] | undefined;
  isLoading: boolean;
  editAction?: (data: TableData) => void;
  toggleEnabledAction?: (data: TableData) => void;
  deleteAction?: (data: TableData) => void;
  filters?: DataTableFilterMeta | undefined;
  areActionsEnabled?: boolean;
  isSelectionEnabled?: boolean;
  isMultipleSelectionEnabled?: boolean;
}

type CheckboxEventType =
  DataTableSelectionSingleChangeEvent<DataTableValueArray>;

const Table = <TableData extends { [key: string]: string | number | boolean }>({
  filters,
  editAction,
  toggleEnabledAction,
  deleteAction,
  tableColumn,
  tableData,
  isLoading,
  areActionsEnabled = false,
  isSelectionEnabled = false,
  isMultipleSelectionEnabled = false,
}: TableProps<TableData>) => {
  const [currentRowData, setCurrentRowData] = useState<TableData | null>(null);
  const op = useRef<OverlayPanel>(null);
  const popoverChange = (
    e: React.MouseEvent<HTMLButtonElement>,
    rowData: TableData,
  ) => {
    setCurrentRowData(rowData);
    op.current?.toggle(e);
  };

  const editActionHandler = () => {
    if (currentRowData && editAction) {
      op.current?.hide();
      editAction(currentRowData);
    }
  };

  const toggleEnabledActionHandler = () => {
    if (currentRowData && toggleEnabledAction) {
      op.current?.hide();
      toggleEnabledAction(currentRowData);
    }
  };

  const blockButtonRef = useRef<HTMLButtonElement | null>(null);
  const deleteButtonRef = useRef<HTMLButtonElement | null>(null);
  const [confirmPopupType, setConfirmPopupType] = useState<
    'block' | 'delete' | null
  >(null);
  const openBlockConfirmPopup = () =>
    setTimeout(() => setConfirmPopupType('block'));
  const openDeleteConfirmPopup = () =>
    setTimeout(() => setConfirmPopupType('delete'));
  const closeConfirmPopup = () => setConfirmPopupType(null);
  const deleteActionHandler = () => {
    if (currentRowData && deleteAction) {
      closeConfirmPopup();
      op.current?.hide();
      deleteAction(currentRowData);
    }
  };

  const actionBodyTemplate = (rowData: TableData) => {
    return (
      <Button
        onClick={(e) => popoverChange(e, rowData)}
        icon="pi pi-ellipsis-v"
        rounded
        text
        className="w-6 h-6 text-surface-500"
      />
    );
  };

  const [selectedRows, setSelectedRows] = useState<DataTableValue | null>(null);
  const onSelectionChange = (e: CheckboxEventType) => {
    setSelectedRows(e.value);
  };

  return (
    <div className="h-full flex-1 flex flex-col justify-between">
      <DataTable
        filters={filters}
        value={tableData}
        scrollable
        selectionMode={isSelectionEnabled ? 'single' : undefined}
        selection={selectedRows}
        onSelectionChange={onSelectionChange}
        emptyMessage=" "
        pt={{
          root: {
            className: classNames({
              ['pb-6']: tableData?.length && !isLoading,
            }),
          },
          column: {
            headerCell: { className: classNames({ 'opacity-40': isLoading }) },
            bodyCell: {
              className: classNames({
                ['border-none p-0']: !tableData?.length || isLoading,
              }),
            },
          },
        }}
        dataKey="id"
      >
        {isMultipleSelectionEnabled && (
          <Column
            selectionMode="multiple"
            pt={{
              headerCell: { className: 'w-4 pr-1' },
              bodyCell: { className: 'w-4 pr-1' },
            }}
          />
        )}
        {areActionsEnabled && (
          <Column
            body={actionBodyTemplate}
            pt={{
              headerCell: {
                className: classNames('w-13 min-w-13', {
                  ['pl-1']: isMultipleSelectionEnabled,
                }),
              },
              bodyCell: {
                className: classNames('w-13', {
                  ['pl-1']: isMultipleSelectionEnabled,
                }),
              },
            }}
          />
        )}

        {tableColumn?.map((col, index) => (
          <Column
            key={index}
            field={col.field}
            body={col.body}
            header={col.header}
            style={{ minWidth: col.width }}
          />
        ))}
      </DataTable>

      {isLoading ? <Spinner /> : null}

      {!tableData?.length && !isLoading ? (
        <EmptyList
          title="Нет данных для отображения"
          message="Измените строку поиска или добавьте новых пользователей"
        />
      ) : null}

      <OverlayPanel pt={{ content: { className: 'p-2' } }} ref={op}>
        <div className="flex flex-col gap-1">
          <button
            className="p-2 flex justify-start hover:bg-surface-100"
            onClick={editActionHandler}
          >
            Редактировать
          </button>
          <ConfirmPopup
            target={blockButtonRef.current ?? undefined}
            visible={confirmPopupType === 'block'}
            onHide={closeConfirmPopup}
            message={`Вы уверены, что хотите ${currentRowData?.enabled ? 'заблокировать' : 'разблокировать'} пользователя? Это действие изменит его доступ к системе.`}
            icon="pi pi-exclamation-triangle"
            defaultFocus="reject"
            acceptLabel="Да"
            acceptClassName="p-button-danger"
            rejectLabel="Нет"
            accept={toggleEnabledActionHandler}
            reject={closeConfirmPopup}
          />
          <button
            ref={blockButtonRef}
            className="p-2 flex justify-start hover:bg-surface-100"
            onClick={openBlockConfirmPopup}
          >
            {currentRowData?.enabled ? 'Заблокировать' : 'Разблокировать'}
          </button>
          <ConfirmPopup
            target={deleteButtonRef.current ?? undefined}
            visible={confirmPopupType === 'delete'}
            onHide={closeConfirmPopup}
            message="Вы уверены, что хотите удалить выбранного пользователя? Это действие необратимо и не может быть отменено."
            icon="pi pi-exclamation-triangle"
            defaultFocus="reject"
            acceptLabel="Да"
            acceptClassName="p-button-danger"
            rejectLabel="Нет"
            accept={deleteActionHandler}
            reject={closeConfirmPopup}
          />
          <button
            ref={deleteButtonRef}
            onClick={openDeleteConfirmPopup}
            className="p-2 flex justify-start hover:bg-surface-100"
          >
            Удалить
          </button>
        </div>
      </OverlayPanel>
    </div>
  );
};

export default Table;
