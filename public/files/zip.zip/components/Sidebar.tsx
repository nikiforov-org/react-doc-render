'use client';
import { useEffect, useLayoutEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { usePathname } from "next/navigation";
import { type OidcUserInfo, useOidcUser, useOidc } from '@axa-fr/react-oidc';
import { Button } from "primereact/button";
import { PanelMenu } from "primereact/panelmenu";
import Avatar from "@/components/Avatar";
import { Divider } from 'primereact/divider';
import { clearLocalStorageOnLogout } from '@/utils/localStorage';
import { MenuItem } from 'primereact/menuitem';

interface SidebarTreeNode extends Omit<MenuItem, 'template' | 'items'> {
  key: string;
  template: (node: SidebarTreeNode) => JSX.Element;
  items?: SidebarTreeNode[];
}

interface SidebarProps {
  sidebarOpen: boolean;
}

interface OidcUserRoleInfo extends OidcUserInfo {
  role?: string[];
}

export default function Sidebar({ sidebarOpen }: SidebarProps) {
  const { logout } = useOidc();
  const { oidcUser } = useOidcUser<OidcUserRoleInfo>();
  const [expandedKeys, setExpandedKeys] = useState<Record<string, boolean>>({});
  const pathname = usePathname();

  const sidebarStyle = {
    headerContent: { className: 'bg-transparent border-none rounded-none flex' },
    menuContent: { className: 'bg-transparent border-none p-0' },
    menu: { className: 'flex flex-col gap-2' },
    content: { className: 'bg-transparent border-none' },
    toggleableContent: { className: 'mt-2' },
  };

  function findKeyByUrl(tree: SidebarTreeNode[], url: string): string | null {
    for (const node of tree) {
      if (node.url === url) {
        return node.key;
      }
      if (node.items) {
        const foundKey = findKeyByUrl(node.items, url);
        if (foundKey) {
          return foundKey;
        }
      }
    }
    return null;
  }

  const getParentKeysArr = (key: string) => {
    const result = [];
    const keyPath = key.split('-');
    for (let i = 1; i < keyPath.length; i += 1) {
      result.push(keyPath.slice(0, i).join('-'));
    }
    return result;
  };

  useEffect(() => {
    const activeKey = findKeyByUrl(nodes, pathname);
    if (!activeKey) return;

    setExpandedKeys(
      Object.fromEntries(getParentKeysArr(activeKey).map((key) => [key, true])),
    );
  }, [pathname]);

  const nodeTemplate = (node: SidebarTreeNode) => {
    const isChild = node.key.split('-').length > 1;
    const isExpanded = Boolean(expandedKeys[node.key]);
    const isActivePanel = node.url === pathname;

    if (node.url) {
      return (
        <Link
          className={`w-full block px-6 py-3 text-surface-100 hover:bg-gray-50/10 ${isActivePanel && 'bg-surface-600 hover:bg-surface-600'} ${isChild && 'pl-10'}`}
          to={node.url}
        >
          {node.label}
        </Link>
      );
    }

    return (
      <div className="w-full flex justify-between px-6 py-3 text-surface-100 hover:bg-gray-50/10">
        <span>{node.label}</span>
        <span
          className={isExpanded ? 'pi pi-angle-down' : 'pi pi-angle-right'}
        />
      </div>
    );
  };

  const nodes: SidebarTreeNode[] = [
    {
      key: '0',
      url: '/',
      label: 'Главный экран',
      template: nodeTemplate,
    },
    {
      key: '1',
      label: 'Администрирование',
      template: nodeTemplate,
      items: [
        {
          key: '1-1',
          url: '/permissions',
          label: 'Роли и группы',
          template: nodeTemplate,
        },
        {
          key: '1-2',
          url: '/users',
          label: 'Список пользователей',
          template: nodeTemplate,
        },
      ],
    },
    {
      key: '2',
      url: '/documents',
      label: 'Документы',
      template: nodeTemplate,
    },
    {
      key: '3',
      url: '/clients',
      label: 'Клиенты',
      template: nodeTemplate,
    },
  ];

  const nodesFooter: SidebarTreeNode[] = [
    { key: '6', url: '/about', label: 'О продукте', template: nodeTemplate },
    {
      key: '7',
      url: 'mailto:support@rdtex.ru',
      label: 'Запрос в поддержку',
      template: nodeTemplate,
    },
  ];

  const [isMenuShown, setIsMenuShown] = useState(sidebarOpen);
  useLayoutEffect(
    function toggleSidebarVisibility() {
      if (sidebarOpen && !isMenuShown) {
        setIsMenuShown(true);
      } else if (!sidebarOpen && isMenuShown) {
        setTimeout(() => {
          setIsMenuShown(false);
        }, 300);
      }
    },
    [sidebarOpen, isMenuShown],
  );

  const handleLogout = () => {
    clearLocalStorageOnLogout();
    logout();
  };

  return (
    <div
      className={
        isMenuShown ? 'h-full flex flex-col justify-between' : 'hidden'
      }
    >
      <div>
        <div className="px-6 pt-4 pb-14">
          <Link to="/">
            <img src="/logo.svg" alt="rdtex.chive" />
          </Link>
        </div>
        <PanelMenu
          className="w-full md:w-30rem"
          // @ts-ignore
          model={nodes}
          pt={sidebarStyle}
          expandedKeys={expandedKeys}
          onExpandedKeysChange={setExpandedKeys}
        />
      </div>

      <div>
        <div className="px-4 pb-1">
          <Divider className="before:border-surface-600" />
        </div>
        <PanelMenu
          className="w-full md:w-30rem"
          // @ts-ignore
          model={nodesFooter}
          pt={sidebarStyle}
        />
        <div className="flex gap-4 items-center py-6 px-4">
          <div>
            <Avatar name={oidcUser?.given_name} />
          </div>
          <div className="flex flex-col">
            <span className="text-sm text-surface-50">
              {oidcUser?.family_name}&nbsp;{oidcUser?.given_name}
            </span>
            <span className="text-sm font-light text-surface-50">
              {oidcUser?.email}
            </span>
          </div>
          <Button
            icon="pi pi-sign-out text-base"
            className="text-surface-500 bg-surface-900 border-0 ml-auto"
            onClick={() => handleLogout()}
          />
        </div>
      </div>
    </div>
  );
}
