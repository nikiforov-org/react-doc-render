import { formStyle } from '@/app/pages/clients/constants';
import { Field } from './MetaData';
import { classNames } from 'primereact/utils';
import {
  Control,
  Controller,
  ControllerProps,
  FieldErrors,
  FieldValues,
  Path,
} from 'react-hook-form';
import { getRules } from '@/utils/validation';
import { InputText } from 'primereact/inputtext';
import { getFormErrorMessage } from '@/utils/formMessages';
import { Calendar } from 'primereact/calendar';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { useEffect, useState } from 'react';
import { getDictionaryService } from '@/app/pages/documents/services';
import { RadioButton } from 'primereact/radiobutton';
import { formatDateToISO } from '@/utils/date';

export type DictionaryItem = { id: string; name: string };

type FormFieldProps<FormValues extends FieldValues> = {
  name: Path<FormValues>;
  label: string;
  isFilter?: boolean;
  preferRadioButtons?: boolean;
  fieldsMetadata: { [key: string]: Field } | null;
  control: Control<FormValues>;
  setValue: (name: keyof FormValues, value: string) => void;
  errors: FieldErrors<FormValues>;
  disabled?: boolean;
};

export const FormField = <FormValues extends FieldValues>({
  name,
  label,
  isFilter,
  preferRadioButtons,
  fieldsMetadata,
  control,
  setValue,
  errors,
  disabled,
}: FormFieldProps<FormValues>) => {
  const fieldMetadata = fieldsMetadata?.[name];
  const lookupField = fieldMetadata?.lookupField;

  const handleTrimOnBlur = (fieldValue: string) => {
    setValue(name, fieldValue.trim());
  };

  const [dictionaryData, setDictionaryData] = useState<DictionaryItem[]>([]);
  useEffect(
    function getDictionaryData() {
      (async () => {
        if (lookupField) {
          const data = await getDictionaryService(lookupField?.objectType, {
            match_all: {},
          });
          if (data) {
            const transformedData = data?.map((item) => ({
              name: item.properties[lookupField.field],
              id: item.id,
            }));
            setDictionaryData(transformedData);
          }
        }
      })();
    },
    [lookupField?.objectType, lookupField?.field],
  );

  let render: ControllerProps<FormValues>['render'] = () => <></>;
  if (fieldMetadata?.dataType === 'TEXT') {
    if (!fieldMetadata?.lookupField?.objectType && !fieldMetadata?.enumValues) {
      render = ({ field, fieldState }) => (
        <InputText
          id={field.name}
          maxLength={fieldMetadata?.maxLength}
          {...field}
          onBlur={() => handleTrimOnBlur(field.value)}
          disabled={disabled}
          className={classNames({ 'p-invalid': fieldState.invalid })}
        />
      );
    } else if (fieldMetadata?.enumValues) {
      if (!preferRadioButtons) {
        render = ({ field }) => {
          const onDropdownChange = (e: DropdownChangeEvent) => {
            if (e.value) {
              field.onChange(e.value);
            } else {
              field.onChange(null);
            }
          };

          return (
            <Dropdown
              placeholder="Выберите из списка"
              id={field.name}
              {...field}
              onChange={
                isFilter || fieldMetadata?.nullable
                  ? onDropdownChange
                  : field.onChange
              }
              options={fieldMetadata?.enumValues}
              showClear={isFilter || fieldMetadata?.nullable}
              disabled={disabled}
            />
          );
        };
      } else {
        render = ({ field, fieldState }) => (
          <div className="flex flex-wrap gap-6">
            {fieldMetadata?.enumValues?.map((value, index) => {
              const id = `${field.name}-${index}`;
              return (
                <div className="flex items-center" key={id}>
                  <RadioButton
                    inputId={id}
                    value={value}
                    onChange={(e) => field.onChange(e.value)}
                    checked={field.value === value}
                    disabled={disabled}
                    className={classNames({
                      'p-invalid': fieldState.invalid,
                    })}
                  />
                  <label
                    htmlFor={id}
                    className={classNames(
                      { 'p-error': fieldState.error },
                      'ml-2',
                    )}
                  >
                    {value}
                  </label>
                </div>
              );
            })}
          </div>
        );
      }
    } else {
      render = ({ field }) => {
        const onDropdownChange = (e: DropdownChangeEvent) => {
          if (e.value) {
            field.onChange(e.value);
          } else {
            field.onChange(null);
          }
        };

        return (
          <Dropdown
            placeholder="Выберите из списка"
            id={field.name}
            {...field}
            onChange={
              isFilter || fieldMetadata?.nullable
                ? onDropdownChange
                : field.onChange
            }
            options={dictionaryData}
            optionLabel="name"
            optionValue="name"
            showClear={isFilter || fieldMetadata?.nullable}
            disabled={disabled}
          />
        );
      };
    }
  } else if (fieldMetadata?.dataType === 'TIMESTAMP') {
    render = ({ field }) => (
      <Calendar
        id={field.name}
        value={field.value && new Date(field.value)}
        onChange={
          isFilter
            ? field.onChange
            : (e) => field.onChange(e.value && formatDateToISO(e.value))
        }
        dateFormat="dd.mm.yy"
        mask="99.99.9999"
        placeholder="__.__.____"
        showIcon
        showButtonBar={isFilter || fieldMetadata?.nullable}
        disabled={disabled}
      />
    );
  } else if (fieldMetadata?.dataType === 'BOOLEAN') {
    const options = [
      {
        name: 'Да',
        value: true,
      },
      {
        name: 'Нет',
        value: false,
      },
    ];
    render = ({ field, fieldState }) => (
      <div className="flex flex-wrap gap-6">
        {options.map((option, index) => {
          const id = `${field.name}-${index}`;
          return (
            <div className="flex items-center" key={id}>
              <RadioButton
                inputId={id}
                value={option.value}
                onChange={(e) => field.onChange(e.value)}
                checked={field.value === option.value}
                disabled={disabled}
                className={classNames({
                  'p-invalid': fieldState.invalid,
                })}
              />
              <label
                htmlFor={id}
                className={classNames({ 'p-error': fieldState.error }, 'ml-2')}
              >
                {option.name}
              </label>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className={formStyle.field}>
      <label
        htmlFor={name ? name.toString() : undefined}
        className={classNames({ 'p-error': errors[name] })}
      >
        {label} {!isFilter && fieldMetadata?.nullable ? '(необязательно)' : ''}
      </label>
      <Controller
        name={name}
        control={control}
        rules={getRules(fieldMetadata, isFilter)}
        render={render}
      />
      {getFormErrorMessage(errors, name)}
    </div>
  );
};
