import React from 'react';
import { Sidebar, SidebarPassThroughOptions } from 'primereact/sidebar';

interface DrawerProps {
  header?: string | React.ReactNode;
  formVisible: boolean;
  fullScreen?: boolean;
  onHide: () => void;
  children: React.ReactNode;
}

const Drawer = ({ header, fullScreen, formVisible, onHide, children }: DrawerProps) => {
  const DrawerStyle: SidebarPassThroughOptions = {
    header: {
      className: 'p-5 text-base font-medium text-surface-600',
    },
    closeIcon: {
      style: {
        width: 16,
        height: 16,
      },
    },
    content: {
      className: 'px-0 pb-0',
    },
  };

  return (
    <Sidebar
      className={!fullScreen ? "min-w-104 h-screen flex flex-col" : undefined}
      header={header}
      visible={formVisible}
      onHide={onHide}
      {...(fullScreen ? { fullScreen: true } : { position: "right" })}
      pt={DrawerStyle}
    >
      {children}
    </Sidebar>
  );
};

export default Drawer;
