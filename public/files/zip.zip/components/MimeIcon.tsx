'use client'
import React from 'react';

interface Props {
    mimeType: string;
    className?: string;
}

const MimeIcon: React.FC<Props> = ({ mimeType, className }) => {
    let icon: string;

    switch (mimeType) {
        case 'application/msword':
        case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
            icon = 'doc.svg';
            break;
        case 'image/jpeg':
            icon = 'jpeg.svg';
            break;
        case 'image/jpg':
            icon = 'jpg.svg';
            break;
        case 'application/pdf':
            icon = 'pdf.svg';
            break;
        case 'image/png':
            icon = 'png.svg';
            break;
        case 'image/gif':
            icon = 'gif.svg';
            break;
        case 'application/vnd.ms-excel':
        case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
            icon = 'xls.svg';
            break;
        case 'application/xml':
        case 'text/xml':
            icon = 'xml.svg';
            break;
        case 'application/zip':
            icon = 'zip.svg';
            break;
        default:
            icon = 'txt.svg'; // SVG icon for unknown MIME types
            break;
    }

    return (
        <img src={`/img/mime-icons/${icon}`} className={className} />
    );
};

export default MimeIcon;
